# Byte Vortex — Android 6.0 e 10+

Android 6.0 abre uma tela nativa leve; a loja abre no navegador. Android 10+ carrega a loja no WebView com tela de reconexão, tentativa automática curta e botões para tentar novamente ou abrir no navegador se a conexão falhar.

Login por e-mail e senha. PIX é manual pela chave informada; pagamento não é confirmado nem licença Pro liberada automaticamente. Builds release via CI, assinatura temporária, não testados em aparelho para todas as falhas de rede.
