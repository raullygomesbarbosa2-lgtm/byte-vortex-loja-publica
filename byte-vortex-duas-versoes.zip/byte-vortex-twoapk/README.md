# Byte Vortex — site e APKs

Projeto atualizado a partir do arquivo recebido em 15/11/2026 às 16:17. O site usa o React e componentes atualizados desse arquivo. O APK Android 10+ abre a loja online; o de KitKat 4.4 usa um catálogo simplificado para contornar o WebView antigo.

Builds release: minSdk 19 (KitKat) e minSdk 29 (Android 10+). A assinatura é temporária e não guardada, então atualizações podem exigir desinstalar. Builds não testados fisicamente em aparelho.

Firestore original bloqueia leituras públicas; catálogo estático JSON é fallback e inicia vazio. GitHub Pages não hospeda o servidor Express/upload. Pagamentos desativados pois o código original marcava pedidos como pagos sem confirmação de transação.
