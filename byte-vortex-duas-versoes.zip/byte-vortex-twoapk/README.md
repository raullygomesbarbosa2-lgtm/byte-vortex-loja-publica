# Byte Vortex — site e APKs Android

Projeto atualizado a partir do arquivo enviado às 17:04 de 15/11/2026. O site usa a versão React mais nova; Android 10+ abre a loja hospedada, enquanto KitKat 4.4 usa tela simplificada de catálogo devido ao WebView antigo.

MinSdk 19 (KitKat) e minSdk 29 (Android 10+). APKs release assinados com chave temporária não retida; futuras atualizações podem exigir desinstalar. Builds não testados em aparelhos físicos.

Firestore não permite leitura pública no estado atual; catalogo.json serve como fallback e começa vazio. GitHub Pages não hospeda servidor Express/uploads. Checkout desativado porque o código-fonte marcava transação como paga sem provedor; redefinição local insegura desativada.
