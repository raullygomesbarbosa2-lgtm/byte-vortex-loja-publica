# Byte Vortex — Android 6.0 e 10+

Android 6.0 abre uma tela nativa leve; a loja abre no navegador. Android 10+ carrega a loja no WebView com tela de reconexão, tentativa automática curta e botões para tentar novamente ou abrir no navegador se a conexão falhar.

Login por e-mail e senha. Os cards mostram ⭐ azul para identificar a versão grátis/Beta, com download direto, e ⭐ verde para Pro. A versão Pro recebe desconto visual de 10% no preço do catálogo e o total Pix manual é calculado com o desconto. Não há pagamento automático, comissão por instalação nem confirmação automática; conferir o Pix e liberar Pro continua manual. Builds release via CI, assinatura temporária, não testados em aparelho para todas as falhas de rede.

O fundo da loja foi atualizado com a imagem quadrada Byte Vortex. O site a exibe inteira com `background-size: contain` e sem recorte; em telas com proporções diferentes pode haver faixas escuras ao redor para preservar a imagem completa.

O áudio enviado pelo usuário foi convertido para MP3 e está incluído no site como player manual (não inicia sozinho), com botão para baixar.
