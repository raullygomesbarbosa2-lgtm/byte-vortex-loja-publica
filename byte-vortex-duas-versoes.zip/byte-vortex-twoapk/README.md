# Byte Vortex — site e aplicativos

Atualizado com o projeto recebido em 15/11/2026 às 17:17. O app moderno conserva os ajustes de login/redirect do projeto mais novo; Android 10+ abre a loja online, KitKat 4.4 usa catálogo simples.

MinSdk 19 e 29, builds release com assinatura temporária não guardada; updates podem exigir reinstalação. Builds não testados nos aparelhos. Firestore impede leitura pública no estado atual, catalogo.json fallback vazio. GitHub Pages não executa servidor Express/upload. Pagamentos desativados; links de redefinição local inseguros desabilitados.
