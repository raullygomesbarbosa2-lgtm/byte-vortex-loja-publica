# Byte Vortex: loja pública e versões Android

Projeto adaptado do ZIP enviado. O APK moderno inclui a interface React do projeto e usa Firebase; endpoints `/api/` de upload/login alternativo requerem um servidor de produção separado e não foram configurados. O APK KitKat é uma interface reduzida para consulta pública de itens gratuitos; não inclui login ou pagamentos. A página pública precisa hospedar a compilação web.

O Firestore retornou PERMISSION_DENIED na leitura pública; os produtos não ficarão visíveis até o proprietário autorizar o acesso ao catálogo com regras seguras. Nenhum checkout real é implementado; compras foram bloqueadas. Não insira cartões nem use PIX. Não há emuladores ou jogos empacotados.

As versões Android de CI são compiladas em modo release assinadas com chave temporária não preservada: para atualizar depois, terá que desinstalar a versão anterior, apagando dados locais. O funcionamento em dispositivo não foi testado.
