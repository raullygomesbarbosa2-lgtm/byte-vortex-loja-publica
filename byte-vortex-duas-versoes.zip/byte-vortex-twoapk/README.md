# Byte Vortex — Android 6.0 e Android 10+

O acesso ao site e ao app é por e-mail e senha; removidos os botões e a opção de entrar com Google. O cadastro/login usa Firebase Authentication (E-mail/Senha). Para administração, é necessária conta verificada no endereço autorizado. GitHub Pages publica o frontend estático e não fornece o servidor Express de upload.

Android 6.0 (minSdk 23) e Android 10+ (minSdk 29). Builds release com assinatura temporária gerada no CI, não testados em aparelhos. Atualizações podem exigir desinstalação da versão anterior. O catálogo depende das permissões do Firestore e começa sem itens; pagamentos desativados.
