# Byte Vortex — Android 6.0 e Android 10+

Android 6.0 usa uma tela inicial nativa leve, sem WebView embutido, para evitar o quadro preto em WebView antigo; abre a loja ou o acesso por e-mail no navegador do aparelho. Android 10+ abre a loja no WebView do app.

Login e cadastro por e-mail e senha; Google removido do site e dos apps. Builds release com assinatura temporária do CI, não testados em aparelho real. Catálogo depende do Firestore (atualmente bloqueado/vazio) e upload de arquivos não é hospedado pelo GitHub Pages. Pagamentos desativados.
