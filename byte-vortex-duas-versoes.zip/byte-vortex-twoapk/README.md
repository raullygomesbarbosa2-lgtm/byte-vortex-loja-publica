# Byte Vortex — site e apps Android

Projeto atualizado com o arquivo recebido em 15/11/2026 às 16:36. Site React inclui os recursos mais novos, inclusive redefinição de senha. O APK Android 10+ abre a loja hospedada; KitKat 4.4 usa catálogo simples devido a limitações do WebView antigo.

MinSdk 19 (KitKat) e minSdk 29 (Android 10+). APKs release têm assinatura temporária não retida; futuras atualizações podem exigir desinstalação. Builds não testados fisicamente em aparelhos.

O Firestore do projeto tem negado leitura pública; a loja tenta catalogo.json estático como fallback, que começa vazio. GitHub Pages não executa o servidor Express nem upload/autenticação server-side. Pagamentos bloqueados porque código original marcava transações como pagas sem confirmação.
