# Byte Vortex — loja web e apps Android

Este pacote parte do HTML/ZIP enviado em 15/11/2026. O site moderno é compilado do projeto React recebido. O APK Android 10+ abre o site público; o APK KitKat 4.4 contém uma interface simplificada de catálogo gratuito porque o WebView do KitKat não executa de forma confiável o React/Firebase moderno.

Compatibilidade de build: KitKat Android 4.4 (minSdk 19) e Android 10+ (minSdk 29). Builds assinados para esta publicação com chave temporária não retida; futuras atualizações assinadas com outra chave exigirão desinstalação. Builds não foram instalados em aparelhos reais.

O Firestore do projeto recebido negou leitura anônima; loja tenta `catalogo.json` público como fallback. O catálogo começa vazio; cadastre itens e links legais públicos para que sejam exibidos. GitHub Pages entrega apenas conteúdo estático, não executa o servidor Express nem seu endpoint de upload. Pagamentos foram desativados porque a implementação original aprovava pedidos sem confirmação de provedor de pagamento.
