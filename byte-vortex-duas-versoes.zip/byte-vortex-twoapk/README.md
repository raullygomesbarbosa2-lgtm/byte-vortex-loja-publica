# Byte Vortex — loja pública e dois APKs

O ZIP de origem foi descompactado; inclui app React/Firebase e servidor Express de upload. O Firestore configurado no ZIP retorna `PERMISSION_DENIED` quando consultado como visitante; ainda não há acesso público ao catálogo, nem itens publicados confirmados. O APK Android 4.4 usa uma interface simples de catálogo e lê `catalogo.json` hospedado publicamente. O APK Android 10+ abre a loja React hospedada publicamente e tenta Firestore, com fallback ao mesmo JSON.

Os APKs são variantes release assinadas com chave temporária de CI. `minSdk 19` (Android 4.4+) e `minSdk 29` (Android 10+). A chave não é guardada; futuras atualizações com assinatura diferente exigem desinstalar a anterior e podem apagar os dados. Builds não foram testados fisicamente nos dispositivos.

Pagamentos/checkout estão desativados porque o código-fonte tratava o pedido como pago sem confirmar uma transação. Upload e autenticação alternativos no servidor não foram implantados; o deploy de GitHub Pages hospeda apenas a página estática. Para publicar novos downloads gratuitos, atualizar `catalogo.json` com links de arquivos publicamente acessíveis e dados de catálogo válidos. Arquivos do app não incluem ROMs/jogos.
