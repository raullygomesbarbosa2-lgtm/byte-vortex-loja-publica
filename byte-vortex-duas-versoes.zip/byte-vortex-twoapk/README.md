# Byte Vortex — site e APKs

Baseado no novo arquivo enviado em 15/11/2026 às 17:28. Site React atualizado; Android 10+ abre a loja online e KitKat 4.4 usa catálogo simples, pois WebView antigo não suporta com confiabilidade React/Firebase atuais.

MinSdk 19 (KitKat) e 29 (Android 10+). Builds release assinados com chave temporária não mantida; updates podem exigir desinstalação. Não testados em aparelhos físicos. Firestore bloqueia leitura pública no estado atual, catalogo.json fallback começa vazio. GitHub Pages não hospeda o servidor Express/upload. Pagamentos e redefinição local de senha desativados por segurança.
