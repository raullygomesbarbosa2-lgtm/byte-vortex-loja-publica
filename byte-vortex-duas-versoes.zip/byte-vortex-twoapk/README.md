# Byte Vortex — loja web e aplicativos Android

Atualização baseada no pacote mais recente enviado em 15/11/2026. O site usa o projeto React recebido; o Android 10+ abre o site público. O KitKat 4.4 usa catálogo web simplificado por incompatibilidade do WebView antigo com React/Firebase atual.

Dois sabores: minSdk 19 (Android 4.4) e minSdk 29 (Android 10+). Builds release assinados com uma chave temporária gerada no CI; a chave não é retida, então updates podem exigir desinstalação. Builds não foram testados fisicamente em aparelhos.

O Firestore original negou leituras públicas; o site tenta usar catalogo.json de fallback. O catálogo inicia vazio e precisa de URLs públicos/legais para baixar. GitHub Pages hospeda apenas conteúdo estático; servidor Express/upload não é implantado. Checkout desativado porque o projeto aprovado falsamente pagamentos sem confirmação de provedor.
