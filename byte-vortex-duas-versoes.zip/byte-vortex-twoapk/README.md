# Byte Vortex — site e APKs Android

Baseado no arquivo enviado às 17:43 de 15/11/2026. O site usa a versão React mais recente. Android 10+ abre a loja online; KitKat 4.4 usa tela simples de catálogo para compatibilidade do WebView.

MinSdk 19/29. APKs release assinados com chave temporária não retida; futuras versões podem exigir reinstalação. Builds não testados em aparelhos físicos. Firestore bloqueia leitura pública, catalogo.json fallback inicia vazio. GitHub Pages não executa o servidor Express/upload. Checkout desativado porque código do projeto aprova pedidos sem confirmação real; recuperação local de senha também desativada por segurança.
