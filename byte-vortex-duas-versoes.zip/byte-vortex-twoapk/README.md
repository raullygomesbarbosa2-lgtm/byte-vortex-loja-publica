# Byte Vortex — site, Android 6 e Android 10+

Baseado no HTML recebido às 18:12 de 15/11/2026. Ambas as versões abrem a loja online. APK Android 6.0 (minSdk 23) pode exigir atualização do Android System WebView para exibir o site moderno; a compatibilidade não foi verificada em aparelho. Android 4.4 foi removido.

Builds release, chave temporária não preservada; futuras versões podem exigir reinstalação. Não testados em aparelhos físicos. Firestore bloqueia leitura pública; fallback JSON começa vazio. GitHub Pages não executa servidor Express/upload. Pagamentos e redefinição de senha local desativados por segurança.
