# Byte Vortex — site e APKs

Projeto atualizado do arquivo recebido às 17:56 de 15/11/2026. O site usa os componentes mais recentes; Android 10+ abre a loja online; KitKat 4.4 apresenta catálogo simplificado por limitações do WebView antigo.

MinSdk 19/29, release com chave temporária não mantida; atualizações podem exigir reinstalar. Builds não testados em aparelho. Firestore bloqueia catálogo público, JSON fallback inicia vazio. GitHub Pages não implanta Express/upload. Pagamentos e links locais reutilizáveis de senha desativados por segurança.
