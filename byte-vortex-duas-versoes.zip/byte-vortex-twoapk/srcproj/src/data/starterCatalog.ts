import heroHandheldImg from '../assets/images/hero_vortex_handheld_1794760330477.jpg';
import emulatorPsImg from '../assets/images/emulator_ps_core_1794760331022.jpg';
import emulatorSnesImg from '../assets/images/emulator_snes_core_1794760331562.jpg';
import gameDriftImg from '../assets/images/game_cyber_drift_1794760332429.jpg';
import gameRpgImg from '../assets/images/game_pixel_odyssey_1794760332947.jpg';
import apkMobileImg from '../assets/images/apk_mobile_showcase_1794760333718.jpg';
import type { AppRelease, CatalogItem } from '../types';

export const HERO_SHOWCASE_IMAGE = heroHandheldImg;
export const APK_SHOWCASE_IMAGE = apkMobileImg;

export const COVER_PRESETS: Array<{ label: string; url: string }> = [
  { label: 'Console Portátil Vortex', url: heroHandheldImg },
  { label: 'Módulo 32-bit PSX', url: emulatorPsImg },
  { label: 'Cartucho 16-bit SNES', url: emulatorSnesImg },
  { label: 'Corrida Arcade Drift', url: gameDriftImg },
  { label: 'RPG Obsidian Citadel', url: gameRpgImg },
  { label: 'Smartphone & Controle APK', url: apkMobileImg },
];

export const DEFAULT_APK_RELEASE: AppRelease = {
  id: 'byte-vortex-apk',
  title: 'Byte Vortex Mobile',
  version: 'Não informado',
  androidMin: 'Confira cada versão',
  fileSize: 'Não informado',
  sha256: 'Não informado',
  freeApkUrl: '',
  freeApkName: 'byte-vortex-free.apk',
  proApkUrl: '',
  proApkName: 'byte-vortex-pro.apk',
  proPriceBrl: 19.9,
  changelog:
    'As versões do aplicativo ainda não estão configuradas nesta página.',
  updatedBy: 'byte-vortex-official',
};
