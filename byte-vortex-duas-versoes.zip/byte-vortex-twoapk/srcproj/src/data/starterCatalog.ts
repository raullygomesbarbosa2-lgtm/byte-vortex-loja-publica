import heroHandheldImg from '../assets/images/hero_vortex_handheld_1794760330477.jpg';
import emulatorPsImg from '../assets/images/emulator_ps_core_1794760331022.jpg';
import emulatorSnesImg from '../assets/images/emulator_snes_core_1794760331562.jpg';
import gameDriftImg from '../assets/images/game_cyber_drift_1794760332429.jpg';
import gameRpgImg from '../assets/images/game_pixel_odyssey_1794760332947.jpg';
import apkMobileImg from '../assets/images/apk_mobile_showcase_1794760333718.jpg';

export const APK_SHOWCASE_IMAGE = apkMobileImg;

export const COVER_PRESETS: Array<{ label: string; url: string }> = [
  { label: 'Capa Hardware Portátil', url: heroHandheldImg },
  { label: 'Capa Console Clássico', url: emulatorPsImg },
  { label: 'Capa Cartucho Retrô', url: emulatorSnesImg },
  { label: 'Capa Corrida Arcade', url: gameDriftImg },
  { label: 'Capa Aventura RPG', url: gameRpgImg },
  { label: 'Capa Mobile e Controle', url: apkMobileImg },
];
