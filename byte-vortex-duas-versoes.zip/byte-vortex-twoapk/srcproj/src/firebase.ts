import { initializeApp } from 'firebase/app';
import {
  createUserWithEmailAndPassword,
  getAuth,
  GoogleAuthProvider,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import type { AppSessionUser } from './types';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const EMAIL_TOKEN_KEY = 'byte_vortex_email_token';

export async function signInWithGoogle(loginHint?: string): Promise<User> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters(
    loginHint
      ? { login_hint: loginHint.trim(), prompt: 'select_account' }
      : { prompt: 'select_account' }
  );
  const result = await signInWithPopup(auth, provider);
  return result.user;
}

function isProviderNotEnabledError(err: unknown): boolean {
  const code = (err as { code?: string })?.code ?? '';
  const msg = err instanceof Error ? err.message : String(err);
  return code === 'auth/operation-not-allowed' || msg.includes('operation-not-allowed');
}

export function getStoredEmailToken(): string | null {
  try {
    return localStorage.getItem(EMAIL_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function clearStoredEmailToken(): void {
  try {
    localStorage.removeItem(EMAIL_TOKEN_KEY);
  } catch {
    // ignore
  }
}

export async function restoreEmailServerSession(): Promise<{
  user: AppSessionUser;
  orders: string[];
} | null> {
  const token = getStoredEmailToken();
  if (!token) return null;

  try {
    const resp = await fetch('/api/email-auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!resp.ok) {
      clearStoredEmailToken();
      return null;
    }
    const data = (await resp.json()) as {
      user: AppSessionUser;
      orders: string[];
    };
    return data;
  } catch {
    return null;
  }
}

export async function saveEmailServerOrders(itemIds: string[]): Promise<string[]> {
  const token = getStoredEmailToken();
  if (!token || itemIds.length === 0) return [];
  try {
    const resp = await fetch('/api/email-auth/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ itemIds }),
    });
    if (!resp.ok) return [];
    const data = (await resp.json()) as { orders?: string[] };
    return Array.isArray(data.orders) ? data.orders : [];
  } catch {
    return [];
  }
}

export async function signInWithEmail(email: string, password: string): Promise<AppSessionUser> {
  const cleanEmail = email.trim();
  try {
    const result = await signInWithEmailAndPassword(auth, cleanEmail, password);
    clearStoredEmailToken();
    return {
      uid: result.user.uid,
      email: result.user.email ?? cleanEmail,
      emailVerified: result.user.emailVerified,
      source: 'firebase',
      firebaseUser: result.user,
    };
  } catch (err) {
    if (!isProviderNotEnabledError(err)) {
      throw err;
    }
  }

  // Pure Email & Password authentication on backend (no Google Sign-In)
  const resp = await fetch('/api/email-auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: cleanEmail, password }),
  });
  const data = (await resp.json()) as {
    token?: string;
    user?: AppSessionUser;
    error?: string;
  };
  if (!resp.ok || !data.token || !data.user) {
    throw new Error(data.error ?? 'Não foi possível entrar com este e-mail.');
  }
  try {
    localStorage.setItem(EMAIL_TOKEN_KEY, data.token);
  } catch {
    // ignore
  }
  return data.user;
}

export async function registerWithEmail(email: string, password: string): Promise<AppSessionUser> {
  const cleanEmail = email.trim();
  try {
    const result = await createUserWithEmailAndPassword(auth, cleanEmail, password);
    await sendEmailVerification(result.user);
    clearStoredEmailToken();
    return {
      uid: result.user.uid,
      email: result.user.email ?? cleanEmail,
      emailVerified: result.user.emailVerified,
      source: 'firebase',
      firebaseUser: result.user,
    };
  } catch (err) {
    if (!isProviderNotEnabledError(err)) {
      throw err;
    }
  }

  // Pure Email & Password registration on backend (no Google Sign-In)
  const resp = await fetch('/api/email-auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: cleanEmail, password }),
  });
  const data = (await resp.json()) as {
    token?: string;
    user?: AppSessionUser;
    error?: string;
  };
  if (!resp.ok || !data.token || !data.user) {
    throw new Error(data.error ?? 'Não foi possível criar a conta com este e-mail.');
  }
  try {
    localStorage.setItem(EMAIL_TOKEN_KEY, data.token);
  } catch {
    // ignore
  }
  return data.user;
}

export async function resendVerificationEmail(user: User): Promise<void> {
  await sendEmailVerification(user);
}

export async function resetPasswordByEmail(email: string): Promise<'email-server' | 'sent'> {
  try {
    await sendPasswordResetEmail(auth, email.trim());
    return 'sent';
  } catch (err) {
    if (isProviderNotEnabledError(err)) {
      return 'email-server';
    }
    throw err;
  }
}

export async function signOutAccount(): Promise<void> {
  clearStoredEmailToken();
  await signOut(auth);
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Verifique a configuração do Firebase.');
    }
  }
}

testConnection();
