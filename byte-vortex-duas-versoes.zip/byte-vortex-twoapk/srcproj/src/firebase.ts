import { initializeApp } from 'firebase/app';
import {
  createUserWithEmailAndPassword,
  getAuth,
  GoogleAuthProvider,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import type { AppSessionUser } from './types';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
auth.languageCode = 'pt-BR';
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const EMAIL_TOKEN_KEY = 'byte_vortex_email_token';
const LOCAL_ACCOUNTS_KEY = 'byte_vortex_local_email_accounts_v1';

interface SafeJsonResult<T> {
  ok: boolean;
  status: number;
  isJson: boolean;
  data: T | null;
}

interface StoredLocalAccount {
  uid: string;
  email: string;
  salt: string;
  passwordHash: string;
  orders: string[];
  createdAt: string;
}

async function safeFetchJson<T>(url: string, init?: RequestInit): Promise<SafeJsonResult<T>> {
  try {
    const resp = await fetch(url, init);
    const text = await resp.text();
    const trimmed = text.trim();
    if (!trimmed || trimmed.startsWith('<')) {
      return { ok: resp.ok, status: resp.status, isJson: false, data: null };
    }
    try {
      const parsed = JSON.parse(trimmed) as T;
      if (parsed && typeof parsed === 'object') {
        return { ok: resp.ok, status: resp.status, isJson: true, data: parsed };
      }
    } catch {
      // Non-JSON payload
    }
    return { ok: resp.ok, status: resp.status, isJson: false, data: null };
  } catch {
    return { ok: false, status: 0, isJson: false, data: null };
  }
}

async function hashLocalSecret(salt: string, password: string): Promise<string> {
  const input = `${salt}:${password}`;
  try {
    if (globalThis.crypto?.subtle) {
      const bytes = new TextEncoder().encode(input);
      const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
      return Array.from(new Uint8Array(digest))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    }
  } catch {
    // Fallback below when subtle crypto is unavailable
  }
  let h1 = 0x811c9dc5;
  let h2 = 0x9e3779b9;
  for (let i = 0; i < input.length; i++) {
    const c = input.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ (c + i), 0x85ebca6b) >>> 0;
  }
  return `${h1.toString(16).padStart(8, '0')}${h2.toString(16).padStart(8, '0')}`;
}

function generateSalt(): string {
  try {
    if (globalThis.crypto?.getRandomValues) {
      const buf = new Uint8Array(12);
      globalThis.crypto.getRandomValues(buf);
      return Array.from(buf)
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    }
  } catch {
    // fallback below
  }
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
}

function readLocalAccounts(): Record<string, StoredLocalAccount> {
  try {
    const raw = localStorage.getItem(LOCAL_ACCOUNTS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, StoredLocalAccount>;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeLocalAccounts(accounts: Record<string, StoredLocalAccount>): void {
  try {
    localStorage.setItem(LOCAL_ACCOUNTS_KEY, JSON.stringify(accounts));
  } catch {
    // ignore storage quota errors
  }
}

async function localRegisterEmail(email: string, password: string): Promise<AppSessionUser> {
  const cleanEmail = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    throw new Error('Informe um endereço de e-mail válido.');
  }
  if (password.length < 6) {
    throw new Error('A senha precisa ter pelo menos 6 caracteres.');
  }
  const accounts = readLocalAccounts();
  if (accounts[cleanEmail]) {
    throw new Error('Este e-mail já está cadastrado. Use a aba Entrar.');
  }
  const uid = `email_${generateSalt().slice(0, 16)}`;
  const salt = generateSalt();
  const passwordHash = await hashLocalSecret(salt, password);
  accounts[cleanEmail] = {
    uid,
    email: cleanEmail,
    salt,
    passwordHash,
    orders: [],
    createdAt: new Date().toISOString(),
  };
  writeLocalAccounts(accounts);
  try {
    localStorage.setItem(EMAIL_TOKEN_KEY, `local:${uid}:${cleanEmail}`);
  } catch {
    // ignore
  }
  return {
    uid,
    email: cleanEmail,
    emailVerified: true,
    source: 'email-server',
  };
}

async function localLoginEmail(email: string, password: string): Promise<AppSessionUser> {
  const cleanEmail = email.trim().toLowerCase();
  if (!cleanEmail || !password) {
    throw new Error('Preencha e-mail e senha.');
  }
  const accounts = readLocalAccounts();
  const record = accounts[cleanEmail];
  if (!record) {
    throw new Error('E-mail ainda não cadastrado. Clique na aba "Criar conta" para registrar.');
  }
  const candidateHash = await hashLocalSecret(record.salt, password);
  if (candidateHash !== record.passwordHash) {
    throw new Error('E-mail ou senha incorretos.');
  }
  try {
    localStorage.setItem(EMAIL_TOKEN_KEY, `local:${record.uid}:${record.email}`);
  } catch {
    // ignore
  }
  return {
    uid: record.uid,
    email: record.email,
    emailVerified: true,
    source: 'email-server',
  };
}

export async function signInWithGoogle(loginHint?: string): Promise<User> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters(
    loginHint
      ? { login_hint: loginHint.trim(), prompt: 'select_account' }
      : { prompt: 'select_account' }
  );
  const result = await signInWithPopup(auth, provider);
  return result.user;
}

function isProviderNotEnabledError(err: unknown): boolean {
  const code = (err as { code?: string })?.code ?? '';
  const msg = err instanceof Error ? err.message : String(err);
  return code === 'auth/operation-not-allowed' || msg.includes('operation-not-allowed');
}

export function getStoredEmailToken(): string | null {
  try {
    return localStorage.getItem(EMAIL_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function clearStoredEmailToken(): void {
  try {
    localStorage.removeItem(EMAIL_TOKEN_KEY);
  } catch {
    // ignore
  }
}

export async function restoreEmailServerSession(): Promise<{
  user: AppSessionUser;
  orders: string[];
} | null> {
  const token = getStoredEmailToken();
  if (!token) return null;

  if (token.startsWith('local:')) {
    const [, uid, ...emailParts] = token.split(':');
    const cleanEmail = emailParts.join(':').toLowerCase();
    const accounts = readLocalAccounts();
    const record = accounts[cleanEmail];
    if (!record || record.uid !== uid) {
      clearStoredEmailToken();
      return null;
    }
    return {
      user: {
        uid: record.uid,
        email: record.email,
        emailVerified: true,
        source: 'email-server',
      },
      orders: Array.isArray(record.orders) ? record.orders : [],
    };
  }

  const res = await safeFetchJson<{
    user: AppSessionUser;
    orders: string[];
  }>('/api/email-auth/me', {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (res.isJson && res.ok && res.data?.user) {
    return res.data;
  }
  if (res.isJson && (res.status === 401 || res.status === 404)) {
    clearStoredEmailToken();
  }
  return null;
}

export async function saveEmailServerOrders(itemIds: string[]): Promise<string[]> {
  const token = getStoredEmailToken();
  if (!token || itemIds.length === 0) return [];

  if (token.startsWith('local:')) {
    const [, uid, ...emailParts] = token.split(':');
    const cleanEmail = emailParts.join(':').toLowerCase();
    const accounts = readLocalAccounts();
    const record = accounts[cleanEmail];
    if (!record || record.uid !== uid) return [];
    record.orders = Array.from(new Set([...(record.orders ?? []), ...itemIds]));
    writeLocalAccounts(accounts);
    return record.orders;
  }

  const res = await safeFetchJson<{ orders?: string[] }>('/api/email-auth/orders', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ itemIds }),
  });

  if (res.isJson && res.ok && Array.isArray(res.data?.orders)) {
    return res.data.orders;
  }
  return [];
}

export async function signInWithEmail(email: string, password: string): Promise<AppSessionUser> {
  const cleanEmail = email.trim();
  try {
    const result = await signInWithEmailAndPassword(auth, cleanEmail, password);
    clearStoredEmailToken();
    return {
      uid: result.user.uid,
      email: result.user.email ?? cleanEmail,
      emailVerified: result.user.emailVerified,
      source: 'firebase',
      firebaseUser: result.user,
    };
  } catch (err) {
    if (!isProviderNotEnabledError(err)) {
      throw err;
    }
  }

  // Pure Email & Password authentication on backend (no Google Sign-In)
  const res = await safeFetchJson<{
    token?: string;
    user?: AppSessionUser;
    error?: string;
  }>('/api/email-auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: cleanEmail, password }),
  });

  if (res.isJson) {
    if (!res.ok || !res.data?.token || !res.data?.user) {
      throw new Error(res.data?.error ?? 'Não foi possível entrar com este e-mail.');
    }
    try {
      localStorage.setItem(EMAIL_TOKEN_KEY, res.data.token);
    } catch {
      // ignore
    }
    return res.data.user;
  }

  // Fallback when running as static/shared SPA where /api/* returns HTML
  return await localLoginEmail(cleanEmail, password);
}

export async function registerWithEmail(email: string, password: string): Promise<AppSessionUser> {
  const cleanEmail = email.trim();
  try {
    const result = await createUserWithEmailAndPassword(auth, cleanEmail, password);
    await sendEmailVerification(result.user);
    clearStoredEmailToken();
    return {
      uid: result.user.uid,
      email: result.user.email ?? cleanEmail,
      emailVerified: result.user.emailVerified,
      source: 'firebase',
      firebaseUser: result.user,
    };
  } catch (err) {
    if (!isProviderNotEnabledError(err)) {
      throw err;
    }
  }

  // Pure Email & Password registration on backend (no Google Sign-In)
  const res = await safeFetchJson<{
    token?: string;
    user?: AppSessionUser;
    error?: string;
  }>('/api/email-auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: cleanEmail, password }),
  });

  if (res.isJson) {
    if (!res.ok || !res.data?.token || !res.data?.user) {
      throw new Error(res.data?.error ?? 'Não foi possível criar a conta com este e-mail.');
    }
    try {
      localStorage.setItem(EMAIL_TOKEN_KEY, res.data.token);
    } catch {
      // ignore
    }
    return res.data.user;
  }

  // Fallback when running as static/shared SPA where /api/* returns HTML
  return await localRegisterEmail(cleanEmail, password);
}

export async function resendVerificationEmail(user: User): Promise<void> {
  await sendEmailVerification(user);
}

export async function resetPasswordByEmail(email: string): Promise<'email-server' | 'sent'> {
  const cleanEmail = email.trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    throw new Error('Informe um endereço de e-mail válido.');
  }
  auth.languageCode = 'pt-BR';
  try {
    await sendPasswordResetEmail(auth, cleanEmail);
    return 'sent';
  } catch (err) {
    if (isProviderNotEnabledError(err)) {
      return 'email-server';
    }
    throw err;
  }
}

export async function signOutAccount(): Promise<void> {
  clearStoredEmailToken();
  await signOut(auth);
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Verifique a configuração do Firebase.');
    }
  }
}

testConnection();
