export function formatBrl(value: number): string {
  if (!Number.isFinite(value) || value <= 0) {
    return 'Grátis';
  }
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

export const PRO_DISCOUNT_RATE = 0.10;

export function discountedProPrice(originalPrice: number): number {
  if (!Number.isFinite(originalPrice) || originalPrice <= 0) return 0;
  return Math.round(originalPrice * (1 - PRO_DISCOUNT_RATE) * 100) / 100;
}

export function triggerFileDownload(url: string, fileName?: string): void {
  if (!url) return;
  const link = document.createElement('a');
  link.href = url;
  if (fileName) {
    link.download = fileName;
  }
  link.rel = 'noopener noreferrer';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function slugifyId(input: string): string {
  const cleaned = input
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
  const suffix = Math.random().toString(36).slice(2, 6);
  return `${cleaned || 'item'}-${suffix}`;
}

export function sanitizeItemPayload(input: {
  title: string;
  subtitle: string;
  description: string;
  category: 'emulator' | 'game' | 'apk';
  platform: string;
  version: string;
  fileSize: string;
  coverUrl: string;
  accessModel: 'free' | 'paid' | 'freemium';
  priceBrl: number;
  freeDownloadUrl: string;
  freeFileName: string;
  paidDownloadUrl: string;
  paidFileName: string;
  features: string[];
  featured: boolean;
}) {
  const accessModel = input.accessModel;
  const normalizedPrice =
    accessModel === 'free'
      ? 0
      : Math.min(9999, Math.max(1, Number(input.priceBrl.toFixed(2))));

  const features = input.features
    .map((f) => f.trim().slice(0, 120))
    .filter((f) => f.length > 0)
    .slice(0, 8);

  return {
    title: input.title.trim().slice(0, 100),
    subtitle: input.subtitle.trim().slice(0, 160),
    description: input.description.trim().slice(0, 2000),
    category: input.category,
    platform: input.platform.trim().slice(0, 40),
    version: input.version.trim().slice(0, 30),
    fileSize: input.fileSize.trim().slice(0, 30),
    coverUrl: input.coverUrl.trim().slice(0, 1000),
    accessModel,
    priceBrl: normalizedPrice,
    freeDownloadUrl:
      accessModel === 'paid' ? '' : input.freeDownloadUrl.trim().slice(0, 1000),
    freeFileName:
      accessModel === 'paid' ? '' : input.freeFileName.trim().slice(0, 160),
    paidDownloadUrl:
      accessModel === 'free' ? '' : input.paidDownloadUrl.trim().slice(0, 1000),
    paidFileName:
      accessModel === 'free' ? '' : input.paidFileName.trim().slice(0, 160),
    features,
    featured: Boolean(input.featured),
  };
}
