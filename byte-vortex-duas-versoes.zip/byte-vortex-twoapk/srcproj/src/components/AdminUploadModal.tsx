import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { Check, Copy, KeyRound, Lock, LogOut, Mail, RefreshCw, Upload, UserCheck, X } from 'lucide-react';
import type { User } from 'firebase/auth';
import { COVER_PRESETS } from '../data/starterCatalog';
import { formatGoogleAuthError } from '../firebase';
import {
  ADMIN_EMAIL,
  type AccessModel,
  type AppRelease,
  type AppSessionUser,
  type CatalogCategory,
  type CatalogItem,
} from '../types';
import { sanitizeItemPayload, slugifyId } from '../utils/formatters';

interface AdminUploadModalProps {
  isOpen: boolean;
  initialTab: 'catalog' | 'apk';
  user: AppSessionUser | null;
  isAdmin: boolean;
  editingItem: CatalogItem | null;
  currentApkRelease: AppRelease | null;
  syncedCount?: number;
  pendingReset?:
    | { kind: 'unlimited'; email: string; token: string }
    | { kind: 'firebase'; email: string; oobCode: string }
    | null;
  onClearPendingReset?: () => void;
  onClose: () => void;
  onSignInGoogle: () => Promise<void>;
  onSignInEmail: (email: string, password: string) => Promise<void>;
  onRegisterEmail: (email: string, password: string) => Promise<void>;
  onCreateUnlimitedResetLink: (
    email: string
  ) => Promise<{ email: string; resetToken: string; resetUrl: string }>;
  onConfirmUnlimitedReset: (email: string, token: string, newPassword: string) => Promise<void>;
  onConfirmFirebaseReset: (oobCode: string, newPassword: string) => Promise<void>;
  onResetPassword: (email: string) => Promise<'email-server' | 'sent'>;
  onResendVerification: (user: User) => Promise<void>;
  onRefreshUser: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onSaveCatalogItem: (
    id: string,
    data: ReturnType<typeof sanitizeItemPayload>,
    isNew: boolean
  ) => Promise<void>;
  onSaveApkRelease: (release: Omit<AppRelease, 'id' | 'updatedAt'>) => Promise<void>;
}

async function uploadFileToServer(
  file: File,
  user: User
): Promise<{ url: string; fileName: string; sizeFormatted: string }> {
  const token = await user.getIdToken();
  const base64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Erro ao ler arquivo selecionado.'));
    reader.readAsDataURL(file);
  });

  const resp = await fetch('/api/upload', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      fileName: file.name,
      dataBase64: base64,
    }),
  });

  const text = await resp.text();
  const trimmed = text.trim();
  type UploadResponse = {
    url?: string;
    fileName?: string;
    sizeFormatted?: string;
    error?: string;
  };
  let data: UploadResponse | null = null;

  if (trimmed && !trimmed.startsWith('<')) {
    try {
      data = JSON.parse(trimmed) as UploadResponse;
    } catch {
      data = null;
    }
  }

  if (!data) {
    throw new Error(
      'O envio direto de arquivos não está disponível neste endereço. Cole um link direto de download (Google Drive, MediaFire ou link direto HTTPS) no campo de URL abaixo.'
    );
  }

  if (!resp.ok || !data.url || !data.fileName) {
    throw new Error(data.error ?? 'Falha ao enviar arquivo.');
  }

  return {
    url: data.url,
    fileName: data.fileName,
    sizeFormatted: data.sizeFormatted ?? '1.0 MB',
  };
}

function formatAuthError(err: unknown): string {
  const code = (err as { code?: string })?.code ?? '';
  const msg = err instanceof Error ? err.message : String(err);
  if (code === 'auth/popup-closed-by-user' || msg.includes('popup-closed-by-user')) {
    return '';
  }
  if (code === 'auth/popup-blocked' || msg.includes('popup-blocked')) {
    return 'O navegador bloqueou a janela de login. Permita pop-ups e tente novamente.';
  }
  if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password')) {
    return 'E-mail ou senha incorretos.';
  }
  if (msg.includes('auth/user-not-found')) {
    return 'Conta não encontrada. Crie uma conta com este e-mail primeiro.';
  }
  if (msg.includes('auth/email-already-in-use')) {
    return 'Este e-mail já está cadastrado. Faça login na aba Entrar ou use Recuperar senha.';
  }
  if (msg.includes('auth/weak-password')) {
    return 'A senha precisa ter pelo menos 6 caracteres.';
  }
  if (msg.includes('auth/invalid-email')) {
    return 'Informe um endereço de e-mail válido.';
  }
  if (msg.includes('auth/too-many-requests')) {
    return 'Muitas solicitações seguidas. Aguarde alguns minutos antes de pedir outro link.';
  }
  if (msg.includes('auth/expired-action-code') || msg.includes('auth/invalid-action-code')) {
    return 'Esse link de recuperação já expirou ou já foi usado. Solicite um novo link e abra apenas o e-mail mais recente.';
  }
  if (msg.includes('is not valid JSON') || msg.includes('Unexpected token') || msg.includes('<html')) {
    return 'Não foi possível conectar ao serviço de e-mail. Tente novamente ou use a aba Criar conta.';
  }
  return msg || 'Não foi possível concluir o acesso agora. Tente novamente.';
}

function GoogleIcon() {
  return (
    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
      />
      <path
        fill="#FBBC05"
        d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
      />
    </svg>
  );
}

export function AdminUploadModal({
  isOpen,
  initialTab,
  user,
  isAdmin,
  editingItem,
  currentApkRelease,
  syncedCount = 0,
  pendingReset = null,
  onClearPendingReset,
  onClose,
  onSignInGoogle,
  onSignInEmail,
  onRegisterEmail,
  onCreateUnlimitedResetLink,
  onConfirmUnlimitedReset,
  onConfirmFirebaseReset,
  onResetPassword,
  onResendVerification,
  onRefreshUser,
  onSignOut,
  onSaveCatalogItem,
  onSaveApkRelease,
}: AdminUploadModalProps) {
  const [tab, setTab] = useState<'catalog' | 'apk'>(initialTab);
  const [busy, setBusy] = useState(false);
  const [uploadingField, setUploadingField] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Email Auth state
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'reset'>('login');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [authBusy, setAuthBusy] = useState(false);
  const [resetCooldown, setResetCooldown] = useState(0);
  const [authNotice, setAuthNotice] = useState('');
  const [authError, setAuthError] = useState('');
  const [googleError, setGoogleError] = useState('');
  const [generatedReset, setGeneratedReset] = useState<{
    email: string;
    resetToken: string;
    resetUrl: string;
  } | null>(null);
  const [copiedReset, setCopiedReset] = useState(false);
  const [activeReset, setActiveReset] = useState<
    | { kind: 'unlimited'; email: string; token: string }
    | { kind: 'firebase'; email: string; oobCode: string }
    | null
  >(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');

  // Catalog form state
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<CatalogCategory>('emulator');
  const [platform, setPlatform] = useState('Android · PC');
  const [version, setVersion] = useState('v1.0.0');
  const [fileSize, setFileSize] = useState('20.0 MB');
  const [coverUrl, setCoverUrl] = useState(COVER_PRESETS[0].url);
  const [accessModel, setAccessModel] = useState<AccessModel>('freemium');
  const [priceBrl, setPriceBrl] = useState('19.90');
  const [freeDownloadUrl, setFreeDownloadUrl] = useState('');
  const [freeFileName, setFreeFileName] = useState('');
  const [paidDownloadUrl, setPaidDownloadUrl] = useState('');
  const [paidFileName, setPaidFileName] = useState('');
  const [featuresText, setFeaturesText] = useState(
    'Compatível com controles Bluetooth\nSuporte direto no Byte Vortex APK'
  );
  const [featured, setFeatured] = useState(true);

  // APK release form state
  const [apkTitle, setApkTitle] = useState(currentApkRelease?.title ?? 'Byte Vortex Mobile');
  const [apkVersion, setApkVersion] = useState(currentApkRelease?.version ?? 'v1.0.0');
  const [apkAndroidMin, setApkAndroidMin] = useState(
    currentApkRelease?.androidMin ?? 'Android 9.0 ou superior'
  );
  const [apkSize, setApkSize] = useState(currentApkRelease?.fileSize ?? '');
  const [apkSha, setApkSha] = useState(currentApkRelease?.sha256 ?? '');
  const [apkFreeUrl, setApkFreeUrl] = useState(currentApkRelease?.freeApkUrl ?? '');
  const [apkFreeName, setApkFreeName] = useState(currentApkRelease?.freeApkName ?? 'byte-vortex-free.apk');
  const [apkProUrl, setApkProUrl] = useState(currentApkRelease?.proApkUrl ?? '');
  const [apkProName, setApkProName] = useState(currentApkRelease?.proApkName ?? 'byte-vortex-pro.apk');
  const [apkProPrice, setApkProPrice] = useState(
    currentApkRelease ? String(currentApkRelease.proPriceBrl) : '19.90'
  );
  const [apkChangelog, setApkChangelog] = useState(currentApkRelease?.changelog ?? '');

  useEffect(() => {
    setTab(initialTab);
    setErrorMsg('');
    setStatusMsg('');
    setAuthError('');
    setAuthNotice('');
    setGoogleError('');
    setGeneratedReset(null);
    setCopiedReset(false);
    if (pendingReset) {
      setActiveReset(pendingReset);
      setNewPasswordInput('');
      setConfirmPasswordInput('');
    } else {
      setActiveReset(null);
    }
  }, [initialTab, isOpen, pendingReset]);

  useEffect(() => {
    if (resetCooldown <= 0) return;
    const timer = setTimeout(() => setResetCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearTimeout(timer);
  }, [resetCooldown]);

  useEffect(() => {
    if (editingItem) {
      setTab('catalog');
      setTitle(editingItem.title);
      setSubtitle(editingItem.subtitle);
      setDescription(editingItem.description);
      setCategory(editingItem.category);
      setPlatform(editingItem.platform);
      setVersion(editingItem.version);
      setFileSize(editingItem.fileSize);
      setCoverUrl(editingItem.coverUrl);
      setAccessModel(editingItem.accessModel);
      setPriceBrl(String(editingItem.priceBrl || 19.9));
      setFreeDownloadUrl(editingItem.freeDownloadUrl);
      setFreeFileName(editingItem.freeFileName);
      setPaidDownloadUrl(editingItem.paidDownloadUrl);
      setPaidFileName(editingItem.paidFileName);
      setFeaturesText(editingItem.features.join('\n'));
      setFeatured(editingItem.featured);
    } else {
      setTitle('');
      setSubtitle('');
      setDescription('');
      setCategory('emulator');
      setPlatform('Android · PC');
      setVersion('v1.0.0');
      setFileSize('20.0 MB');
      setCoverUrl(COVER_PRESETS[0].url);
      setAccessModel('freemium');
      setPriceBrl('19.90');
      setFreeDownloadUrl('');
      setFreeFileName('');
      setPaidDownloadUrl('');
      setPaidFileName('');
      setFeaturesText('Compatível com controles Bluetooth\nSuporte direto no Byte Vortex APK');
      setFeatured(true);
    }
  }, [editingItem, isOpen]);

  useEffect(() => {
    setApkTitle(currentApkRelease?.title ?? 'Byte Vortex Mobile');
    setApkVersion(currentApkRelease?.version ?? 'v1.0.0');
    setApkAndroidMin(currentApkRelease?.androidMin ?? 'Android 9.0 ou superior');
    setApkSize(currentApkRelease?.fileSize ?? '');
    setApkSha(currentApkRelease?.sha256 ?? '');
    setApkFreeUrl(currentApkRelease?.freeApkUrl ?? '');
    setApkFreeName(currentApkRelease?.freeApkName ?? 'byte-vortex-free.apk');
    setApkProUrl(currentApkRelease?.proApkUrl ?? '');
    setApkProName(currentApkRelease?.proApkName ?? 'byte-vortex-pro.apk');
    setApkProPrice(currentApkRelease ? String(currentApkRelease.proPriceBrl) : '19.90');
    setApkChangelog(currentApkRelease?.changelog ?? '');
  }, [currentApkRelease, isOpen]);

  if (!isOpen) return null;

  const handleEmailAuthSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthNotice('');
    setAuthBusy(true);

    try {
      if (authMode === 'login') {
        await onSignInEmail(emailInput, passwordInput);
      } else if (authMode === 'register') {
        await onRegisterEmail(emailInput, passwordInput);
        setAuthNotice('Conta criada e conectada com sucesso.');
      } else {
        const res = await onResetPassword(emailInput);
        if (res === 'email-server') {
          const result = await onCreateUnlimitedResetLink(emailInput);
          setGeneratedReset(result);
          setAuthNotice(
            `Link ilimitado gerado para ${result.email}. Este link nunca expira.`
          );
        } else {
          setResetCooldown(30);
          setAuthNotice(
            `E-mail de recuperação enviado para ${emailInput.trim()}. Abra apenas o e-mail mais recente (confira também Spam/Promoções).`
          );
        }
      }
    } catch (err) {
      const friendly = formatAuthError(err);
      if (friendly) setAuthError(friendly);
    } finally {
      setAuthBusy(false);
    }
  };

  const handleConfirmNewPassword = async (e: FormEvent) => {
    e.preventDefault();
    if (!activeReset) return;
    setAuthError('');
    setAuthNotice('');

    if (newPasswordInput.length < 6) {
      setAuthError('A nova senha precisa ter pelo menos 6 caracteres.');
      return;
    }
    if (newPasswordInput !== confirmPasswordInput) {
      setAuthError('As duas senhas digitadas não coincidem.');
      return;
    }

    setAuthBusy(true);
    try {
      if (activeReset.kind === 'firebase') {
        await onConfirmFirebaseReset(activeReset.oobCode, newPasswordInput);
      } else {
        await onConfirmUnlimitedReset(activeReset.email, activeReset.token, newPasswordInput);
      }
      setActiveReset(null);
      setGeneratedReset(null);
      setNewPasswordInput('');
      setConfirmPasswordInput('');
      onClearPendingReset?.();
      setAuthNotice('Nova senha salva e conta conectada com sucesso.');
    } catch (err) {
      const friendly = formatAuthError(err);
      if (friendly) setAuthError(friendly);
    } finally {
      setAuthBusy(false);
    }
  };

  const handleGenerateUnlimitedLink = async () => {
    setAuthError('');
    setAuthNotice('');
    setAuthBusy(true);
    try {
      const result = await onCreateUnlimitedResetLink(emailInput);
      setGeneratedReset(result);
      setAuthNotice(
        `Link ilimitado criado para ${result.email}. Este link nunca expira e pode ser aberto quantas vezes precisar.`
      );
    } catch (err) {
      const friendly = formatAuthError(err);
      if (friendly) setAuthError(friendly);
    } finally {
      setAuthBusy(false);
    }
  };

  const handleGoogleSignInClick = async () => {
    setAuthError('');
    setAuthNotice('');
    setGoogleError('');
    setAuthBusy(true);
    try {
      await onSignInGoogle();
    } catch (err) {
      const details = formatGoogleAuthError(err);
      if (details.message) {
        setGoogleError(details.message);
      }
    } finally {
      setAuthBusy(false);
    }
  };

  const handleFilePicked = async (
    e: ChangeEvent<HTMLInputElement>,
    target: 'free' | 'paid' | 'cover' | 'apkFree' | 'apkPro'
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !user?.firebaseUser) return;

    setErrorMsg('');
    setStatusMsg('');
    setUploadingField(target);

    try {
      const uploaded = await uploadFileToServer(file, user.firebaseUser);
      if (target === 'free') {
        setFreeDownloadUrl(uploaded.url);
        setFreeFileName(uploaded.fileName);
        setFileSize(uploaded.sizeFormatted);
      } else if (target === 'paid') {
        setPaidDownloadUrl(uploaded.url);
        setPaidFileName(uploaded.fileName);
        setFileSize(uploaded.sizeFormatted);
      } else if (target === 'cover') {
        setCoverUrl(uploaded.url);
      } else if (target === 'apkFree') {
        setApkFreeUrl(uploaded.url);
        setApkFreeName(uploaded.fileName);
        setApkSize(uploaded.sizeFormatted);
      } else if (target === 'apkPro') {
        setApkProUrl(uploaded.url);
        setApkProName(uploaded.fileName);
      }
      setStatusMsg(`Arquivo "${uploaded.fileName}" enviado com sucesso.`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Erro no upload do arquivo.');
    } finally {
      setUploadingField(null);
    }
  };

  const handleCatalogSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setStatusMsg('');

    if (title.trim().length < 2 || subtitle.trim().length < 2 || description.trim().length < 10) {
      setErrorMsg('Preencha título, subtítulo e uma descrição com pelo menos 10 caracteres.');
      return;
    }

    if (accessModel !== 'paid' && !freeDownloadUrl.trim()) {
      setErrorMsg('Envie o arquivo da versão gratuita ou informe a URL de download.');
      return;
    }

    if (accessModel !== 'free' && !paidDownloadUrl.trim()) {
      setErrorMsg('Envie o arquivo da versão paga Pro ou informe a URL de download.');
      return;
    }

    setBusy(true);
    try {
      const payload = sanitizeItemPayload({
        title,
        subtitle,
        description,
        category,
        platform,
        version,
        fileSize,
        coverUrl,
        accessModel,
        priceBrl: Number(priceBrl.replace(',', '.')) || 0,
        freeDownloadUrl,
        freeFileName: freeFileName || `${slugifyId(title)}-free.zip`,
        paidDownloadUrl,
        paidFileName: paidFileName || `${slugifyId(title)}-pro.zip`,
        features: featuresText.split('\n'),
        featured,
      });

      const targetId = editingItem ? editingItem.id : slugifyId(title);
      await onSaveCatalogItem(targetId, payload, !editingItem);
      setStatusMsg('Item publicado no catálogo público com sucesso.');
      setTimeout(() => onClose(), 800);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Erro ao salvar no catálogo.');
    } finally {
      setBusy(false);
    }
  };

  const handleApkSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setStatusMsg('');

    if (!user) return;
    setBusy(true);
    try {
      await onSaveApkRelease({
        title: apkTitle.trim().slice(0, 100),
        version: apkVersion.trim().slice(0, 30),
        androidMin: apkAndroidMin.trim().slice(0, 40),
        fileSize: apkSize.trim().slice(0, 30),
        sha256: apkSha.trim().slice(0, 128),
        freeApkUrl: apkFreeUrl.trim().slice(0, 1000),
        freeApkName: apkFreeName.trim().slice(0, 160),
        proApkUrl: apkProUrl.trim().slice(0, 1000),
        proApkName: apkProName.trim().slice(0, 160),
        proPriceBrl: Math.max(1, Number(apkProPrice.replace(',', '.')) || 19.9),
        changelog: apkChangelog.trim().slice(0, 1500),
        updatedBy: user.uid,
      });
      setStatusMsg('Versão oficial do APK atualizada com sucesso.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Erro ao atualizar APK.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-modal-title"
    >
      <div className="w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-[#16181F] border border-white/15 rounded-xl">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <Lock className="w-4 h-4 text-[#D93811]" aria-hidden="true" />
            <h2 id="admin-modal-title" className="font-display text-lg font-bold text-[#F4F5F7]">
              {isAdmin ? 'Painel Admin' : user ? 'Minha Conta' : 'Entrar na Conta'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela"
            className="p-2 rounded-lg text-[#A3AAB8] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auth Gate & Unlimited Password Reset */}
        {activeReset ? (
          <div className="p-6 sm:p-8 space-y-5 max-w-md mx-auto">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-xl bg-[#1F222C] border border-white/10 mx-auto flex items-center justify-center">
                <KeyRound className="w-6 h-6 text-[#D93811]" aria-hidden="true" />
              </div>
              <h3 className="font-display text-xl font-bold text-white">
                Definir Nova Senha
              </h3>
              <p className="text-xs text-[#A3AAB8] leading-relaxed">
                {activeReset.kind === 'firebase' ? (
                  <>
                    Defina a nova senha para <span className="font-mono text-white">{activeReset.email}</span>.
                  </>
                ) : (
                  <>
                    Redefinição ilimitada para <span className="font-mono text-white">{activeReset.email}</span>. Este link nunca expira.
                  </>
                )}
              </p>
            </div>

            <form onSubmit={handleConfirmNewPassword} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-[#D1D5DB] mb-1">
                  Nova senha
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={newPasswordInput}
                  onChange={(e) => setNewPasswordInput(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#D1D5DB] mb-1">
                  Confirmar nova senha
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={confirmPasswordInput}
                  onChange={(e) => setConfirmPasswordInput(e.target.value)}
                  placeholder="Repita a nova senha"
                  className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                />
              </div>

              {authError && (
                <p
                  className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-xs text-red-200"
                  role="alert"
                >
                  {authError}
                </p>
              )}

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setActiveReset(null);
                    setAuthError('');
                    onClearPendingReset?.();
                  }}
                  className="px-4 py-2.5 min-h-[42px] rounded-lg bg-[#1A1D26] hover:bg-[#232632] text-xs font-semibold text-[#D1D5DB] cursor-pointer"
                >
                  Voltar
                </button>
                <button
                  type="submit"
                  disabled={authBusy}
                  className="flex-1 py-2.5 px-4 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] disabled:opacity-60 text-xs font-semibold text-white cursor-pointer"
                >
                  {authBusy ? 'Salvando...' : 'Salvar Nova Senha e Entrar'}
                </button>
              </div>
            </form>
          </div>
        ) : !user ? (
          <div className="p-6 sm:p-8 space-y-6">
            <div className="max-w-lg mx-auto space-y-2 text-center">
              <h3 className="font-display text-xl font-bold text-white">
                Entrar com sua conta Google
              </h3>
              <p className="text-sm text-[#A3AAB8] leading-relaxed">
                Toque no botão abaixo para escolher sua conta do Google. Suas compras ficam salvas na nuvem mesmo se você trocar ou formatar o celular, e o painel Admin é liberado automaticamente ao entrar com{' '}
                <span className="font-mono text-white">{ADMIN_EMAIL}</span>.
              </p>
            </div>

            <div className="max-w-md mx-auto space-y-4">
              <button
                type="button"
                disabled={authBusy}
                onClick={handleGoogleSignInClick}
                className="w-full inline-flex items-center justify-center gap-3 px-6 py-3 min-h-[46px] rounded-lg bg-white hover:bg-[#F3F4F6] border border-white/20 disabled:opacity-60 text-sm font-semibold text-[#111318] transition-colors cursor-pointer"
              >
                <GoogleIcon />
                <span>{authBusy ? 'Abrindo Google...' : 'Continuar com Google'}</span>
              </button>

              {googleError ? (
                <p
                  className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-xs text-red-200 text-center"
                  role="alert"
                >
                  {googleError}
                </p>
              ) : null}
            </div>
          </div>
        ) : !user.emailVerified ? (
          <div className="p-8 text-center space-y-5 max-w-lg mx-auto">
            <div className="w-12 h-12 rounded-xl bg-[#1F222C] border border-white/10 mx-auto flex items-center justify-center">
              <Mail className="w-6 h-6 text-[#D93811]" aria-hidden="true" />
            </div>
            <div className="space-y-2">
              <h3 className="font-display text-xl font-bold text-white">
                Confirme seu e-mail
              </h3>
              <p className="text-sm text-[#A3AAB8] leading-relaxed">
                Você entrou como <span className="font-mono text-white">{user.email}</span>, mas o e-mail ainda não foi verificado. Clique no link enviado para sua caixa de entrada e depois atualize abaixo.
              </p>
            </div>
            {authNotice && (
              <p className="p-3 rounded-lg bg-emerald-950/50 border border-emerald-500/30 text-xs text-emerald-200">
                {authNotice}
              </p>
            )}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={async () => {
                  await onRefreshUser();
                }}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" aria-hidden="true" />
                <span>Já confirmei, atualizar</span>
              </button>
              <button
                type="button"
                onClick={async () => {
                  if (user.firebaseUser) {
                    await onResendVerification(user.firebaseUser);
                    setAuthNotice('Novo e-mail de verificação enviado.');
                  }
                }}
                className="px-4 py-2.5 rounded-lg bg-[#232632] hover:bg-[#2F3342] text-xs font-semibold text-white cursor-pointer"
              >
                Reenviar verificação
              </button>
              <button
                type="button"
                onClick={onSignOut}
                className="px-4 py-2.5 rounded-lg bg-[#1A1D26] hover:bg-[#232632] text-xs font-medium text-[#D1D5DB] cursor-pointer"
              >
                Sair
              </button>
            </div>
          </div>
        ) : !isAdmin ? (
          user.email.toLowerCase() === ADMIN_EMAIL && user.source !== 'firebase' ? (
            <div className="p-8 text-center space-y-5">
              <div className="w-12 h-12 rounded-xl bg-[#1F222C] border border-white/10 mx-auto flex items-center justify-center">
                <UserCheck className="w-6 h-6 text-[#F4F5F7]" aria-hidden="true" />
              </div>
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="font-display text-xl font-bold text-white">
                  E-mail conectado — falta validar upload no Firebase
                </h3>
                <p className="text-sm text-[#A3AAB8] leading-relaxed">
                  Você entrou com <span className="font-mono text-white">{user.email}</span> no modo e-mail. Para liberar o envio público no catálogo do Firebase, entre com o Google abaixo ou ative o login por E-mail/Senha no Firebase Console.
                </p>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  disabled={authBusy}
                  onClick={handleGoogleSignInClick}
                  className="inline-flex items-center justify-center gap-2.5 px-5 py-2.5 min-h-[42px] rounded-lg bg-white hover:bg-[#F3F4F6] disabled:opacity-60 text-sm font-semibold text-[#111318] transition-colors cursor-pointer"
                >
                  <GoogleIcon />
                  <span>Continuar com Google</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 min-h-[42px] rounded-lg bg-[#232632] hover:bg-[#2F3342] text-sm font-semibold text-white transition-colors cursor-pointer"
                >
                  Continuar na Loja
                </button>
                <button
                  type="button"
                  onClick={onSignOut}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[42px] rounded-lg bg-[#1A1D26] hover:bg-[#232632] text-sm font-semibold text-[#D1D5DB] transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" aria-hidden="true" />
                  <span>Sair</span>
                </button>
              </div>
              {googleError ? (
                <p
                  className="max-w-md mx-auto p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-xs text-red-200"
                  role="alert"
                >
                  {googleError}
                </p>
              ) : null}
            </div>
          ) : (
            <div className="p-8 text-center space-y-5">
              <div className="w-12 h-12 rounded-xl bg-[#1F222C] border border-white/10 mx-auto flex items-center justify-center">
                <UserCheck className="w-6 h-6 text-[#F4F5F7]" aria-hidden="true" />
              </div>
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="font-display text-xl font-bold text-white">
                  Conta conectada na nuvem
                </h3>
                <p className="text-sm text-[#A3AAB8] leading-relaxed">
                  Você entrou como <span className="font-mono text-white">{user.email}</span> ({syncedCount} licença{syncedCount === 1 ? '' : 's'} Pro sincronizada{syncedCount === 1 ? '' : 's'} na nuvem). Mesmo que você formate ou troque de celular, basta entrar novamente com esta conta para recuperar tudo.
                </p>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-sm font-semibold text-white transition-colors cursor-pointer"
                >
                  Continuar na Loja
                </button>
                <button
                  type="button"
                  onClick={onSignOut}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[42px] rounded-lg bg-[#232632] hover:bg-[#2F3342] text-sm font-semibold text-white transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" aria-hidden="true" />
                  <span>Trocar de conta</span>
                </button>
              </div>
            </div>
          )
        ) : (
          <div className="p-6 space-y-6">
            {/* Authenticated Admin Header Bar */}
            <div className="p-3.5 rounded-xl bg-[#111318] border border-white/10 flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs">
                <span className="text-[#9CA3AF]">Administrador autenticado: </span>
                <span className="font-mono text-white font-medium">{user.email}</span>
              </div>

              <button
                type="button"
                onClick={onSignOut}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232632] hover:bg-[#303444] text-xs font-medium text-[#D1D5DB] cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sair</span>
              </button>
            </div>

            {/* Admin Tabs */}
            <div className="flex items-center gap-1 p-1 bg-[#111318] border border-white/10 rounded-lg w-fit">
              <button
                type="button"
                onClick={() => setTab('catalog')}
                className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                  tab === 'catalog' ? 'bg-[#D93811] text-white' : 'text-[#A3AAB8] hover:text-white'
                }`}
              >
                {editingItem ? 'Editar Item' : 'Upload de Emulador / Jogo'}
              </button>
              <button
                type="button"
                onClick={() => setTab('apk')}
                className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                  tab === 'apk' ? 'bg-[#D93811] text-white' : 'text-[#A3AAB8] hover:text-white'
                }`}
              >
                Gerenciar Byte Vortex APK
              </button>
            </div>

            {statusMsg && (
              <div className="p-3 rounded-lg bg-emerald-950/50 border border-emerald-500/30 text-xs font-medium text-emerald-200">
                {statusMsg}
              </div>
            )}
            {errorMsg && (
              <div
                className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-xs font-medium text-red-200"
                role="alert"
              >
                {errorMsg}
              </div>
            )}

            {tab === 'catalog' ? (
              <form onSubmit={handleCatalogSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Nome do Emulador ou Jogo *
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={100}
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Digite o nome do emulador ou jogo"
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Categoria *
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as CatalogCategory)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    >
                      <option value="emulator">Emulador</option>
                      <option value="game">Jogo</option>
                      <option value="apk">Utilitário APK</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Subtítulo curto *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={160}
                    value={subtitle}
                    onChange={(e) => setSubtitle(e.target.value)}
                    placeholder="Resumo curto do emulador ou jogo"
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Plataforma
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={40}
                      value={platform}
                      onChange={(e) => setPlatform(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Versão
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={30}
                      value={version}
                      onChange={(e) => setVersion(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Tamanho
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={30}
                      value={fileSize}
                      onChange={(e) => setFileSize(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Modelo de Acesso (Grátis / Pago)
                    </label>
                    <select
                      value={accessModel}
                      onChange={(e) => setAccessModel(e.target.value as AccessModel)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    >
                      <option value="freemium">Versão Gratuita + Versão Paga (Pro)</option>
                      <option value="free">Somente Gratuito</option>
                      <option value="paid">Somente Pago (Pro)</option>
                    </select>
                  </div>
                  {accessModel !== 'free' && (
                    <div>
                      <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                        Preço da Versão Pro (R$)
                      </label>
                      <input
                        type="number"
                        step="0.10"
                        min="1"
                        max="9999"
                        required
                        value={priceBrl}
                        onChange={(e) => setPriceBrl(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                      />
                    </div>
                  )}
                </div>

                {accessModel !== 'paid' && (
                  <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <span className="text-xs font-semibold text-white">
                        Arquivo da Versão Gratuita (.zip, .apk, .gba, .sfc, .iso)
                      </span>
                      <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#232632] hover:bg-[#313646] text-xs font-semibold text-white cursor-pointer">
                        <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>
                          {uploadingField === 'free' ? 'Enviando...' : 'Fazer Upload do Arquivo'}
                        </span>
                        <input
                          type="file"
                          className="hidden"
                          accept=".apk,.zip,.7z,.rar,.nes,.sfc,.smc,.gba,.gb,.gbc,.n64,.z64,.iso,.bin,.cue,.chd"
                          onChange={(e) => handleFilePicked(e, 'free')}
                        />
                      </label>
                    </div>
                    <input
                      type="text"
                      value={freeDownloadUrl}
                      onChange={(e) => setFreeDownloadUrl(e.target.value)}
                      placeholder="URL gerada pelo upload ou link direto"
                      className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg font-mono text-xs text-[#D1D5DB] focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                )}

                {accessModel !== 'free' && (
                  <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <span className="text-xs font-semibold text-white">
                        Arquivo da Versão Paga (Pro)
                      </span>
                      <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white cursor-pointer">
                        <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>
                          {uploadingField === 'paid' ? 'Enviando...' : 'Fazer Upload da Versão Pro'}
                        </span>
                        <input
                          type="file"
                          className="hidden"
                          accept=".apk,.zip,.7z,.rar,.nes,.sfc,.smc,.gba,.gb,.gbc,.n64,.z64,.iso,.bin,.cue,.chd"
                          onChange={(e) => handleFilePicked(e, 'paid')}
                        />
                      </label>
                    </div>
                    <input
                      type="text"
                      value={paidDownloadUrl}
                      onChange={(e) => setPaidDownloadUrl(e.target.value)}
                      placeholder="URL gerada pelo upload ou link direto da edição Pro"
                      className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg font-mono text-xs text-[#D1D5DB] focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                )}

                <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <span className="text-xs font-semibold text-white">Imagem de Capa</span>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232632] hover:bg-[#313646] text-xs font-medium text-white cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'cover' ? 'Enviando...' : 'Enviar Imagem'}</span>
                      <input
                        type="file"
                        className="hidden"
                        accept=".png,.jpg,.jpeg,.webp"
                        onChange={(e) => handleFilePicked(e, 'cover')}
                      />
                    </label>
                  </div>
                  <select
                    value={COVER_PRESETS.some((p) => p.url === coverUrl) ? coverUrl : 'custom'}
                    onChange={(e) => {
                      if (e.target.value !== 'custom') setCoverUrl(e.target.value);
                    }}
                    className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg text-xs text-white"
                  >
                    {COVER_PRESETS.map((p) => (
                      <option key={p.label} value={p.url}>
                        Arte Byte Vortex: {p.label}
                      </option>
                    ))}
                    {!COVER_PRESETS.some((p) => p.url === coverUrl) && (
                      <option value="custom">Imagem personalizada enviada</option>
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Descrição completa *
                  </label>
                  <textarea
                    required
                    rows={3}
                    maxLength={2000}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Explique compatibilidade, recursos da versão gratuita e benefícios da versão Pro..."
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Destaques técnicos (1 por linha, máx. 8)
                  </label>
                  <textarea
                    rows={3}
                    value={featuresText}
                    onChange={(e) => setFeaturesText(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-[#D93811]"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 rounded-lg bg-[#232632] hover:bg-[#2E3242] text-xs font-semibold text-white cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={busy || uploadingField !== null}
                    className="px-6 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] disabled:opacity-60 text-xs font-semibold text-white cursor-pointer"
                  >
                    {busy ? 'Publicando...' : editingItem ? 'Salvar Alterações' : 'Publicar no Catálogo'}
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleApkSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Nome do App APK
                    </label>
                    <input
                      type="text"
                      required
                      value={apkTitle}
                      onChange={(e) => setApkTitle(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Versão
                    </label>
                    <input
                      type="text"
                      required
                      value={apkVersion}
                      onChange={(e) => setApkVersion(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Android Mínimo
                    </label>
                    <input
                      type="text"
                      required
                      value={apkAndroidMin}
                      onChange={(e) => setApkAndroidMin(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Tamanho
                    </label>
                    <input
                      type="text"
                      required
                      value={apkSize}
                      onChange={(e) => setApkSize(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Preço APK Pro (R$)
                    </label>
                    <input
                      type="number"
                      step="0.10"
                      min="1"
                      required
                      value={apkProPrice}
                      onChange={(e) => setApkProPrice(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Checksum SHA-256
                  </label>
                  <input
                    type="text"
                    required
                    value={apkSha}
                    onChange={(e) => setApkSha(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-xs text-white"
                  />
                </div>

                <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-white">APK Gratuito (.apk)</span>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232632] hover:bg-[#313646] text-xs font-semibold text-white cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'apkFree' ? 'Enviando...' : 'Upload APK Grátis'}</span>
                      <input
                        type="file"
                        className="hidden"
                        accept=".apk,.zip"
                        onChange={(e) => handleFilePicked(e, 'apkFree')}
                      />
                    </label>
                  </div>
                  <input
                    type="text"
                    required
                    value={apkFreeUrl}
                    onChange={(e) => setApkFreeUrl(e.target.value)}
                    className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg font-mono text-xs text-[#D1D5DB]"
                  />
                </div>

                <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-white">APK Pro Pago (.apk)</span>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'apkPro' ? 'Enviando...' : 'Upload APK Pro'}</span>
                      <input
                        type="file"
                        className="hidden"
                        accept=".apk,.zip"
                        onChange={(e) => handleFilePicked(e, 'apkPro')}
                      />
                    </label>
                  </div>
                  <input
                    type="text"
                    required
                    value={apkProUrl}
                    onChange={(e) => setApkProUrl(e.target.value)}
                    className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg font-mono text-xs text-[#D1D5DB]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Notas da versão (Changelog)
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={apkChangelog}
                    onChange={(e) => setApkChangelog(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 rounded-lg bg-[#232632] hover:bg-[#2E3242] text-xs font-semibold text-white cursor-pointer"
                  >
                    Fechar
                  </button>
                  <button
                    type="submit"
                    disabled={busy || uploadingField !== null}
                    className="px-6 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] disabled:opacity-60 text-xs font-semibold text-white cursor-pointer"
                  >
                    {busy ? 'Salvando...' : 'Atualizar APK Oficial'}
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
