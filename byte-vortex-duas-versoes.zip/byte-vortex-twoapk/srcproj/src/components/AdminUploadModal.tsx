import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { Lock, LogOut, Mail, RefreshCw, Upload, UserCheck, X } from 'lucide-react';
import type { User } from 'firebase/auth';
import { COVER_PRESETS } from '../data/starterCatalog';
import {
  ADMIN_EMAIL,
  type AccessModel,
  type AppRelease,
  type AppSessionUser,
  type CatalogCategory,
  type CatalogItem,
} from '../types';
import { sanitizeItemPayload, slugifyId } from '../utils/formatters';

interface AdminUploadModalProps {
  isOpen: boolean;
  initialTab: 'catalog' | 'apk';
  user: AppSessionUser | null;
  isAdmin: boolean;
  editingItem: CatalogItem | null;
  currentApkRelease: AppRelease | null;
  onClose: () => void;
  onSignInGoogle: () => Promise<void>;
  onSignInEmail: (email: string, password: string) => Promise<void>;
  onRegisterEmail: (email: string, password: string) => Promise<void>;
  onResetPassword: (email: string) => Promise<'email-server' | 'sent'>;
  onResendVerification: (user: User) => Promise<void>;
  onRefreshUser: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onSaveCatalogItem: (
    id: string,
    data: ReturnType<typeof sanitizeItemPayload>,
    isNew: boolean
  ) => Promise<void>;
  onSaveApkRelease: (release: Omit<AppRelease, 'id' | 'updatedAt'>) => Promise<void>;
}

async function uploadFileToServer(
  file: File,
  user: User
): Promise<{ url: string; fileName: string; sizeFormatted: string }> {
  const token = await user.getIdToken();
  const base64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Erro ao ler arquivo selecionado.'));
    reader.readAsDataURL(file);
  });

  const resp = await fetch('/api/upload', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      fileName: file.name,
      dataBase64: base64,
    }),
  });

  const data = (await resp.json()) as {
    url?: string;
    fileName?: string;
    sizeFormatted?: string;
    error?: string;
  };

  if (!resp.ok || !data.url || !data.fileName) {
    throw new Error(data.error ?? 'Falha ao enviar arquivo.');
  }

  return {
    url: data.url,
    fileName: data.fileName,
    sizeFormatted: data.sizeFormatted ?? '1.0 MB',
  };
}

function formatAuthError(err: unknown): string {
  const code = (err as { code?: string })?.code ?? '';
  const msg = err instanceof Error ? err.message : String(err);
  if (code === 'auth/popup-closed-by-user' || msg.includes('popup-closed-by-user')) {
    return '';
  }
  if (code === 'auth/popup-blocked' || msg.includes('popup-blocked')) {
    return 'O navegador bloqueou a janela de login. Permita pop-ups e tente novamente.';
  }
  if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password')) {
    return 'E-mail ou senha incorretos.';
  }
  if (msg.includes('auth/user-not-found')) {
    return 'Conta não encontrada. Crie uma conta com este e-mail primeiro.';
  }
  if (msg.includes('auth/email-already-in-use')) {
    return 'Este e-mail já está cadastrado. Faça login na aba Entrar.';
  }
  if (msg.includes('auth/weak-password')) {
    return 'A senha precisa ter pelo menos 6 caracteres.';
  }
  if (msg.includes('auth/invalid-email')) {
    return 'Informe um endereço de e-mail válido.';
  }
  return msg || 'Não foi possível concluir o acesso agora. Tente novamente.';
}

export function AdminUploadModal({
  isOpen,
  initialTab,
  user,
  isAdmin,
  editingItem,
  currentApkRelease,
  onClose,
  onSignInGoogle,
  onSignInEmail,
  onRegisterEmail,
  onResetPassword,
  onResendVerification,
  onRefreshUser,
  onSignOut,
  onSaveCatalogItem,
  onSaveApkRelease,
}: AdminUploadModalProps) {
  const [tab, setTab] = useState<'catalog' | 'apk'>(initialTab);
  const [busy, setBusy] = useState(false);
  const [uploadingField, setUploadingField] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Email Auth state
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'reset'>('login');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [authBusy, setAuthBusy] = useState(false);
  const [authNotice, setAuthNotice] = useState('');
  const [authError, setAuthError] = useState('');

  // Catalog form state
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<CatalogCategory>('emulator');
  const [platform, setPlatform] = useState('Android · PC');
  const [version, setVersion] = useState('v1.0.0');
  const [fileSize, setFileSize] = useState('20.0 MB');
  const [coverUrl, setCoverUrl] = useState(COVER_PRESETS[0].url);
  const [accessModel, setAccessModel] = useState<AccessModel>('freemium');
  const [priceBrl, setPriceBrl] = useState('19.90');
  const [freeDownloadUrl, setFreeDownloadUrl] = useState('');
  const [freeFileName, setFreeFileName] = useState('');
  const [paidDownloadUrl, setPaidDownloadUrl] = useState('');
  const [paidFileName, setPaidFileName] = useState('');
  const [featuresText, setFeaturesText] = useState(
    'Compatível com controles Bluetooth\nSuporte direto no Byte Vortex APK'
  );
  const [featured, setFeatured] = useState(true);

  // APK release form state
  const [apkTitle, setApkTitle] = useState(currentApkRelease?.title ?? 'Byte Vortex Mobile');
  const [apkVersion, setApkVersion] = useState(currentApkRelease?.version ?? 'v1.0.0');
  const [apkAndroidMin, setApkAndroidMin] = useState(
    currentApkRelease?.androidMin ?? 'Android 9.0 ou superior'
  );
  const [apkSize, setApkSize] = useState(currentApkRelease?.fileSize ?? '');
  const [apkSha, setApkSha] = useState(currentApkRelease?.sha256 ?? '');
  const [apkFreeUrl, setApkFreeUrl] = useState(currentApkRelease?.freeApkUrl ?? '');
  const [apkFreeName, setApkFreeName] = useState(currentApkRelease?.freeApkName ?? 'byte-vortex-free.apk');
  const [apkProUrl, setApkProUrl] = useState(currentApkRelease?.proApkUrl ?? '');
  const [apkProName, setApkProName] = useState(currentApkRelease?.proApkName ?? 'byte-vortex-pro.apk');
  const [apkProPrice, setApkProPrice] = useState(
    currentApkRelease ? String(currentApkRelease.proPriceBrl) : '19.90'
  );
  const [apkChangelog, setApkChangelog] = useState(currentApkRelease?.changelog ?? '');

  useEffect(() => {
    setTab(initialTab);
    setErrorMsg('');
    setStatusMsg('');
    setAuthError('');
    setAuthNotice('');
  }, [initialTab, isOpen]);

  useEffect(() => {
    if (editingItem) {
      setTab('catalog');
      setTitle(editingItem.title);
      setSubtitle(editingItem.subtitle);
      setDescription(editingItem.description);
      setCategory(editingItem.category);
      setPlatform(editingItem.platform);
      setVersion(editingItem.version);
      setFileSize(editingItem.fileSize);
      setCoverUrl(editingItem.coverUrl);
      setAccessModel(editingItem.accessModel);
      setPriceBrl(String(editingItem.priceBrl || 19.9));
      setFreeDownloadUrl(editingItem.freeDownloadUrl);
      setFreeFileName(editingItem.freeFileName);
      setPaidDownloadUrl(editingItem.paidDownloadUrl);
      setPaidFileName(editingItem.paidFileName);
      setFeaturesText(editingItem.features.join('\n'));
      setFeatured(editingItem.featured);
    } else {
      setTitle('');
      setSubtitle('');
      setDescription('');
      setCategory('emulator');
      setPlatform('Android · PC');
      setVersion('v1.0.0');
      setFileSize('20.0 MB');
      setCoverUrl(COVER_PRESETS[0].url);
      setAccessModel('freemium');
      setPriceBrl('19.90');
      setFreeDownloadUrl('');
      setFreeFileName('');
      setPaidDownloadUrl('');
      setPaidFileName('');
      setFeaturesText('Compatível com controles Bluetooth\nSuporte direto no Byte Vortex APK');
      setFeatured(true);
    }
  }, [editingItem, isOpen]);

  useEffect(() => {
    setApkTitle(currentApkRelease?.title ?? 'Byte Vortex Mobile');
    setApkVersion(currentApkRelease?.version ?? 'v1.0.0');
    setApkAndroidMin(currentApkRelease?.androidMin ?? 'Android 9.0 ou superior');
    setApkSize(currentApkRelease?.fileSize ?? '');
    setApkSha(currentApkRelease?.sha256 ?? '');
    setApkFreeUrl(currentApkRelease?.freeApkUrl ?? '');
    setApkFreeName(currentApkRelease?.freeApkName ?? 'byte-vortex-free.apk');
    setApkProUrl(currentApkRelease?.proApkUrl ?? '');
    setApkProName(currentApkRelease?.proApkName ?? 'byte-vortex-pro.apk');
    setApkProPrice(currentApkRelease ? String(currentApkRelease.proPriceBrl) : '19.90');
    setApkChangelog(currentApkRelease?.changelog ?? '');
  }, [currentApkRelease, isOpen]);

  if (!isOpen) return null;

  const handleEmailAuthSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthNotice('');
    setAuthBusy(true);

    try {
      if (authMode === 'login') {
        await onSignInEmail(emailInput, passwordInput);
      } else if (authMode === 'register') {
        await onRegisterEmail(emailInput, passwordInput);
        setAuthNotice('Conta criada e conectada com sucesso.');
      } else {
        const res = await onResetPassword(emailInput);
        setAuthNotice(
          res === 'email-server'
            ? 'Para alterar ou criar uma nova senha para outro e-mail, utilize a aba Criar conta.'
            : 'E-mail de redefinição de senha enviado. Confira sua caixa de entrada.'
        );
      }
    } catch (err) {
      const friendly = formatAuthError(err);
      if (friendly) setAuthError(friendly);
    } finally {
      setAuthBusy(false);
    }
  };

  const handleFilePicked = async (
    e: ChangeEvent<HTMLInputElement>,
    target: 'free' | 'paid' | 'cover' | 'apkFree' | 'apkPro'
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !user?.firebaseUser) return;

    setErrorMsg('');
    setStatusMsg('');
    setUploadingField(target);

    try {
      const uploaded = await uploadFileToServer(file, user.firebaseUser);
      if (target === 'free') {
        setFreeDownloadUrl(uploaded.url);
        setFreeFileName(uploaded.fileName);
        setFileSize(uploaded.sizeFormatted);
      } else if (target === 'paid') {
        setPaidDownloadUrl(uploaded.url);
        setPaidFileName(uploaded.fileName);
        setFileSize(uploaded.sizeFormatted);
      } else if (target === 'cover') {
        setCoverUrl(uploaded.url);
      } else if (target === 'apkFree') {
        setApkFreeUrl(uploaded.url);
        setApkFreeName(uploaded.fileName);
        setApkSize(uploaded.sizeFormatted);
      } else if (target === 'apkPro') {
        setApkProUrl(uploaded.url);
        setApkProName(uploaded.fileName);
      }
      setStatusMsg(`Arquivo "${uploaded.fileName}" enviado com sucesso.`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Erro no upload do arquivo.');
    } finally {
      setUploadingField(null);
    }
  };

  const handleCatalogSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setStatusMsg('');

    if (title.trim().length < 2 || subtitle.trim().length < 2 || description.trim().length < 10) {
      setErrorMsg('Preencha título, subtítulo e uma descrição com pelo menos 10 caracteres.');
      return;
    }

    if (accessModel !== 'paid' && !freeDownloadUrl.trim()) {
      setErrorMsg('Envie o arquivo da versão gratuita ou informe a URL de download.');
      return;
    }

    if (accessModel !== 'free' && !paidDownloadUrl.trim()) {
      setErrorMsg('Envie o arquivo da versão paga Pro ou informe a URL de download.');
      return;
    }

    setBusy(true);
    try {
      const payload = sanitizeItemPayload({
        title,
        subtitle,
        description,
        category,
        platform,
        version,
        fileSize,
        coverUrl,
        accessModel,
        priceBrl: Number(priceBrl.replace(',', '.')) || 0,
        freeDownloadUrl,
        freeFileName: freeFileName || `${slugifyId(title)}-free.zip`,
        paidDownloadUrl,
        paidFileName: paidFileName || `${slugifyId(title)}-pro.zip`,
        features: featuresText.split('\n'),
        featured,
      });

      const targetId = editingItem ? editingItem.id : slugifyId(title);
      await onSaveCatalogItem(targetId, payload, !editingItem);
      setStatusMsg('Item publicado no catálogo público com sucesso.');
      setTimeout(() => onClose(), 800);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Erro ao salvar no catálogo.');
    } finally {
      setBusy(false);
    }
  };

  const handleApkSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setStatusMsg('');

    if (!user) return;
    setBusy(true);
    try {
      await onSaveApkRelease({
        title: apkTitle.trim().slice(0, 100),
        version: apkVersion.trim().slice(0, 30),
        androidMin: apkAndroidMin.trim().slice(0, 40),
        fileSize: apkSize.trim().slice(0, 30),
        sha256: apkSha.trim().slice(0, 128),
        freeApkUrl: apkFreeUrl.trim().slice(0, 1000),
        freeApkName: apkFreeName.trim().slice(0, 160),
        proApkUrl: apkProUrl.trim().slice(0, 1000),
        proApkName: apkProName.trim().slice(0, 160),
        proPriceBrl: Math.max(1, Number(apkProPrice.replace(',', '.')) || 19.9),
        changelog: apkChangelog.trim().slice(0, 1500),
        updatedBy: user.uid,
      });
      setStatusMsg('Versão oficial do APK atualizada com sucesso.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Erro ao atualizar APK.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-modal-title"
    >
      <div className="w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-[#16181F] border border-white/15 rounded-xl">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <Lock className="w-4 h-4 text-[#D93811]" aria-hidden="true" />
            <h2 id="admin-modal-title" className="font-display text-lg font-bold text-[#F4F5F7]">
              {user && !isAdmin ? 'Acesso da Conta' : 'Acesso por E-mail e Painel Admin'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela"
            className="p-2 rounded-lg text-[#A3AAB8] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auth Gate */}
        {!user ? (
          <div className="p-6 sm:p-8 space-y-6">
            <div className="max-w-lg mx-auto space-y-2 text-center">
              <h3 className="font-display text-xl font-bold text-white">
                Entrar com E-mail ou Google
              </h3>
              <p className="text-sm text-[#A3AAB8] leading-relaxed">
                O acesso por e-mail funciona de forma independente, sem abrir login com Google. O painel de upload é liberado exclusivamente para{' '}
                <span className="font-mono text-white">{ADMIN_EMAIL}</span>.
              </p>
            </div>

            <div className="max-w-md mx-auto space-y-5">
              <button
                type="button"
                onClick={onSignInGoogle}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-sm font-semibold text-white transition-colors cursor-pointer"
              >
                <span>Entrar com Google</span>
              </button>

              <div className="relative flex items-center justify-center">
                <span className="w-full border-t border-white/10" />
                <span className="px-3 text-xs text-[#8E95A5] bg-[#16181F] shrink-0">
                  ou acesse com seu e-mail
                </span>
                <span className="w-full border-t border-white/10" />
              </div>

              {/* Email / Password Tabs */}
              <div className="flex items-center gap-1 p-1 bg-[#111318] border border-white/10 rounded-lg">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('login');
                    setAuthError('');
                    setAuthNotice('');
                  }}
                  className={`flex-1 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    authMode === 'login' ? 'bg-[#252935] text-white' : 'text-[#A3AAB8] hover:text-white'
                  }`}
                >
                  Entrar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('register');
                    setAuthError('');
                    setAuthNotice('');
                  }}
                  className={`flex-1 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    authMode === 'register'
                      ? 'bg-[#252935] text-white'
                      : 'text-[#A3AAB8] hover:text-white'
                  }`}
                >
                  Criar conta
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('reset');
                    setAuthError('');
                    setAuthNotice('');
                  }}
                  className={`flex-1 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    authMode === 'reset'
                      ? 'bg-[#252935] text-white'
                      : 'text-[#A3AAB8] hover:text-white'
                  }`}
                >
                  Recuperar senha
                </button>
              </div>

              <form onSubmit={handleEmailAuthSubmit} className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1">
                    E-mail
                  </label>
                  <input
                    type="email"
                    required
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="seuemail@exemplo.com"
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                  />
                </div>

                {authMode !== 'reset' && (
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1">
                      Senha
                    </label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      placeholder="Mínimo 6 caracteres"
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                )}

                {authNotice && (
                  <p className="p-3 rounded-lg bg-emerald-950/50 border border-emerald-500/30 text-xs text-emerald-200">
                    {authNotice}
                  </p>
                )}

                {authError && (
                  <p
                    className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-xs text-red-200"
                    role="alert"
                  >
                    {authError}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={authBusy}
                  className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 min-h-[42px] rounded-lg bg-[#232632] hover:bg-[#2F3342] border border-white/15 disabled:opacity-60 text-xs font-semibold text-white transition-colors cursor-pointer"
                >
                  <Mail className="w-4 h-4" aria-hidden="true" />
                  <span>
                    {authBusy
                      ? 'Processando...'
                      : authMode === 'login'
                        ? 'Entrar com E-mail'
                        : authMode === 'register'
                          ? 'Criar conta com E-mail'
                          : 'Enviar link de recuperação'}
                  </span>
                </button>
              </form>
            </div>
          </div>
        ) : !user.emailVerified ? (
          <div className="p-8 text-center space-y-5 max-w-lg mx-auto">
            <div className="w-12 h-12 rounded-xl bg-[#1F222C] border border-white/10 mx-auto flex items-center justify-center">
              <Mail className="w-6 h-6 text-[#D93811]" aria-hidden="true" />
            </div>
            <div className="space-y-2">
              <h3 className="font-display text-xl font-bold text-white">
                Confirme seu e-mail
              </h3>
              <p className="text-sm text-[#A3AAB8] leading-relaxed">
                Você entrou como <span className="font-mono text-white">{user.email}</span>, mas o e-mail ainda não foi verificado. Clique no link enviado para sua caixa de entrada e depois atualize abaixo.
              </p>
            </div>
            {authNotice && (
              <p className="p-3 rounded-lg bg-emerald-950/50 border border-emerald-500/30 text-xs text-emerald-200">
                {authNotice}
              </p>
            )}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={async () => {
                  await onRefreshUser();
                }}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" aria-hidden="true" />
                <span>Já confirmei, atualizar</span>
              </button>
              <button
                type="button"
                onClick={async () => {
                  if (user.firebaseUser) {
                    await onResendVerification(user.firebaseUser);
                    setAuthNotice('Novo e-mail de verificação enviado.');
                  }
                }}
                className="px-4 py-2.5 rounded-lg bg-[#232632] hover:bg-[#2F3342] text-xs font-semibold text-white cursor-pointer"
              >
                Reenviar verificação
              </button>
              <button
                type="button"
                onClick={onSignOut}
                className="px-4 py-2.5 rounded-lg bg-[#1A1D26] hover:bg-[#232632] text-xs font-medium text-[#D1D5DB] cursor-pointer"
              >
                Sair
              </button>
            </div>
          </div>
        ) : !isAdmin ? (
          <div className="p-8 text-center space-y-5">
            <div className="w-12 h-12 rounded-xl bg-[#1F222C] border border-white/10 mx-auto flex items-center justify-center">
              <UserCheck className="w-6 h-6 text-[#F4F5F7]" aria-hidden="true" />
            </div>
            <div className="max-w-md mx-auto space-y-2">
              <h3 className="font-display text-xl font-bold text-white">
                Conta conectada (Acesso de Cliente)
              </h3>
              <p className="text-sm text-[#A3AAB8] leading-relaxed">
                Você está conectado como <span className="font-mono text-white">{user.email}</span>. Suas compras Pro ficam salvas nesta conta, porém somente o administrador{' '}
                <span className="font-mono text-white">{ADMIN_EMAIL}</span> tem permissão para fazer upload ou postar emuladores e jogos.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-sm font-semibold text-white transition-colors cursor-pointer"
              >
                Continuar na Loja
              </button>
              <button
                type="button"
                onClick={onSignOut}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[42px] rounded-lg bg-[#232632] hover:bg-[#2F3342] text-sm font-semibold text-white transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" aria-hidden="true" />
                <span>Trocar de conta</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 space-y-6">
            {/* Authenticated Admin Header Bar */}
            <div className="p-3.5 rounded-xl bg-[#111318] border border-white/10 flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs">
                <span className="text-[#9CA3AF]">Administrador autenticado: </span>
                <span className="font-mono text-white font-medium">{user.email}</span>
              </div>

              <button
                type="button"
                onClick={onSignOut}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232632] hover:bg-[#303444] text-xs font-medium text-[#D1D5DB] cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sair</span>
              </button>
            </div>

            {/* Admin Tabs */}
            <div className="flex items-center gap-1 p-1 bg-[#111318] border border-white/10 rounded-lg w-fit">
              <button
                type="button"
                onClick={() => setTab('catalog')}
                className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                  tab === 'catalog' ? 'bg-[#D93811] text-white' : 'text-[#A3AAB8] hover:text-white'
                }`}
              >
                {editingItem ? 'Editar Item' : 'Upload de Emulador / Jogo'}
              </button>
              <button
                type="button"
                onClick={() => setTab('apk')}
                className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                  tab === 'apk' ? 'bg-[#D93811] text-white' : 'text-[#A3AAB8] hover:text-white'
                }`}
              >
                Gerenciar Byte Vortex APK
              </button>
            </div>

            {statusMsg && (
              <div className="p-3 rounded-lg bg-emerald-950/50 border border-emerald-500/30 text-xs font-medium text-emerald-200">
                {statusMsg}
              </div>
            )}
            {errorMsg && (
              <div
                className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-xs font-medium text-red-200"
                role="alert"
              >
                {errorMsg}
              </div>
            )}

            {tab === 'catalog' ? (
              <form onSubmit={handleCatalogSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Nome do Emulador ou Jogo *
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={100}
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Digite o nome do emulador ou jogo"
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Categoria *
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as CatalogCategory)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    >
                      <option value="emulator">Emulador</option>
                      <option value="game">Jogo</option>
                      <option value="apk">Utilitário APK</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Subtítulo curto *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={160}
                    value={subtitle}
                    onChange={(e) => setSubtitle(e.target.value)}
                    placeholder="Resumo curto do emulador ou jogo"
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Plataforma
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={40}
                      value={platform}
                      onChange={(e) => setPlatform(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Versão
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={30}
                      value={version}
                      onChange={(e) => setVersion(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Tamanho
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={30}
                      value={fileSize}
                      onChange={(e) => setFileSize(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Modelo de Acesso (Grátis / Pago)
                    </label>
                    <select
                      value={accessModel}
                      onChange={(e) => setAccessModel(e.target.value as AccessModel)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                    >
                      <option value="freemium">Versão Gratuita + Versão Paga (Pro)</option>
                      <option value="free">Somente Gratuito</option>
                      <option value="paid">Somente Pago (Pro)</option>
                    </select>
                  </div>
                  {accessModel !== 'free' && (
                    <div>
                      <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                        Preço da Versão Pro (R$)
                      </label>
                      <input
                        type="number"
                        step="0.10"
                        min="1"
                        max="9999"
                        required
                        value={priceBrl}
                        onChange={(e) => setPriceBrl(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                      />
                    </div>
                  )}
                </div>

                {accessModel !== 'paid' && (
                  <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <span className="text-xs font-semibold text-white">
                        Arquivo da Versão Gratuita (.zip, .apk, .gba, .sfc, .iso)
                      </span>
                      <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#232632] hover:bg-[#313646] text-xs font-semibold text-white cursor-pointer">
                        <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>
                          {uploadingField === 'free' ? 'Enviando...' : 'Fazer Upload do Arquivo'}
                        </span>
                        <input
                          type="file"
                          className="hidden"
                          accept=".apk,.zip,.7z,.rar,.nes,.sfc,.smc,.gba,.gb,.gbc,.n64,.z64,.iso,.bin,.cue,.chd"
                          onChange={(e) => handleFilePicked(e, 'free')}
                        />
                      </label>
                    </div>
                    <input
                      type="text"
                      value={freeDownloadUrl}
                      onChange={(e) => setFreeDownloadUrl(e.target.value)}
                      placeholder="URL gerada pelo upload ou link direto"
                      className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg font-mono text-xs text-[#D1D5DB] focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                )}

                {accessModel !== 'free' && (
                  <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <span className="text-xs font-semibold text-white">
                        Arquivo da Versão Paga (Pro)
                      </span>
                      <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white cursor-pointer">
                        <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>
                          {uploadingField === 'paid' ? 'Enviando...' : 'Fazer Upload da Versão Pro'}
                        </span>
                        <input
                          type="file"
                          className="hidden"
                          accept=".apk,.zip,.7z,.rar,.nes,.sfc,.smc,.gba,.gb,.gbc,.n64,.z64,.iso,.bin,.cue,.chd"
                          onChange={(e) => handleFilePicked(e, 'paid')}
                        />
                      </label>
                    </div>
                    <input
                      type="text"
                      value={paidDownloadUrl}
                      onChange={(e) => setPaidDownloadUrl(e.target.value)}
                      placeholder="URL gerada pelo upload ou link direto da edição Pro"
                      className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg font-mono text-xs text-[#D1D5DB] focus:outline-none focus:border-[#D93811]"
                    />
                  </div>
                )}

                <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <span className="text-xs font-semibold text-white">Imagem de Capa</span>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232632] hover:bg-[#313646] text-xs font-medium text-white cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'cover' ? 'Enviando...' : 'Enviar Imagem'}</span>
                      <input
                        type="file"
                        className="hidden"
                        accept=".png,.jpg,.jpeg,.webp"
                        onChange={(e) => handleFilePicked(e, 'cover')}
                      />
                    </label>
                  </div>
                  <select
                    value={COVER_PRESETS.some((p) => p.url === coverUrl) ? coverUrl : 'custom'}
                    onChange={(e) => {
                      if (e.target.value !== 'custom') setCoverUrl(e.target.value);
                    }}
                    className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg text-xs text-white"
                  >
                    {COVER_PRESETS.map((p) => (
                      <option key={p.label} value={p.url}>
                        Arte Byte Vortex: {p.label}
                      </option>
                    ))}
                    {!COVER_PRESETS.some((p) => p.url === coverUrl) && (
                      <option value="custom">Imagem personalizada enviada</option>
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Descrição completa *
                  </label>
                  <textarea
                    required
                    rows={3}
                    maxLength={2000}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Explique compatibilidade, recursos da versão gratuita e benefícios da versão Pro..."
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Destaques técnicos (1 por linha, máx. 8)
                  </label>
                  <textarea
                    rows={3}
                    value={featuresText}
                    onChange={(e) => setFeaturesText(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-[#D93811]"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 rounded-lg bg-[#232632] hover:bg-[#2E3242] text-xs font-semibold text-white cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={busy || uploadingField !== null}
                    className="px-6 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] disabled:opacity-60 text-xs font-semibold text-white cursor-pointer"
                  >
                    {busy ? 'Publicando...' : editingItem ? 'Salvar Alterações' : 'Publicar no Catálogo'}
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleApkSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Nome do App APK
                    </label>
                    <input
                      type="text"
                      required
                      value={apkTitle}
                      onChange={(e) => setApkTitle(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Versão
                    </label>
                    <input
                      type="text"
                      required
                      value={apkVersion}
                      onChange={(e) => setApkVersion(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Android Mínimo
                    </label>
                    <input
                      type="text"
                      required
                      value={apkAndroidMin}
                      onChange={(e) => setApkAndroidMin(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Tamanho
                    </label>
                    <input
                      type="text"
                      required
                      value={apkSize}
                      onChange={(e) => setApkSize(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                      Preço APK Pro (R$)
                    </label>
                    <input
                      type="number"
                      step="0.10"
                      min="1"
                      required
                      value={apkProPrice}
                      onChange={(e) => setApkProPrice(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Checksum SHA-256
                  </label>
                  <input
                    type="text"
                    required
                    value={apkSha}
                    onChange={(e) => setApkSha(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg font-mono text-xs text-white"
                  />
                </div>

                <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-white">APK Gratuito (.apk)</span>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232632] hover:bg-[#313646] text-xs font-semibold text-white cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'apkFree' ? 'Enviando...' : 'Upload APK Grátis'}</span>
                      <input
                        type="file"
                        className="hidden"
                        accept=".apk,.zip"
                        onChange={(e) => handleFilePicked(e, 'apkFree')}
                      />
                    </label>
                  </div>
                  <input
                    type="text"
                    required
                    value={apkFreeUrl}
                    onChange={(e) => setApkFreeUrl(e.target.value)}
                    className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg font-mono text-xs text-[#D1D5DB]"
                  />
                </div>

                <div className="p-4 rounded-xl bg-[#111318] border border-white/10 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-white">APK Pro Pago (.apk)</span>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'apkPro' ? 'Enviando...' : 'Upload APK Pro'}</span>
                      <input
                        type="file"
                        className="hidden"
                        accept=".apk,.zip"
                        onChange={(e) => handleFilePicked(e, 'apkPro')}
                      />
                    </label>
                  </div>
                  <input
                    type="text"
                    required
                    value={apkProUrl}
                    onChange={(e) => setApkProUrl(e.target.value)}
                    className="w-full px-3 py-2 bg-[#16181F] border border-white/10 rounded-lg font-mono text-xs text-[#D1D5DB]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#D1D5DB] mb-1.5">
                    Notas da versão (Changelog)
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={apkChangelog}
                    onChange={(e) => setApkChangelog(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111318] border border-white/10 rounded-lg text-sm text-white"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 rounded-lg bg-[#232632] hover:bg-[#2E3242] text-xs font-semibold text-white cursor-pointer"
                  >
                    Fechar
                  </button>
                  <button
                    type="submit"
                    disabled={busy || uploadingField !== null}
                    className="px-6 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] disabled:opacity-60 text-xs font-semibold text-white cursor-pointer"
                  >
                    {busy ? 'Salvando...' : 'Atualizar APK Oficial'}
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
