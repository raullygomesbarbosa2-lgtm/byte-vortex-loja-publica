import { useMemo, useState } from 'react';
import {
  Barcode,
  Check,
  Copy,
  CreditCard,
  Download,
  QrCode,
  Trash2,
  X,
} from 'lucide-react';
import type { AppSessionUser, CartEntry, PaymentMethod } from '../types';
import { formatBrl, triggerFileDownload } from '../utils/formatters';
import { MediaImage } from './MediaImage';

interface CheckoutDrawerProps {
  isOpen: boolean;
  cart: CartEntry[];
  user: AppSessionUser | null;
  processing: boolean;
  onClose: () => void;
  onRemoveItem: (itemId: string) => void;
  onSwitchToFree: (entry: CartEntry) => void;
  onCompletePayment: (method: PaymentMethod) => Promise<CartEntry[]>;
  onOpenEmailAuth: () => void;
}

// Deterministic clean QR pattern SVG for PIX preview
function PixQrMatrix({ seed }: { seed: string }) {
  const cells = useMemo(() => {
    const size = 21;
    const grid: boolean[] = [];
    let hash = 2166136261;
    for (let i = 0; i < seed.length; i++) {
      hash ^= seed.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const inTopLeft = r < 7 && c < 7;
        const inTopRight = r < 7 && c >= size - 7;
        const inBottomLeft = r >= size - 7 && c < 7;

        if (inTopLeft || inTopRight || inBottomLeft) {
          const lr = inBottomLeft ? r - (size - 7) : r;
          const lc = inTopRight ? c - (size - 7) : c;
          const border = lr === 0 || lr === 6 || lc === 0 || lc === 6;
          const center = lr >= 2 && lr <= 4 && lc >= 2 && lc <= 4;
          grid.push(border || center);
        } else {
          hash = (Math.imul(hash, 1664525) + 1013904223) >>> 0;
          grid.push((hash & 3) === 0 || (hash & 5) === 5);
        }
      }
    }
    return grid;
  }, [seed]);

  return (
    <svg
      viewBox="0 0 21 21"
      className="w-36 h-36 bg-white p-2 rounded-lg shrink-0"
      aria-label="QR Code PIX Byte Vortex"
    >
      {cells.map((filled, i) =>
        filled ? (
          <rect
            key={i}
            x={i % 21}
            y={Math.floor(i / 21)}
            width={1}
            height={1}
            fill="#0E0F13"
          />
        ) : null
      )}
    </svg>
  );
}

export function CheckoutDrawer({
  isOpen,
  cart,
  user,
  processing,
  onClose,
  onRemoveItem,
  onSwitchToFree,
  onCompletePayment,
  onOpenEmailAuth,
}: CheckoutDrawerProps) {
  const [method, setMethod] = useState<PaymentMethod>('pix');
  const [copiedCode, setCopiedCode] = useState(false);
  const [cardName, setCardName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [installments, setInstallments] = useState('1');
  const [formError, setFormError] = useState('');
  const [paidItems, setPaidItems] = useState<CartEntry[] | null>(null);

  const totalBrl = useMemo(
    () => cart.reduce((acc, item) => acc + item.priceBrl, 0),
    [cart]
  );

  const pixKey = 'raullygomesbarbosa2@gmail.com';

  const boletoCode = '34191.79001 01043.510047 91020.150008 6 98520000002490';

  if (!isOpen) return null;

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } catch {
      setCopiedCode(false);
    }
  };

  const handleSubmit = async () => {
    setFormError('');
    if (method === 'card') {
      const digits = cardNumber.replace(/\D/g, '');
      if (cardName.trim().length < 3 || digits.length < 13 || cardCvv.trim().length < 3) {
        setFormError('Preencha nome do titular, número do cartão e CVV válidos.');
        return;
      }
    }

    try {
      const unlocked = await onCompletePayment(method);
      setPaidItems(unlocked);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Erro ao processar pagamento.');
    }
  };

  const handleCloseDrawer = () => {
    setPaidItems(null);
    setFormError('');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Sacola e Pagamento"
    >
      <div className="w-full max-w-lg h-full bg-[#13151B] border-l border-white/15 flex flex-col">
        {/* Drawer header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-[#F4F5F7]">
              {paidItems ? 'Pagamento Confirmado' : 'Sacola e Pagamento'}
            </h2>
            <p className="text-xs text-[#9CA3AF]">
              {paidItems
                ? 'Seus downloads Pro já estão liberados abaixo.'
                : 'Escolha PIX, Cartão ou Boleto — ou baixe a versão gratuita.'}
            </p>
          </div>
          <button
            type="button"
            onClick={handleCloseDrawer}
            aria-label="Fechar sacola"
            className="p-2 rounded-lg text-[#A3AAB8] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {paidItems ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-emerald-950/50 border border-emerald-500/30 flex items-start gap-3">
                <Check className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-sm font-semibold text-emerald-200">
                    Compra aprovada com sucesso
                  </p>
                  <p className="mt-1 text-xs text-emerald-300/80">
                    {user
                      ? `Recibo salvo na conta ${user.email}.`
                      : 'Licença liberada nesta sessão para download imediato.'}
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {paidItems.map((item) => (
                  <div
                    key={item.itemId}
                    className="p-4 rounded-xl bg-[#1A1D26] border border-white/10 flex items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-white truncate">{item.title}</p>
                      <p className="text-xs font-mono text-[#9CA3AF] truncate">
                        {item.paidFileName}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => triggerFileDownload(item.paidDownloadUrl, item.paidFileName)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Download className="w-4 h-4" aria-hidden="true" />
                      <span>Baixar Pro</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ) : cart.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <p className="text-base font-medium text-[#F4F5F7]">Sua sacola está vazia.</p>
              <p className="text-sm text-[#9CA3AF]">
                Adicione uma versão Pro de emulador, jogo ou APK — ou baixe qualquer versão gratuita diretamente no catálogo.
              </p>
            </div>
          ) : (
            <>
              {/* Cart items */}
              <div className="space-y-3">
                {cart.map((entry) => (
                  <div
                    key={entry.itemId}
                    className="p-3.5 rounded-xl bg-[#1A1D26] border border-white/10 space-y-3"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-16 h-12 rounded-md overflow-hidden bg-[#111318] shrink-0">
                        <MediaImage
                          src={entry.coverUrl}
                          alt={entry.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-[#F4F5F7] truncate">
                          {entry.title}
                        </p>
                        <p className="text-xs text-[#9CA3AF] truncate">{entry.subtitle}</p>
                        <p className="mt-0.5 font-mono text-xs font-semibold tabular-nums text-white">
                          {formatBrl(entry.priceBrl)}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(entry.itemId)}
                        aria-label={`Remover ${entry.title}`}
                        className="p-2 text-[#9CA3AF] hover:text-red-400 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Explicit option to download Free version instead of paying */}
                    {entry.freeDownloadUrl && (
                      <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-2">
                        <span className="text-xs text-[#A3AAB8]">
                          Não quer pagar agora?
                        </span>
                        <button
                          type="button"
                          onClick={() => onSwitchToFree(entry)}
                          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#F4F5F7] hover:text-[#D93811] underline underline-offset-4 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Baixar Versão Gratuita</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Optional Sign-In to save purchases in cloud */}
              {!user && (
                <div className="p-4 rounded-xl bg-[#1A1D26] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <p className="text-xs text-[#A3AAB8]">
                    Entre com seu e-mail para salvar suas licenças na nuvem e recuperá-las em outro aparelho.
                  </p>
                  <button
                    type="button"
                    onClick={onOpenEmailAuth}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white whitespace-nowrap cursor-pointer transition-colors"
                  >
                    Entrar com e-mail
                  </button>
                </div>
              )}

              {/* Payment method tabs */}
              <div className="space-y-4 pt-2 border-t border-white/10">
                <h3 className="text-sm font-semibold text-[#F4F5F7]">Forma de Pagamento</h3>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setMethod('pix')}
                    className={`flex flex-col items-center justify-center gap-1.5 py-3 px-2 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${
                      method === 'pix'
                        ? 'bg-[#D93811]/15 border-[#D93811] text-white'
                        : 'bg-[#1A1D26] border-white/10 text-[#A3AAB8] hover:text-white'
                    }`}
                  >
                    <QrCode className="w-4 h-4" aria-hidden="true" />
                    <span>PIX</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMethod('card')}
                    className={`flex flex-col items-center justify-center gap-1.5 py-3 px-2 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${
                      method === 'card'
                        ? 'bg-[#D93811]/15 border-[#D93811] text-white'
                        : 'bg-[#1A1D26] border-white/10 text-[#A3AAB8] hover:text-white'
                    }`}
                  >
                    <CreditCard className="w-4 h-4" aria-hidden="true" />
                    <span>Cartão</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMethod('boleto')}
                    className={`flex flex-col items-center justify-center gap-1.5 py-3 px-2 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${
                      method === 'boleto'
                        ? 'bg-[#D93811]/15 border-[#D93811] text-white'
                        : 'bg-[#1A1D26] border-white/10 text-[#A3AAB8] hover:text-white'
                    }`}
                  >
                    <Barcode className="w-4 h-4" aria-hidden="true" />
                    <span>Boleto</span>
                  </button>
                </div>

                {method === 'pix' && (
                  <div className="p-4 rounded-xl bg-[#1A1D26] border border-white/10 flex flex-col sm:flex-row items-center gap-4">
                    <PixQrMatrix seed={`${pixKey}-${totalBrl.toFixed(2)}-${cart.length}`} />
                    <div className="flex-1 min-w-0 space-y-2.5 w-full">
                      <p className="text-xs font-medium text-[#F4F5F7]">
                        Copie e cole a chave PIX abaixo para realizar o pagamento:
                      </p>
                      <div className="p-2.5 rounded-lg bg-[#111318] border border-white/10 font-mono text-xs text-white select-all break-all">
                        {pixKey}
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopy(pixKey)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#252935] hover:bg-[#313646] text-xs font-medium text-white cursor-pointer"
                      >
                        {copiedCode ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        <span>{copiedCode ? 'Chave PIX copiada' : 'Copiar Chave PIX'}</span>
                      </button>
                    </div>
                  </div>
                )}

                {method === 'card' && (
                  <div className="p-4 rounded-xl bg-[#1A1D26] border border-white/10 space-y-3">
                    <div>
                      <label className="block text-xs text-[#A3AAB8] mb-1">
                        Nome impresso no cartão
                      </label>
                      <input
                        type="text"
                        value={cardName}
                        onChange={(e) => setCardName(e.target.value)}
                        placeholder="Nome completo"
                        className="w-full px-3 py-2 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-[#A3AAB8] mb-1">Número do cartão</label>
                      <input
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="0000 0000 0000 0000"
                        maxLength={19}
                        className="w-full px-3 py-2 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs text-[#A3AAB8] mb-1">Validade</label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          placeholder="MM/AA"
                          maxLength={5}
                          className="w-full px-3 py-2 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-[#A3AAB8] mb-1">CVV</label>
                        <input
                          type="password"
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value)}
                          placeholder="123"
                          maxLength={4}
                          className="w-full px-3 py-2 bg-[#111318] border border-white/10 rounded-lg font-mono text-sm text-white focus:outline-none focus:border-[#D93811]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-[#A3AAB8] mb-1">Parcelas</label>
                        <select
                          value={installments}
                          onChange={(e) => setInstallments(e.target.value)}
                          className="w-full px-2 py-2 bg-[#111318] border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#D93811]"
                        >
                          <option value="1">1x sem juros</option>
                          <option value="2">2x sem juros</option>
                          <option value="3">3x sem juros</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {method === 'boleto' && (
                  <div className="p-4 rounded-xl bg-[#1A1D26] border border-white/10 space-y-3">
                    <p className="text-xs text-[#D1D5DB]">
                      Linha digitável gerada para pagamento em qualquer banco ou aplicativo:
                    </p>
                    <div className="p-2.5 rounded-lg bg-[#111318] border border-white/10 font-mono text-xs text-[#F4F5F7] break-all">
                      {boletoCode}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(boletoCode)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#252935] hover:bg-[#313646] text-xs font-medium text-white cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copiedCode ? 'Linha copiada' : 'Copiar linha digitável'}</span>
                    </button>
                  </div>
                )}

                {formError && (
                  <p className="text-xs text-red-400 font-medium" role="alert">
                    {formError}
                  </p>
                )}
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        {!paidItems && cart.length > 0 && (
          <div className="px-6 py-4 border-t border-white/10 bg-[#101218] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#A3AAB8]">Total a pagar</span>
              <span className="font-mono text-lg font-bold tabular-nums text-white">
                {formatBrl(totalBrl)}
              </span>
            </div>

            <button
              type="button"
              disabled={processing}
              onClick={handleSubmit}
              className="w-full py-3 px-4 min-h-[44px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] disabled:opacity-60 text-sm font-semibold text-white transition-colors cursor-pointer"
            >
              {processing
                ? 'Confirmando pagamento...'
                : method === 'pix'
                  ? 'Confirmar Pagamento PIX'
                  : method === 'card'
                    ? 'Finalizar no Cartão'
                    : 'Confirmar Pagamento Boleto'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
