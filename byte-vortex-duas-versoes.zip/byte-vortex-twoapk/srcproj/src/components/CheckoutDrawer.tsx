import { Download, Trash2, X } from 'lucide-react';
import type { AppSessionUser, CartEntry } from '../types';
import { formatBrl, triggerFileDownload } from '../utils/formatters';
import { MediaImage } from './MediaImage';

interface CheckoutDrawerProps {
  isOpen: boolean;
  cart: CartEntry[];
  user: AppSessionUser | null;
  onClose: () => void;
  onRemoveItem: (itemId: string) => void;
  onSwitchToFree: (entry: CartEntry) => void;
  onOpenEmailAuth: () => void;
}

export function CheckoutDrawer({
  isOpen,
  cart,
  user,
  onClose,
  onRemoveItem,
  onSwitchToFree,
  onOpenEmailAuth,
}: CheckoutDrawerProps) {
  if (!isOpen) return null;

  const handleCloseDrawer = () => { onClose(); };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Sacola"
    >
      <div className="w-full max-w-lg h-full bg-[#13151B] border-l border-white/15 flex flex-col">
        {/* Drawer header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-[#F4F5F7]">
              Sacola
            </h2>
            <p className="text-xs text-[#9CA3AF]">
              Veja a opção gratuita; pagamentos online ainda não estão habilitados.
            </p>
          </div>
          <button
            type="button"
            onClick={handleCloseDrawer}
            aria-label="Fechar sacola"
            className="p-2 rounded-lg text-[#A3AAB8] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {cart.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <p className="text-base font-medium text-[#F4F5F7]">Sua sacola está vazia.</p>
              <p className="text-sm text-[#9CA3AF]">
                Baixe qualquer versão gratuita diretamente no catálogo.
              </p>
            </div>
          ) : (
            <>
              {/* Cart items */}
              <div className="space-y-3">
                {cart.map((entry) => (
                  <div
                    key={entry.itemId}
                    className="p-3.5 rounded-xl bg-[#1A1D26] border border-white/10 space-y-3"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-16 h-12 rounded-md overflow-hidden bg-[#111318] shrink-0">
                        <MediaImage
                          src={entry.coverUrl}
                          alt={entry.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-[#F4F5F7] truncate">
                          {entry.title}
                        </p>
                        <p className="text-xs text-[#9CA3AF] truncate">{entry.subtitle}</p>
                        <p className="mt-0.5 font-mono text-xs font-semibold tabular-nums text-white">
                          {formatBrl(entry.priceBrl)}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(entry.itemId)}
                        aria-label={`Remover ${entry.title}`}
                        className="p-2 text-[#9CA3AF] hover:text-red-400 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Explicit option to download Free version instead of paying */}
                    {entry.freeDownloadUrl && (
                      <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-2">
                        <span className="text-xs text-[#A3AAB8]">
                          Prefere a versão gratuita?
                        </span>
                        <button
                          type="button"
                          onClick={() => onSwitchToFree(entry)}
                          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#F4F5F7] hover:text-[#D93811] underline underline-offset-4 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Baixar Versão Gratuita</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Optional Sign-In to save purchases in cloud */}
              {!user && (
                <div className="p-4 rounded-xl bg-[#1A1D26] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <p className="text-xs text-[#A3AAB8]">
                    Entre com seu e-mail para salvar suas licenças na nuvem e recuperá-las em outro aparelho.
                  </p>
                  <button
                    type="button"
                    onClick={onOpenEmailAuth}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white whitespace-nowrap cursor-pointer transition-colors"
                  >
                    Entrar com e-mail
                  </button>
                </div>
              )}

              <div className="p-4 rounded-xl bg-amber-950/35 border border-amber-500/25 space-y-2">
                <p className="text-sm font-semibold text-amber-100">Compra online ainda não habilitada</p>
                <p className="text-xs leading-relaxed text-amber-100/80">
                  Nenhum pagamento é processado aqui. Não envie dados de cartão nem faça PIX com os dados desta tela. Para baixar agora, use o botão da versão gratuita abaixo. O botão de compra só poderá liberar a versão Pro depois da integração com um provedor de pagamento real.
                </p>
              </div>


            </>
          )}
        </div>


      </div>
    </div>
  );
}
