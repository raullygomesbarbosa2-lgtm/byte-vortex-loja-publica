import { useState } from 'react';
import { Gamepad2 } from 'lucide-react';

interface MediaImageProps {
  src: string;
  alt: string;
  className?: string;
}

export function MediaImage({ src, alt, className = '' }: MediaImageProps) {
  const [hasError, setHasError] = useState(false);

  if (!src || hasError) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-[#14161D] text-[#8E95A5] select-none ${className}`}
        role="img"
        aria-label={alt}
      >
        <Gamepad2 className="w-8 h-8 mb-2 text-[#D93811]/80" aria-hidden="true" />
        <span className="text-xs font-medium px-4 text-center line-clamp-2">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
