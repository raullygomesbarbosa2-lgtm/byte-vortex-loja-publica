import { ArrowDown, Download } from 'lucide-react';
import { HERO_SHOWCASE_IMAGE } from '../data/starterCatalog';
import { MediaImage } from './MediaImage';

interface HeroSectionProps {
  onExploreCatalog: () => void;
  onJumpToApk: () => void;
}

export function HeroSection({ onExploreCatalog, onJumpToApk }: HeroSectionProps) {
  return (
    <section id="top" className="border-b border-white/10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-12 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left column: Editorial storefront pitch */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <p className="text-xs font-mono tracking-wide text-[#A3AAB8] mb-3">
              Acesso público · Emuladores, jogos e Android APK
            </p>
            <h1 className="font-display text-[clamp(2.25rem,3.8vw,3.4rem)] font-bold leading-[1.08] tracking-tight text-[#F4F5F7] text-balance max-w-xl">
              Encontre emuladores e jogos na Byte Vortex.
            </h1>
            <p className="mt-5 text-base leading-relaxed text-[#A3AAB8] max-w-lg">
              Explore o catálogo público e baixe os itens gratuitos publicados pelo administrador. Pagamentos ainda não estão disponíveis.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onExploreCatalog}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                <span>Explorar Catálogo</span>
                <ArrowDown className="w-4 h-4" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={onJumpToApk}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-lg bg-[#171920] hover:bg-[#20232D] border border-white/15 text-[#F4F5F7] text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#D93811]"
              >
                <Download className="w-4 h-4" aria-hidden="true" />
                <span>Baixar App APK</span>
              </button>
            </div>
          </div>

          {/* Right column: Full-height hardware focal image */}
          <div className="lg:col-span-6 flex">
            <div className="relative w-full aspect-[16/10] lg:aspect-auto lg:min-h-[380px] rounded-xl overflow-hidden bg-[#171920] border border-white/10">
              <MediaImage
                src={HERO_SHOWCASE_IMAGE}
                alt="Console portátil Byte Vortex com controle sem fio sobre superfície escura"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0E0F13]/85 via-[#0E0F13]/20 to-transparent pointer-events-none" />
              <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs font-mono text-[#D1D5DB]">
                    Plataforma Unificada · Android &amp; PC
                  </p>
                  <p className="text-sm font-semibold text-white mt-0.5">
                    Catálogo público da Byte Vortex
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
