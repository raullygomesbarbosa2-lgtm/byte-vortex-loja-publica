import { ArrowDown, Download } from 'lucide-react';

interface HeroSectionProps {
  onExploreCatalog: () => void;
  onJumpToApk: () => void;
}

export function HeroSection({ onExploreCatalog, onJumpToApk }: HeroSectionProps) {
  return (
    <section id="top" className="border-b border-white/10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-12 lg:py-16">
        <div className="max-w-2xl">
          <p className="text-xs font-mono tracking-wide text-[#A3AAB8] mb-3">
            Byte Vortex · Loja pública de emuladores, jogos e Android APK
          </p>
          <h1 className="font-display text-[clamp(2.25rem,3.8vw,3.3rem)] font-bold leading-[1.08] tracking-tight text-[#F4F5F7] text-balance">
            Emuladores e jogos publicados pelo administrador.
          </h1>
          <p className="mt-4 text-base leading-relaxed text-[#A3AAB8]">
            Acesso aberto para todos os usuários. Baixe gratuitamente os itens liberados ou desbloqueie versões Pro via PIX, cartão de crédito e boleto.
          </p>

          <div className="mt-7 flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={onExploreCatalog}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              <span>Ver Catálogo</span>
              <ArrowDown className="w-4 h-4" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={onJumpToApk}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-lg bg-[#171920] hover:bg-[#20232D] border border-white/15 text-[#F4F5F7] text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#D93811]"
            >
              <Download className="w-4 h-4" aria-hidden="true" />
              <span>Baixar App APK</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
