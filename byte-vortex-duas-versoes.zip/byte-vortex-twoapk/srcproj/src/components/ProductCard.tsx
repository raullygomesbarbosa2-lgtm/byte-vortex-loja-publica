import { Check, Download, Pencil, ShoppingCart, Trash2 } from 'lucide-react';
import type { CatalogItem } from '../types';
import { formatBrl } from '../utils/formatters';
import { MediaImage } from './MediaImage';

interface ProductCardProps {
  item: CatalogItem;
  isUnlockedPro: boolean;
  isAdmin: boolean;
  onSelectDetail: (item: CatalogItem) => void;
  onDownloadFree: (item: CatalogItem) => void;
  onBuyPro: (item: CatalogItem) => void;
  onDownloadPro: (item: CatalogItem) => void;
  onEditItem?: (item: CatalogItem) => void;
  onDeleteItem?: (item: CatalogItem) => void;
}

export function ProductCard({
  item,
  isUnlockedPro,
  isAdmin,
  onSelectDetail,
  onDownloadFree,
  onBuyPro,
  onDownloadPro,
  onEditItem,
  onDeleteItem,
}: ProductCardProps) {
  const categoryLabel =
    item.category === 'emulator' ? 'Emulador' : item.category === 'apk' ? 'APK' : 'Jogo';

  const hasFreeOption = item.accessModel === 'free' || item.accessModel === 'freemium';
  const hasPaidOption = item.accessModel === 'paid' || item.accessModel === 'freemium';

  return (
    <article className="group flex flex-col bg-[#16181F] border border-white/10 rounded-xl overflow-hidden transition-transform duration-200 hover:-translate-y-0.5">
      {/* Media frame (65%+ visual weight) */}
      <button
        type="button"
        onClick={() => onSelectDetail(item)}
        className="relative w-full aspect-[4/3] bg-[#111318] overflow-hidden cursor-pointer text-left focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-[#D93811]"
      >
        <MediaImage
          src={item.coverUrl}
          alt={item.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
        />
      </button>

      {/* Card content */}
      <div className="p-5 flex-1 flex flex-col justify-between gap-4">
        <div>
          {/* Unboxed clean metadata line (zero pills) */}
          <div className="flex items-center flex-wrap gap-1.5 text-xs font-mono text-[#9CA3AF]">
            <span>{categoryLabel}</span>
            <span aria-hidden="true">·</span>
            <span>{item.platform}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{item.version}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{item.fileSize}</span>
          </div>

          <button
            type="button"
            onClick={() => onSelectDetail(item)}
            className="mt-2 text-left block w-full cursor-pointer"
          >
            <h3 className="font-display text-lg font-semibold text-[#F4F5F7] group-hover:text-white truncate">
              {item.title}
            </h3>
          </button>

          <p className="mt-1 text-sm text-[#A3AAB8] line-clamp-2 leading-relaxed">
            {item.subtitle}
          </p>
        </div>

        {/* Pricing & Download / Purchase Footer */}
        <div className="pt-4 border-t border-white/10 space-y-3">
          <div className="flex items-baseline justify-between gap-3">
            <span className="text-xs text-[#9CA3AF]">
              {item.accessModel === 'free'
                ? 'Edição Gratuita'
                : item.accessModel === 'freemium'
                  ? 'Grátis ou Edição Pro'
                  : 'Licença Pro Completa'}
            </span>
            <span className="font-mono text-sm font-semibold tabular-nums text-[#F4F5F7]">
              {item.accessModel === 'free' ? 'Grátis' : formatBrl(item.priceBrl)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {hasFreeOption && (
              <button
                type="button"
                onClick={() => onDownloadFree(item)}
                className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2.5 min-h-[40px] rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white ${
                  item.accessModel === 'free'
                    ? 'bg-[#D93811] hover:bg-[#BF2F0C] text-white'
                    : 'bg-[#21242E] hover:bg-[#2A2E3B] text-[#F4F5F7] border border-white/10'
                }`}
              >
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Baixar Grátis</span>
              </button>
            )}

            {hasPaidOption &&
              (isUnlockedPro ? (
                <button
                  type="button"
                  onClick={() => onDownloadPro(item)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2.5 min-h-[40px] rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Baixar Pro</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onBuyPro(item)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2.5 min-h-[40px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  <ShoppingCart className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Comprar Pro</span>
                </button>
              ))}
          </div>

          {/* Admin controls for persisted Firestore items */}
          {isAdmin && !item.isStarter && (
            <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => onEditItem?.(item)}
                className="inline-flex items-center gap-1.5 text-xs text-[#A3AAB8] hover:text-white transition-colors cursor-pointer py-1"
              >
                <Pencil className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Editar</span>
              </button>
              <button
                type="button"
                onClick={() => onDeleteItem?.(item)}
                className="inline-flex items-center gap-1.5 text-xs text-red-400 hover:text-red-300 transition-colors cursor-pointer py-1"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Excluir</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}
