import { Check, Download, Lock, ShoppingCart, Smartphone, Upload } from 'lucide-react';
import { APK_SHOWCASE_IMAGE } from '../data/starterCatalog';
import type { AppRelease } from '../types';
import { formatBrl } from '../utils/formatters';
import { MediaImage } from './MediaImage';

interface ApkShowcaseSectionProps {
  release: AppRelease | null;
  isProUnlocked: boolean;
  isAdmin: boolean;
  onDownloadFreeApk: () => void;
  onBuyProApk: () => void;
  onDownloadProApk: () => void;
  onOpenAdminApk: () => void;
}

export function ApkShowcaseSection({
  release,
  isProUnlocked,
  isAdmin,
  onDownloadFreeApk,
  onBuyProApk,
  onDownloadProApk,
  onOpenAdminApk,
}: ApkShowcaseSectionProps) {
  if (!release) {
    return (
      <section id="apk" className="border-b border-white/10">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14 lg:py-20">
          <div className="py-12 px-6 text-center bg-[#16181F] border border-white/10 rounded-xl space-y-4">
            <h2 className="font-display text-2xl font-bold text-[#F4F5F7]">
              Aplicativo Byte Vortex APK
            </h2>
            <p className="text-sm text-[#A3AAB8] max-w-md mx-auto">
              Nenhum APK publicado ainda. Assim que o administrador enviar o arquivo oficial, os downloads gratuito e Pro ficarão disponíveis aqui.
            </p>
            <button
              type="button"
              onClick={onOpenAdminApk}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white transition-colors cursor-pointer"
            >
              {isAdmin ? (
                <Upload className="w-4 h-4" aria-hidden="true" />
              ) : (
                <Lock className="w-4 h-4" aria-hidden="true" />
              )}
              <span>{isAdmin ? 'Publicar APK Oficial' : 'Publicar APK (Admin)'}</span>
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="apk" className="border-b border-white/10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left: Smartphone + controller showcase */}
          <div className="lg:col-span-5 flex">
            <div className="w-full aspect-[4/3] lg:aspect-auto rounded-xl overflow-hidden bg-[#16181F] border border-white/10">
              <MediaImage
                src={APK_SHOWCASE_IMAGE}
                alt="Aplicativo Byte Vortex APK"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Right: APK Free & Pro release details */}
          <div className="lg:col-span-7 flex flex-col justify-between gap-6">
            <div>
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <p className="text-xs font-mono text-[#A3AAB8]">
                  Aplicativo Oficial Android · {release.version} · {release.fileSize}
                </p>
                {isAdmin && (
                  <button
                    type="button"
                    onClick={onOpenAdminApk}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1F222C] hover:bg-[#2A2E3B] border border-white/10 text-xs font-medium text-[#F4F5F7] transition-colors cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Atualizar APK</span>
                  </button>
                )}
              </div>

              <h2 className="mt-3 font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5F7] text-balance">
                {release.title} — Download Direto em APK
              </h2>
              <p className="mt-3 text-sm sm:text-base text-[#A3AAB8] leading-relaxed">
                {release.changelog}
              </p>

              {/* Technical specification strip */}
              <dl className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-4 py-4 border-y border-white/10">
                <div>
                  <dt className="text-xs text-[#9CA3AF]">Compatibilidade</dt>
                  <dd className="mt-1 text-sm font-medium text-[#F4F5F7]">{release.androidMin}</dd>
                </div>
                <div>
                  <dt className="text-xs text-[#9CA3AF]">Versão atual</dt>
                  <dd className="mt-1 font-mono text-sm tabular-nums text-[#F4F5F7]">
                    {release.version}
                  </dd>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <dt className="text-xs text-[#9CA3AF]">Assinatura SHA-256</dt>
                  <dd className="mt-1 font-mono text-xs tabular-nums text-[#A3AAB8] truncate">
                    {release.sha256}
                  </dd>
                </div>
              </dl>
            </div>

            {/* Dual Free & Paid APK action block */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#16181F] border border-white/10 flex flex-col justify-between gap-4">
                  <div>
                    <div className="flex items-baseline justify-between gap-2">
                      <h3 className="text-sm font-semibold text-[#F4F5F7]">APK Gratuito</h3>
                      <span className="font-mono text-sm font-semibold text-[#F4F5F7]">Grátis</span>
                    </div>
                    <p className="mt-1 text-xs text-[#A3AAB8] leading-relaxed">
                      Versão gratuita do aplicativo oficial em APK para baixar sem custo.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={onDownloadFreeApk}
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 min-h-[42px] rounded-lg bg-[#232632] hover:bg-[#2E3242] border border-white/10 text-xs font-semibold text-white transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <Download className="w-4 h-4" aria-hidden="true" />
                    <span>Baixar APK Grátis</span>
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-[#16181F] border border-[#D93811]/45 flex flex-col justify-between gap-4">
                  <div>
                    <div className="flex items-baseline justify-between gap-2">
                      <h3 className="text-sm font-semibold text-[#F4F5F7]">APK Pro Completo</h3>
                      <span className="font-mono text-sm font-semibold tabular-nums text-[#F4F5F7]">
                        {formatBrl(release.proPriceBrl)}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-[#A3AAB8] leading-relaxed">
                      Versão Pro completa desbloqueada após pagamento.
                    </p>
                  </div>

                  {isProUnlocked ? (
                    <button
                      type="button"
                      onClick={onDownloadProApk}
                      className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 min-h-[42px] rounded-lg bg-emerald-700 hover:bg-emerald-600 text-xs font-semibold text-white transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <Check className="w-4 h-4" aria-hidden="true" />
                      <span>Baixar APK Pro</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={onBuyProApk}
                      className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <ShoppingCart className="w-4 h-4" aria-hidden="true" />
                      <span>Comprar APK Pro</span>
                    </button>
                  )}
                </div>
              </div>

              <p className="flex items-center gap-2 text-xs text-[#8E95A5]">
                <Smartphone className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>
                  Instalação no Android: baixe o arquivo .apk, autorize fontes desconhecidas no navegador e toque em Instalar.
                </span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
