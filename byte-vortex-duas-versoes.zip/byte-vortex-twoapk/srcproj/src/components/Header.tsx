import { ShoppingBag, User } from 'lucide-react';
import type { AppSessionUser } from '../types';

interface HeaderProps {
  cartCount: number;
  user: AppSessionUser | null;
  isAdmin: boolean;
  onOpenCart: () => void;
  onNavigateCatalog: (filter?: 'all' | 'emulator' | 'game') => void;
  onNavigateApk: () => void;
  onOpenAdmin: () => void;
}

export function Header({
  cartCount,
  user,
  isAdmin,
  onOpenCart,
  onNavigateCatalog,
  onNavigateApk,
  onOpenAdmin,
}: HeaderProps) {
  const accountLabel = isAdmin ? 'Admin' : user ? 'Conta' : 'Entrar';

  return (
    <header className="sticky top-0 z-40 bg-[#0E0F13]/92 backdrop-blur-md border-b border-white/10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Brand wordmark (single text element) */}
        <a
          href="#top"
          className="font-display text-lg font-bold tracking-tight text-[#F4F5F7] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#D93811]"
        >
          Byte Vortex
        </a>

        {/* Zone 2: Concise single-line navigation links */}
        <nav
          aria-label="Navegação principal"
          className="hidden md:flex items-center gap-6 text-sm font-medium text-[#A3AAB8]"
        >
          <a
            href="#catalogo"
            onClick={() => onNavigateCatalog('all')}
            className="hover:text-[#F4F5F7] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Catálogo
          </a>
          <a
            href="#catalogo"
            onClick={() => onNavigateCatalog('emulator')}
            className="hover:text-[#F4F5F7] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Emuladores
          </a>
          <a
            href="#catalogo"
            onClick={() => onNavigateCatalog('game')}
            className="hover:text-[#F4F5F7] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Jogos
          </a>
          <a
            href="#apk"
            onClick={(e) => {
              e.preventDefault();
              onNavigateApk();
            }}
            className="hover:text-[#F4F5F7] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            App APK
          </a>
        </nav>

        {/* Zone 3: Account access link + single primary action button */}
        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          <button
            type="button"
            onClick={onOpenAdmin}
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-medium text-[#D1D5DB] hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#D93811]"
          >
            <User className="w-4 h-4 text-[#A3AAB8]" aria-hidden="true" />
            <span>{accountLabel}</span>
          </button>

          <button
            type="button"
            onClick={onOpenCart}
            className="inline-flex items-center gap-2 px-4 py-2 min-h-[40px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
          >
            <ShoppingBag className="w-4 h-4" aria-hidden="true" />
            <span className="tabular-nums">Sacola ({cartCount})</span>
          </button>
        </div>
      </div>
    </header>
  );
}
