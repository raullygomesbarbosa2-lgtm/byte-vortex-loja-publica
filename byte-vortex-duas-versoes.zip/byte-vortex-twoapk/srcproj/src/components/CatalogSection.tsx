import { Lock, Search, Upload } from 'lucide-react';
import type { CatalogItem } from '../types';
import { ProductCard } from './ProductCard';

export type CatalogFilter = 'all' | 'emulator' | 'game' | 'free' | 'paid';

interface CatalogSectionProps {
  items: CatalogItem[];
  totalCount: number;
  loading: boolean;
  filter: CatalogFilter;
  searchQuery: string;
  isAdmin: boolean;
  unlockedIds: Set<string>;
  onFilterChange: (filter: CatalogFilter) => void;
  onSearchChange: (q: string) => void;
  onOpenAdminUpload: () => void;
  onSelectDetail: (item: CatalogItem) => void;
  onDownloadFree: (item: CatalogItem) => void;
  onBuyPro: (item: CatalogItem) => void;
  onDownloadPro: (item: CatalogItem) => void;
  onEditItem: (item: CatalogItem) => void;
  onDeleteItem: (item: CatalogItem) => void;
}

const FILTER_TABS: Array<{ id: CatalogFilter; label: string }> = [
  { id: 'all', label: 'Todos' },
  { id: 'emulator', label: 'Emuladores' },
  { id: 'game', label: 'Jogos' },
  { id: 'free', label: 'Gratuitos' },
  { id: 'paid', label: 'Versão Paga' },
];

export function CatalogSection({
  items,
  totalCount,
  loading,
  filter,
  searchQuery,
  isAdmin,
  unlockedIds,
  onFilterChange,
  onSearchChange,
  onOpenAdminUpload,
  onSelectDetail,
  onDownloadFree,
  onBuyPro,
  onDownloadPro,
  onEditItem,
  onDeleteItem,
}: CatalogSectionProps) {
  return (
    <section id="catalogo" className="border-b border-white/10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14 lg:py-20">
        {/* Section header + Admin Upload trigger */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5F7] text-balance">
              Catálogo Público de Emuladores e Jogos
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#A3AAB8] max-w-2xl">
              Veja downloads gratuitos publicados. Compras e pagamentos estão desativados; o catálogo depende de configuração.
            </p>
          </div>

          <button
            type="button"
            onClick={onOpenAdminUpload}
            className={`inline-flex items-center justify-center gap-2 px-4 py-2.5 min-h-[44px] rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white ${
              isAdmin
                ? 'bg-[#D93811] hover:bg-[#BF2F0C] text-white'
                : 'bg-[#171920] hover:bg-[#20232D] text-[#E5E7EB] border border-white/15'
            }`}
          >
            {isAdmin ? (
              <Upload className="w-4 h-4" aria-hidden="true" />
            ) : (
              <Lock className="w-4 h-4 text-[#A3AAB8]" aria-hidden="true" />
            )}
            <span>{isAdmin ? 'Fazer Upload de Emulador' : 'Upload Admin'}</span>
          </button>
        </div>

        {/* Filter tabs & search bar */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8 pb-6 border-b border-white/10">
          <div
            role="tablist"
            aria-label="Filtrar catálogo"
            className="flex items-center gap-1 p-1 bg-[#16181F] border border-white/10 rounded-lg overflow-x-auto"
          >
            {FILTER_TABS.map((tab) => {
              const active = filter === tab.id;
              return (
                <button
                  key={tab.id}
                  role="tab"
                  aria-selected={active}
                  type="button"
                  onClick={() => onFilterChange(tab.id)}
                  className={`px-3.5 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-[#252935] text-white'
                      : 'text-[#A3AAB8] hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          <div className="relative w-full lg:w-80">
            <Search
              className="w-4 h-4 text-[#8E95A5] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Buscar emulador, jogo ou console..."
              aria-label="Buscar no catálogo"
              className="w-full pl-10 pr-4 py-2.5 min-h-[42px] bg-[#16181F] border border-white/10 rounded-lg text-sm text-[#F4F5F7] placeholder:text-[#6B7280] focus:outline-none focus:border-[#D93811]"
            />
          </div>
        </div>

        {/* Product grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((idx) => (
              <div
                key={idx}
                className="h-[420px] rounded-xl bg-[#16181F] border border-white/10 animate-pulse"
              />
            ))}
          </div>
        ) : totalCount === 0 ? (
          <div className="py-16 px-6 text-center bg-[#16181F] border border-white/10 rounded-xl space-y-4">
            <p className="text-base font-semibold text-[#F4F5F7]">
              Nenhum emulador ou jogo publicado ainda.
            </p>
            <p className="text-sm text-[#A3AAB8] max-w-md mx-auto">
              O catálogo começa vazio até que o administrador autorizado publique os primeiros emuladores e jogos.
            </p>
            <button
              type="button"
              onClick={onOpenAdminUpload}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[42px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-xs font-semibold text-white transition-colors cursor-pointer"
            >
              {isAdmin ? (
                <Upload className="w-4 h-4" aria-hidden="true" />
              ) : (
                <Lock className="w-4 h-4" aria-hidden="true" />
              )}
              <span>{isAdmin ? 'Publicar Primeiro Emulador' : 'Entrar como Admin para Publicar'}</span>
            </button>
          </div>
        ) : items.length === 0 ? (
          <div className="py-16 px-6 text-center bg-[#16181F] border border-white/10 rounded-xl">
            <p className="text-base font-medium text-[#F4F5F7]">
              Nenhum item encontrado para este filtro.
            </p>
            <p className="mt-1 text-sm text-[#A3AAB8]">
              Limpe a busca ou altere a categoria selecionada.
            </p>
            <button
              type="button"
              onClick={() => {
                onFilterChange('all');
                onSearchChange('');
              }}
              className="mt-5 px-4 py-2 min-h-[40px] rounded-lg bg-[#252935] hover:bg-[#303545] text-xs font-semibold text-white transition-colors cursor-pointer"
            >
              Mostrar todos os itens
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((item) => (
              <ProductCard
                key={item.id}
                item={item}
                isUnlockedPro={unlockedIds.has(item.id)}
                isAdmin={isAdmin}
                onSelectDetail={onSelectDetail}
                onDownloadFree={onDownloadFree}
                onBuyPro={onBuyPro}
                onDownloadPro={onDownloadPro}
                onEditItem={onEditItem}
                onDeleteItem={onDeleteItem}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
