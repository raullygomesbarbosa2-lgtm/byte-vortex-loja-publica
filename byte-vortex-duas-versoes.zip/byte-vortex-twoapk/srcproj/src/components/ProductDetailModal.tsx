import { Check, Download, ShoppingCart, Star, X } from 'lucide-react';
import type { CatalogItem } from '../types';
import { formatBrl } from '../utils/formatters';
import { MediaImage } from './MediaImage';

interface ProductDetailModalProps {
  item: CatalogItem | null;
  isUnlockedPro: boolean;
  onClose: () => void;
  onDownloadFree: (item: CatalogItem) => void;
  onBuyPro: (item: CatalogItem) => void;
  onDownloadPro: (item: CatalogItem) => void;
}

export function ProductDetailModal({
  item,
  isUnlockedPro,
  onClose,
  onDownloadFree,
  onBuyPro,
  onDownloadPro,
}: ProductDetailModalProps) {
  if (!item) return null;

  const hasFreeOption = item.accessModel === 'free' || item.accessModel === 'freemium';
  const hasPaidOption = item.accessModel === 'paid' || item.accessModel === 'freemium';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="detail-modal-title"
    >
      <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-[#16181F] border border-white/15 rounded-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <span className="text-xs font-mono text-[#9CA3AF]">
            {item.platform} · {item.version} · {item.fileSize}
          </span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar detalhes"
            className="p-2 rounded-lg text-[#A3AAB8] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-5">
            <div className="aspect-[4/3] rounded-lg overflow-hidden bg-[#111318] border border-white/10">
              <MediaImage
                src={item.coverUrl}
                alt={item.title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="md:col-span-7 flex flex-col justify-between gap-5">
            <div>
              <h3
                id="detail-modal-title"
                className="font-display text-2xl font-bold text-[#F4F5F7]"
              >
                {item.title}
              </h3>
              <p className="mt-1 text-sm font-medium text-[#D1D5DB]">{item.subtitle}</p>
              <div className="mt-3 flex flex-wrap gap-3" aria-label="Legenda das versões">
                {hasFreeOption && <span className="inline-flex items-center gap-1.5 rounded-full border border-sky-300/20 bg-sky-400/10 px-3 py-1.5 text-xs font-bold text-sky-300"><Star className="h-4 w-4 fill-sky-300 text-sky-300 drop-shadow-[0_0_7px_rgba(56,189,248,0.95)]" aria-hidden="true" />GRÁTIS / BETA · estrela azul</span>}
                {hasPaidOption && <span className="inline-flex items-center gap-1.5 rounded-full border border-lime-300/20 bg-lime-400/10 px-3 py-1.5 text-xs font-bold text-lime-300"><Star className="h-4 w-4 fill-lime-300 text-lime-300 drop-shadow-[0_0_7px_rgba(163,230,53,0.95)]" aria-hidden="true" />PRO · estrela verde</span>}
              </div>
              <p className="mt-4 text-sm text-[#A3AAB8] leading-relaxed whitespace-pre-line">
                {item.description}
              </p>

              {item.features.length > 0 && (
                <ul className="mt-5 space-y-2 border-t border-white/10 pt-4">
                  {item.features.map((feat, idx) => (
                    <li
                      key={idx}
                      className="flex items-start gap-2 text-xs sm:text-sm text-[#D1D5DB]"
                    >
                      <Check
                        className="w-4 h-4 text-[#D93811] shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#9CA3AF]">
                  {item.accessModel === 'free'
                    ? 'Disponível gratuitamente'
                    : item.accessModel === 'freemium'
                      ? 'Escolha grátis/Beta (azul) ou Pro (verde)'
                      : 'Versão Paga (Licença Vitalícia)'}
                </span>
                <span className="font-mono text-lg font-bold tabular-nums text-white">
                  {item.accessModel === 'free' ? 'Grátis' : formatBrl(item.priceBrl)}
                </span>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                {hasFreeOption && (
                  <button
                    type="button"
                    onClick={() => {
                      onDownloadFree(item);
                      onClose();
                    }}
                    className={`flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 min-h-[44px] rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                      item.accessModel === 'free'
                        ? 'bg-[#D93811] hover:bg-[#BF2F0C] text-white'
                        : 'bg-[#232632] hover:bg-[#2E3242] text-white border border-white/10'
                    }`}
                  >
                    <Download className="w-4 h-4" aria-hidden="true" />
                    <span>Baixar Versão Gratuita</span>
                  </button>
                )}

                {hasPaidOption &&
                  (isUnlockedPro ? (
                    <button
                      type="button"
                      onClick={() => {
                        onDownloadPro(item);
                        onClose();
                      }}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 min-h-[44px] rounded-lg bg-emerald-700 hover:bg-emerald-600 text-sm font-semibold text-white transition-colors cursor-pointer"
                    >
                      <Check className="w-4 h-4" aria-hidden="true" />
                      <span>Baixar Versão Pro</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        onBuyPro(item);
                        onClose();
                      }}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 min-h-[44px] rounded-lg bg-[#D93811] hover:bg-[#BF2F0C] text-sm font-semibold text-white transition-colors cursor-pointer"
                    >
                      <ShoppingCart className="w-4 h-4" aria-hidden="true" />
                      <span>Comprar Versão Pro</span>
                    </button>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
