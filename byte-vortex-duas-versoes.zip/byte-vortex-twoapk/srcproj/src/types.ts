import type { User } from 'firebase/auth';

export const ADMIN_EMAIL = 'gomesbarbosaraully@gmail.com';

export interface AppSessionUser {
  uid: string;
  email: string;
  emailVerified: boolean;
  source: 'firebase' | 'email-server';
  firebaseUser?: User;
}

export type CatalogCategory = 'emulator' | 'game' | 'apk';
export type AccessModel = 'free' | 'paid' | 'freemium';
export type PaymentMethod = 'pix' | 'card' | 'boleto';

export interface CatalogItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  category: CatalogCategory;
  platform: string;
  version: string;
  fileSize: string;
  coverUrl: string;
  accessModel: AccessModel;
  priceBrl: number;
  freeDownloadUrl: string;
  freeFileName: string;
  paidDownloadUrl: string;
  paidFileName: string;
  features: string[];
  featured: boolean;
  authorId: string;
  isStarter?: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AppRelease {
  id: string;
  title: string;
  version: string;
  androidMin: string;
  fileSize: string;
  sha256: string;
  freeApkUrl: string;
  freeApkName: string;
  proApkUrl: string;
  proApkName: string;
  proPriceBrl: number;
  changelog: string;
  updatedBy: string;
  updatedAt?: unknown;
}

export interface OrderRecord {
  id: string;
  buyerUid: string;
  itemId: string;
  itemTitle: string;
  edition: 'pro' | 'apk_pro';
  paymentMethod: PaymentMethod;
  amountBrl: number;
  status: 'paid';
  createdAt?: unknown;
}

export interface CartEntry {
  itemId: string;
  title: string;
  subtitle: string;
  coverUrl: string;
  edition: 'pro' | 'apk_pro';
  priceBrl: number;
  paidDownloadUrl: string;
  paidFileName: string;
  freeDownloadUrl?: string;
  freeFileName?: string;
}
