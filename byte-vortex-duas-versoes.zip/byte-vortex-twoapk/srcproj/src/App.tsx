import { useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  applyFirebaseVerifyEmailCode,
  auth,
  completeGoogleRedirectResult,
  confirmFirebasePasswordReset,
  confirmUnlimitedPasswordReset,
  createUnlimitedResetLink,
  db,
  formatGoogleAuthError,
  handleFirestoreError,
  OperationType,
  registerWithEmail,
  resendVerificationEmail,
  resetPasswordByEmail,
  restoreEmailServerSession,
  saveEmailServerOrders,
  signInWithEmail,
  signInWithGoogle,
  signOutAccount,
  verifyFirebaseResetCode,
} from './firebase';
import {
  ADMIN_EMAIL,
  type AppRelease,
  type AppSessionUser,
  type CartEntry,
  type CatalogItem,
  type PaymentMethod,
} from './types';
import { APK_SHOWCASE_IMAGE } from './data/starterCatalog';
import { sanitizeItemPayload, triggerFileDownload } from './utils/formatters';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { CatalogSection, type CatalogFilter } from './components/CatalogSection';
import { ApkShowcaseSection } from './components/ApkShowcaseSection';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CheckoutDrawer } from './components/CheckoutDrawer';
import { AdminUploadModal } from './components/AdminUploadModal';

const LOCAL_UNLOCKED_KEY = 'byte_vortex_unlocked_v1';
const LEGACY_EXAMPLE_IDS = new Set([
  'vortexstation-x1',
  'supervortex-16',
  'apex-drift-94',
  'obsidian-citadel',
]);
const LEGACY_EXAMPLE_TITLES = new Set([
  'vortexstation x1',
  'supervortex 16',
  'apex drift 94',
  'obsidian citadel: cinder oath',
]);

function readLocalUnlocked(): string[] {
  try {
    const raw = localStorage.getItem(LOCAL_UNLOCKED_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

export default function App() {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [emailUser, setEmailUser] = useState<AppSessionUser | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [, setAuthRefreshTick] = useState(0);

  const [firestoreItems, setFirestoreItems] = useState<CatalogItem[]>([]);
  const [catalogLoading, setCatalogLoading] = useState(true);
  const [apkRelease, setApkRelease] = useState<AppRelease | null>(null);

  const [filter, setFilter] = useState<CatalogFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [cart, setCart] = useState<CartEntry[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [checkoutBusy, setCheckoutBusy] = useState(false);

  const [localUnlocked, setLocalUnlocked] = useState<string[]>(() => readLocalUnlocked());
  const [cloudUnlocked, setCloudUnlocked] = useState<string[]>([]);

  const [detailItem, setDetailItem] = useState<CatalogItem | null>(null);
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminInitialTab, setAdminInitialTab] = useState<'catalog' | 'apk'>('catalog');
  const [editingItem, setEditingItem] = useState<CatalogItem | null>(null);
  const [pendingDelete, setPendingDelete] = useState<CatalogItem | null>(null);
  const [pendingReset, setPendingReset] = useState<
    | { kind: 'unlimited'; email: string; token: string }
    | { kind: 'firebase'; email: string; oobCode: string }
    | null
  >(null);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const user: AppSessionUser | null = useMemo(() => {
    if (firebaseUser) {
      return {
        uid: firebaseUser.uid,
        email: firebaseUser.email ?? '',
        emailVerified: firebaseUser.emailVerified,
        source: 'firebase',
        firebaseUser,
      };
    }
    return emailUser;
  }, [firebaseUser, emailUser]);

  const isAdmin = Boolean(
    user &&
      user.source === 'firebase' &&
      user.email.toLowerCase() === ADMIN_EMAIL &&
      user.emailVerified === true
  );

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // Detect unlimited password reset (?bvReset=) or Firebase action links (?mode=...&oobCode=...)
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const token = params.get('bvReset');
      const email = params.get('email');
      if (token && email) {
        setPendingReset({ kind: 'unlimited', email, token });
        setAdminInitialTab('catalog');
        setAdminOpen(true);
        return;
      }

      const mode = params.get('mode');
      const oobCode = params.get('oobCode');
      if (mode === 'resetPassword' && oobCode) {
        verifyFirebaseResetCode(oobCode)
          .then((resolvedEmail) => {
            setPendingReset({ kind: 'firebase', email: resolvedEmail, oobCode });
            setAdminInitialTab('catalog');
            setAdminOpen(true);
          })
          .catch(() => {
            showToast('O link de e-mail do Google expirou. Gere um Link Ilimitado no botão abaixo.');
            setAdminInitialTab('catalog');
            setAdminOpen(true);
          });
      } else if (mode === 'verifyEmail' && oobCode) {
        applyFirebaseVerifyEmailCode(oobCode)
          .then(async () => {
            if (auth.currentUser) {
              await auth.currentUser.reload();
              await auth.currentUser.getIdToken(true);
              setFirebaseUser(auth.currentUser);
              setAuthRefreshTick((t) => t + 1);
            }
            showToast('E-mail confirmado com sucesso!');
          })
          .catch(() => {
            showToast('O link de verificação já foi usado ou expirou.');
          });
      }
    } catch {
      // ignore invalid URL
    }
  }, []);

  // Auth listener (Firebase + redirect completion + isolated Email/Password session restore)
  useEffect(() => {
    completeGoogleRedirectResult().then(({ user: redirectUser, error: redirectError }) => {
      if (redirectUser) {
        setFirebaseUser(redirectUser);
        setAuthReady(true);
      } else if (redirectError?.message) {
        showToast(redirectError.message);
      }
    });
    const unsub = onAuthStateChanged(auth, (nextUser) => {
      setFirebaseUser(nextUser);
      setAuthReady(true);
    });
    restoreEmailServerSession().then((restored) => {
      if (restored) {
        setEmailUser(restored.user);
        if (restored.orders.length > 0) {
          setCloudUnlocked((prev) => Array.from(new Set([...prev, ...restored.orders])));
        }
      }
    });
    return () => unsub();
  }, []);

  // Public catalog listener
  useEffect(() => {
    const catalogRef = collection(db, 'catalog_items');
    const q = query(catalogRef, orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const docs: CatalogItem[] = snapshot.docs
          .filter((d) => {
            const rawTitle = String(d.data().title ?? '').trim().toLowerCase();
            const isLegacy =
              LEGACY_EXAMPLE_IDS.has(d.id) ||
              LEGACY_EXAMPLE_TITLES.has(rawTitle) ||
              String(d.data().authorId ?? '') === 'starter';
            return !isLegacy;
          })
          .map((d) => {
            const data = d.data();
            return {
              id: d.id,
              title: String(data.title ?? ''),
              subtitle: String(data.subtitle ?? ''),
              description: String(data.description ?? ''),
              category: (data.category as CatalogItem['category']) ?? 'emulator',
              platform: String(data.platform ?? ''),
              version: String(data.version ?? 'v1.0.0'),
              fileSize: String(data.fileSize ?? '10 MB'),
              coverUrl: String(data.coverUrl ?? ''),
              accessModel: (data.accessModel as CatalogItem['accessModel']) ?? 'free',
              priceBrl: Number(data.priceBrl ?? 0),
              freeDownloadUrl: String(data.freeDownloadUrl ?? ''),
              freeFileName: String(data.freeFileName ?? ''),
              paidDownloadUrl: String(data.paidDownloadUrl ?? ''),
              paidFileName: String(data.paidFileName ?? ''),
              features: Array.isArray(data.features) ? data.features.map(String) : [],
              featured: Boolean(data.featured),
              authorId: String(data.authorId ?? ''),
              isStarter: false,
              createdAt: data.createdAt,
              updatedAt: data.updatedAt,
            };
          });
        setFirestoreItems(docs);
        setCatalogLoading(false);
      },
      (err) => {
        console.error('Firestore não liberou catálogo público; buscando catálogo JSON publicado.', err);
        fetch('./catalogo.json', { cache: 'no-store' })
          .then((resp) => { if (!resp.ok) throw new Error(`HTTP ${resp.status}`); return resp.json(); })
          .then((rows: unknown) => {
            const docs = Array.isArray(rows) ? rows as CatalogItem[] : [];
            setFirestoreItems(docs.filter((item) => ['free', 'freemium'].includes(item.accessModel) && Boolean(item.freeDownloadUrl)));
          })
          .catch((fallbackErr) => { console.error('Catálogo indisponível:', fallbackErr); setFirestoreItems([]); })
          .finally(() => setCatalogLoading(false));
      }
    );
    return () => unsub();
  }, []);

  // Public APK release listener
  useEffect(() => {
    const apkDocRef = doc(db, 'app_releases', 'byte-vortex-apk');
    const unsub = onSnapshot(
      apkDocRef,
      (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setApkRelease({
            id: snap.id,
            title: String(d.title ?? 'Byte Vortex Mobile'),
            version: String(d.version ?? 'v1.0.0'),
            androidMin: String(d.androidMin ?? 'Android 9.0 ou superior'),
            fileSize: String(d.fileSize ?? ''),
            sha256: String(d.sha256 ?? ''),
            freeApkUrl: String(d.freeApkUrl ?? ''),
            freeApkName: String(d.freeApkName ?? 'byte-vortex-free.apk'),
            proApkUrl: String(d.proApkUrl ?? ''),
            proApkName: String(d.proApkName ?? 'byte-vortex-pro.apk'),
            proPriceBrl: Number(d.proPriceBrl ?? 19.9),
            changelog: String(d.changelog ?? ''),
            updatedBy: String(d.updatedBy ?? ''),
            updatedAt: d.updatedAt,
          });
        } else {
          setApkRelease(null);
        }
      },
      (err) => {
        console.error('Versão APK indisponível:', err);
      }
    );
    return () => unsub();
  }, []);

  // Private orders listener (only when authenticated with Firebase)
  useEffect(() => {
    if (!authReady || !firebaseUser) {
      if (!emailUser) {
        setCloudUnlocked([]);
      }
      return;
    }

    const ordersQuery = query(
      collection(db, 'orders'),
      where('buyerUid', '==', firebaseUser.uid)
    );
    const unsub = onSnapshot(
      ordersQuery,
      (snap) => {
        const ids = snap.docs.map((d) => String(d.data().itemId ?? ''));
        setCloudUnlocked(ids.filter(Boolean));
      },
      (err) => {
        console.error('Pedidos indisponíveis:', err);
      }
    );
    return () => unsub();
  }, [authReady, firebaseUser, emailUser]);

  const activeCatalog = firestoreItems;

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return activeCatalog.filter((item) => {
      if (filter === 'emulator' && item.category !== 'emulator') return false;
      if (filter === 'game' && item.category !== 'game') return false;
      if (filter === 'free' && item.accessModel === 'paid') return false;
      if (filter === 'paid' && item.accessModel === 'free') return false;

      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q) ||
        item.platform.toLowerCase().includes(q)
      );
    });
  }, [activeCatalog, filter, searchQuery]);

  const unlockedIds = useMemo(
    () => new Set([...localUnlocked, ...cloudUnlocked]),
    [localUnlocked, cloudUnlocked]
  );

  const persistLocalUnlocks = (newIds: string[]) => {
    const merged = Array.from(new Set([...localUnlocked, ...newIds]));
    setLocalUnlocked(merged);
    try {
      localStorage.setItem(LOCAL_UNLOCKED_KEY, JSON.stringify(merged));
    } catch {
      // Ignore storage quota issues
    }
  };

  const handleDownloadFreeItem = (item: CatalogItem) => {
    if (!item.freeDownloadUrl) return;
    triggerFileDownload(item.freeDownloadUrl, item.freeFileName || `${item.id}-free.zip`);
    showToast(`Download gratuito iniciado: ${item.title}`);
  };

  const handleDownloadProItem = (item: CatalogItem) => {
    if (!item.paidDownloadUrl) return;
    triggerFileDownload(item.paidDownloadUrl, item.paidFileName || `${item.id}-pro.zip`);
    showToast(`Download Pro iniciado: ${item.title}`);
  };

  // Pagamentos desativados até integração de um provedor que confirme transações.
  const handleBuyProItem = (_item: CatalogItem) => { showToast('Compras indisponíveis: pagamento não configurado.'); };
  const handleBuyProApk = () => { showToast('Compras indisponíveis: pagamento não configurado.'); };
  const handleCompletePayment = async (_method: PaymentMethod): Promise<CartEntry[]> => {
    throw new Error('Pagamento indisponível: nenhum pagamento foi processado.');
  };

  const handleSaveCatalogItem = async (
    id: string,
    data: ReturnType<typeof sanitizeItemPayload>,
    isNew: boolean
  ) => {
    if (!user || !isAdmin) {
      throw new Error(`Apenas ${ADMIN_EMAIL} pode publicar.`);
    }

    const docRef = doc(db, 'catalog_items', id);
    if (isNew) {
      try {
        await setDoc(docRef, {
          ...data,
          authorId: user.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `catalog_items/${id}`);
      }
    } else {
      try {
        await updateDoc(docRef, {
          ...data,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `catalog_items/${id}`);
      }
    }
    showToast(isNew ? 'Publicado no catálogo público.' : 'Item atualizado.');
  };

  const handleSaveApkRelease = async (release: Omit<AppRelease, 'id' | 'updatedAt'>) => {
    if (!user || !isAdmin) return;
    const ref = doc(db, 'app_releases', 'byte-vortex-apk');
    try {
      await setDoc(ref, {
        ...release,
        updatedBy: user.uid,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'app_releases/byte-vortex-apk');
    }
    showToast('Versão oficial do APK atualizada.');
  };

  const confirmDeleteItem = async () => {
    if (!pendingDelete || !isAdmin) return;
    const target = pendingDelete;
    setPendingDelete(null);
    try {
      await deleteDoc(doc(db, 'catalog_items', target.id));
      showToast(`"${target.title}" removido do catálogo.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `catalog_items/${target.id}`);
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0E0F13] text-[#F4F5F7]">
      <Header
        cartCount={cart.length}
        user={user}
        isAdmin={isAdmin}
        onOpenCart={() => setIsCartOpen(true)}
        onNavigateCatalog={(f) => {
          if (f) setFilter(f);
          scrollToSection('catalogo');
        }}
        onNavigateApk={() => scrollToSection('apk')}
        onOpenAdmin={() => {
          setEditingItem(null);
          setAdminInitialTab('catalog');
          setAdminOpen(true);
        }}
      />

      <div role="status" style={{padding:'12px 18px',textAlign:'center',background:'#38251b',color:'#fff'}}>Loja pública. Downloads gratuitos publicados pelo administrador. Compras e pagamentos estão desativados.</div>
      <div style={{padding:'12px 18px',textAlign:'center',background:'#171920',color:'#fff'}}>
        <a href="https://github.com/raullygomesbarbosa2-lgtm/byte-vortex-loja-publica/releases/latest/download/Byte-Vortex-Android-4.4.apk" style={{color:'#fff',textDecoration:'underline',marginRight:'24px'}}>Baixar APK Android 4.4</a>
        <a href="https://github.com/raullygomesbarbosa2-lgtm/byte-vortex-loja-publica/releases/latest/download/Byte-Vortex-Android-10.apk" style={{color:'#fff',textDecoration:'underline'}}>Baixar APK Android 10+</a>
      </div>
      <main className="flex-1">
        <HeroSection
          onExploreCatalog={() => scrollToSection('catalogo')}
          onJumpToApk={() => scrollToSection('apk')}
        />

        <CatalogSection
          items={filteredItems}
          totalCount={activeCatalog.length}
          loading={catalogLoading}
          filter={filter}
          searchQuery={searchQuery}
          isAdmin={isAdmin}
          unlockedIds={unlockedIds}
          onFilterChange={setFilter}
          onSearchChange={setSearchQuery}
          onOpenAdminUpload={() => {
            setEditingItem(null);
            setAdminInitialTab('catalog');
            setAdminOpen(true);
          }}
          onSelectDetail={(item) => setDetailItem(item)}
          onDownloadFree={handleDownloadFreeItem}
          onBuyPro={handleBuyProItem}
          onDownloadPro={handleDownloadProItem}
          onEditItem={(item) => {
            setEditingItem(item);
            setAdminInitialTab('catalog');
            setAdminOpen(true);
          }}
          onDeleteItem={(item) => setPendingDelete(item)}
        />

        <ApkShowcaseSection
          release={apkRelease}
          isProUnlocked={apkRelease ? unlockedIds.has(apkRelease.id) : false}
          isAdmin={isAdmin}
          onDownloadFreeApk={() => {
            if (!apkRelease) return;
            triggerFileDownload(apkRelease.freeApkUrl, apkRelease.freeApkName);
            showToast(`Download gratuito iniciado: ${apkRelease.freeApkName}`);
          }}
          onBuyProApk={handleBuyProApk}
          onDownloadProApk={() => {
            if (!apkRelease) return;
            triggerFileDownload(apkRelease.proApkUrl, apkRelease.proApkName);
            showToast(`Download APK Pro iniciado: ${apkRelease.proApkName}`);
          }}
          onOpenAdminApk={() => {
            setEditingItem(null);
            setAdminInitialTab('apk');
            setAdminOpen(true);
          }}
        />
      </main>

      <footer className="bg-[#0B0C10]">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#8E95A5]">
          <div>
            <p className="font-display text-sm font-semibold text-[#F4F5F7]">Byte Vortex</p>
            <p className="mt-1">
              Loja pública de emuladores, jogos e aplicativo Android APK.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-6">
            <a href="#catalogo" className="hover:text-white transition-colors">
              Catálogo
            </a>
            <a href="#apk" className="hover:text-white transition-colors">
              App APK
            </a>
            <a
              href={`mailto:${ADMIN_EMAIL}?subject=Byte%20Vortex%20-%20Contato`}
              className="hover:text-white transition-colors"
            >
              {ADMIN_EMAIL}
            </a>
            <button
              type="button"
              onClick={() => {
                setEditingItem(null);
                setAdminInitialTab('catalog');
                setAdminOpen(true);
              }}
              className="hover:text-white transition-colors cursor-pointer"
            >
              {isAdmin
                ? `Admin (${user?.email})`
                : user
                  ? `Conta (${user.email})`
                  : 'Entrar com Google ou E-mail'}
            </button>
          </div>
        </div>
      </footer>

      {/* Product Detail Modal */}
      <ProductDetailModal
        item={detailItem}
        isUnlockedPro={detailItem ? unlockedIds.has(detailItem.id) : false}
        onClose={() => setDetailItem(null)}
        onDownloadFree={handleDownloadFreeItem}
        onBuyPro={handleBuyProItem}
        onDownloadPro={handleDownloadProItem}
      />

      {/* Checkout & Payment Drawer */}
      <CheckoutDrawer
        isOpen={isCartOpen}
        cart={cart}
        user={user}
        processing={checkoutBusy}
        onClose={() => setIsCartOpen(false)}
        onRemoveItem={(itemId) =>
          setCart((prev) => prev.filter((item) => item.itemId !== itemId))
        }
        onSwitchToFree={(entry) => {
          if (entry.freeDownloadUrl) {
            triggerFileDownload(entry.freeDownloadUrl, entry.freeFileName);
            setCart((prev) => prev.filter((item) => item.itemId !== entry.itemId));
            showToast(`Download da versão gratuita iniciado: ${entry.title}`);
          }
        }}
        onCompletePayment={handleCompletePayment}
        onSignInGoogle={async () => {
          try {
            await signInWithGoogle();
          } catch (err) {
            const details = formatGoogleAuthError(err);
            if (details.isUnauthorizedDomain) {
              setIsCartOpen(false);
              setEditingItem(null);
              setAdminInitialTab('catalog');
              setAdminOpen(true);
              showToast(details.message);
            } else if (details.message) {
              showToast(details.message);
            }
          }
        }}
        onOpenEmailAuth={() => {
          setIsCartOpen(false);
          setEditingItem(null);
          setAdminInitialTab('catalog');
          setAdminOpen(true);
        }}
      />

      {/* Admin Upload & Email Access Modal */}
      <AdminUploadModal
        isOpen={adminOpen}
        initialTab={adminInitialTab}
        user={user}
        isAdmin={isAdmin}
        editingItem={editingItem}
        currentApkRelease={apkRelease}
        syncedCount={cloudUnlocked.length}
        pendingReset={pendingReset}
        onClearPendingReset={() => {
          setPendingReset(null);
          try {
            const url = new URL(window.location.href);
            url.searchParams.delete('bvReset');
            url.searchParams.delete('email');
            url.searchParams.delete('mode');
            url.searchParams.delete('oobCode');
            url.searchParams.delete('apiKey');
            url.searchParams.delete('lang');
            window.history.replaceState({}, '', url.pathname + url.search + url.hash);
          } catch {
            // ignore
          }
        }}
        onClose={() => {
          setAdminOpen(false);
          setEditingItem(null);
        }}
        onSignInGoogle={async () => {
          await signInWithGoogle();
        }}
        onSignInEmail={async (email, password) => {
          const session = await signInWithEmail(email, password);
          if (session.source === 'email-server') {
            setEmailUser(session);
          }
        }}
        onRegisterEmail={async (email, password) => {
          const session = await registerWithEmail(email, password);
          if (session.source === 'email-server') {
            setEmailUser(session);
          }
        }}
        onCreateUnlimitedResetLink={async (email) => {
          return await createUnlimitedResetLink(email);
        }}
        onConfirmUnlimitedReset={async (email, token, newPassword) => {
          const session = await confirmUnlimitedPasswordReset(email, token, newPassword);
          setEmailUser(session);
          showToast('Nova senha salva com sucesso.');
        }}
        onConfirmFirebaseReset={async (oobCode, newPassword) => {
          const session = await confirmFirebasePasswordReset(oobCode, newPassword);
          if (session?.firebaseUser) {
            setFirebaseUser(session.firebaseUser);
          }
          showToast('Senha redefinida com sucesso!');
        }}
        onResetPassword={async (email) => {
          return await resetPasswordByEmail(email);
        }}
        onResendVerification={async (currentUser) => {
          await resendVerificationEmail(currentUser);
        }}
        onRefreshUser={async () => {
          if (auth.currentUser) {
            await auth.currentUser.reload();
            await auth.currentUser.getIdToken(true);
            setFirebaseUser(auth.currentUser);
            setAuthRefreshTick((t) => t + 1);
          }
        }}
        onSignOut={async () => {
          setEmailUser(null);
          setCloudUnlocked([]);
          await signOutAccount();
        }}
        onSaveCatalogItem={handleSaveCatalogItem}
        onSaveApkRelease={handleSaveApkRelease}
      />

      {/* Delete confirmation modal */}
      {pendingDelete && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md p-6 rounded-xl bg-[#16181F] border border-white/15 space-y-4">
            <h3 className="font-display text-lg font-bold text-white">
              Excluir "{pendingDelete.title}"?
            </h3>
            <p className="text-sm text-[#A3AAB8]">
              Esta ação remove o item permanentemente do catálogo público.
            </p>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setPendingDelete(null)}
                className="px-4 py-2 rounded-lg bg-[#232632] hover:bg-[#303444] text-xs font-semibold text-white cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDeleteItem}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-xs font-semibold text-white cursor-pointer"
              >
                Confirmar Exclusão
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Non-intrusive bottom toast */}
      {toastMessage && (
        <div
          role="status"
          className="fixed bottom-5 right-5 z-50 px-4 py-3 rounded-lg bg-[#1C1F29] border border-white/15 text-xs font-medium text-white shadow-lg"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
