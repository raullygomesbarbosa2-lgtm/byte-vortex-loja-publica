# Byte Vortex Security Specification

## 1. Data Invariants
1. **Strict Admin-Only Catalog & APK Writes**: Only an authenticated user with `request.auth.token.email == 'gomesbarbosaraully@gmail.com'` AND `request.auth.token.email_verified == true` can create, update, or delete documents in `/catalog_items/{itemId}` and `/app_releases/{releaseId}`.
2. **Public Catalog Visibility (Zero PII)**: `/catalog_items` and `/app_releases` are publicly readable (`get` and `list`) so any visitor can browse, filter Free vs Paid versions, and download Free releases or the Byte Vortex APK without friction. No user emails, phone numbers, or addresses are stored in public collections.
3. **Private Order Isolation**: `/orders/{orderId}` documents contain `buyerUid` and purchase records. `get` and `list` are strictly restricted to `resource.data.buyerUid == request.auth.uid` or `isAdmin()`.
4. **Strict Schema & Volumetric Bounds**: All documents enforce `keys().hasAll(...) && keys().hasOnly(...)` on creation, `affectedKeys().hasOnly(...)` on update, strict `.size()` bounds on every string and array, `request.time` server timestamp integrity, and `isValidId()` regex validation (`^[a-zA-Z0-9_\-]+$`) on single-document path IDs.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Non-Admin Catalog Create**: Regular user (`other@gmail.com`, verified) attempts `create` on `/catalog_items/hack-emu` -> **REJECTED** (`isAdmin()` fails).
2. **Unverified Admin Email Spoof**: User with `email: 'gomesbarbosaraully@gmail.com'` and `email_verified: false` attempts `create` on `/catalog_items/spoof-1` -> **REJECTED** (`email_verified == true` fails).
3. **Shadow Field Injection on Catalog Create**: Admin sends valid `CatalogItem` plus `"shadowAdmin": true` -> **REJECTED** (`keys().hasOnly(...)` fails).
4. **Author Spoofing on Catalog Create**: Admin sends `authorId: "someone-else"` (`!= request.auth.uid`) -> **REJECTED** (`incoming().authorId == request.auth.uid` fails).
5. **Client Timestamp Forgery on Catalog Create**: Admin sends `createdAt: Timestamp(2020-01-01)` instead of `serverTimestamp()` -> **REJECTED** (`incoming().createdAt == request.time` fails).
6. **Oversized String / DoW Poisoning**: Admin sends `title` with 500 characters (`> 100`) or `id` with invalid characters `../etc/passwd` -> **REJECTED** (`isValidId()` and `.size() <= 100` fail).
7. **Unbounded Features Array**: Admin sends 25 items in `features` (`> 8`) or non-string first element `[123]` -> **REJECTED** (`features.size() <= 8` and `features[0] is string` fail).
8. **Negative or Extreme Price**: Admin sends `priceBrl: -50` or `accessModel: "free"` with `priceBrl: 99` -> **REJECTED** (price bounds & accessModel consistency fail).
9. **Non-Admin APK Release Overwrite**: Non-admin user attempts `update` on `/app_releases/byte-vortex-apk` to inject a malicious `freeApkUrl` -> **REJECTED** (`isAdmin()` fails).
10. **Cross-User Order Hijack (Read/List)**: User B attempts `get` or unfiltered `list` on `/orders` belonging to User A -> **REJECTED** (`resource.data.buyerUid == request.auth.uid` fails).
11. **Order Identity Spoofing on Create**: User B attempts `create` on `/orders/ord-1` with `buyerUid: "user-A"` -> **REJECTED** (`incoming().buyerUid == request.auth.uid` fails).
12. **Order Terminal State Tampering**: User A attempts `update` or `delete` on their own completed `/orders/ord-1` to change `amountBrl` to `0` -> **REJECTED** (orders are immutable for buyers).
