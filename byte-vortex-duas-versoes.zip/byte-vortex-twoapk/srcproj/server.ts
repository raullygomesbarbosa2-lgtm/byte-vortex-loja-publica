import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ADMIN_EMAIL = 'gomesbarbosaraully@gmail.com';
const UPLOADS_DIR = path.resolve(__dirname, 'uploads');
const DATA_DIR = path.resolve(__dirname, 'data');
const AUTH_STORE_PATH = path.join(DATA_DIR, 'email-auth.json');
const AUTH_SECRET_PATH = path.join(DATA_DIR, '.auth-secret');
const DIST_DIR = path.resolve(__dirname, 'dist');
const CONFIG_PATH = path.resolve(__dirname, 'firebase-applet-config.json');

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface StoredEmailUser {
  uid: string;
  email: string;
  passwordHash: string;
  resetToken?: string;
  orders: string[];
  createdAt: string;
}

interface EmailAuthStore {
  users: Record<string, StoredEmailUser>;
}

function getAuthSecret(): string {
  try {
    if (fs.existsSync(AUTH_SECRET_PATH)) {
      return fs.readFileSync(AUTH_SECRET_PATH, 'utf-8').trim();
    }
  } catch {
    // regenerate below
  }
  const secret = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(AUTH_SECRET_PATH, secret, 'utf-8');
  return secret;
}

const EMAIL_AUTH_SECRET = getAuthSecret();

function readEmailStore(): EmailAuthStore {
  try {
    if (fs.existsSync(AUTH_STORE_PATH)) {
      const raw = fs.readFileSync(AUTH_STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw) as EmailAuthStore;
      if (parsed && typeof parsed.users === 'object') {
        return parsed;
      }
    }
  } catch {
    // ignore corrupt store
  }
  return { users: {} };
}

function writeEmailStore(store: EmailAuthStore): void {
  fs.writeFileSync(AUTH_STORE_PATH, JSON.stringify(store, null, 2), 'utf-8');
}

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [salt, keyHex] = stored.split(':');
  if (!salt || !keyHex) return false;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derivedBuf = crypto.scryptSync(password, salt, 64);
  if (keyBuf.length !== derivedBuf.length) return false;
  return crypto.timingSafeEqual(keyBuf, derivedBuf);
}

function signEmailToken(uid: string, email: string): string {
  const payload = Buffer.from(
    JSON.stringify({ uid, email, exp: Date.now() + 1000 * 60 * 60 * 24 * 30 }),
    'utf-8'
  ).toString('base64url');
  const sig = crypto
    .createHmac('sha256', EMAIL_AUTH_SECRET)
    .update(payload)
    .digest('base64url');
  return `${payload}.${sig}`;
}

function verifyEmailToken(token: string): { uid: string; email: string } | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expected = crypto
    .createHmac('sha256', EMAIL_AUTH_SECRET)
    .update(payload)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8')) as {
      uid?: string;
      email?: string;
      exp?: number;
    };
    if (!parsed.uid || !parsed.email || !parsed.exp || parsed.exp < Date.now()) {
      return null;
    }
    return { uid: parsed.uid, email: parsed.email };
  } catch {
    return null;
  }
}

interface FirebaseAppletConfig {
  apiKey?: string;
}

function getFirebaseApiKey(): string {
  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as FirebaseAppletConfig;
    return parsed.apiKey ?? '';
  } catch {
    return '';
  }
}

async function verifyAdminIdToken(idToken: string): Promise<{ ok: boolean; email?: string; reason?: string }> {
  const apiKey = getFirebaseApiKey();
  if (!apiKey) {
    return { ok: false, reason: 'Configuração do Firebase ausente no servidor.' };
  }

  try {
    const resp = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      }
    );

    if (!resp.ok) {
      return { ok: false, reason: 'Token de autenticação inválido ou expirado.' };
    }

    const data = (await resp.json()) as {
      users?: Array<{ email?: string; emailVerified?: boolean }>;
    };

    const user = data.users?.[0];
    if (!user) {
      return { ok: false, reason: 'Usuário não encontrado.' };
    }

    if (user.email !== ADMIN_EMAIL || user.emailVerified !== true) {
      return {
        ok: false,
        email: user.email,
        reason: `Acesso restrito ao administrador autorizado (${ADMIN_EMAIL}).`,
      };
    }

    return { ok: true, email: user.email };
  } catch {
    return { ok: false, reason: 'Falha ao validar credenciais do administrador.' };
  }
}

// --- Pure Node Uncompressed ZIP / APK Builder (valid PKZIP archive) ---
const CRC32_TABLE = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let k = 0; k < 8; k++) {
    c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  CRC32_TABLE[i] = c >>> 0;
}

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC32_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

interface ZipEntryInput {
  name: string;
  content: string | Buffer;
}

function buildZipArchive(entries: ZipEntryInput[]): Buffer {
  const localChunks: Buffer[] = [];
  const centralChunks: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBuf = Buffer.from(entry.name, 'utf-8');
    const dataBuf = Buffer.isBuffer(entry.content) ? entry.content : Buffer.from(entry.content, 'utf-8');
    const crc = crc32(dataBuf);

    // Local file header (30 bytes + name)
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4); // version needed
    localHeader.writeUInt16LE(0, 6); // flags
    localHeader.writeUInt16LE(0, 8); // compression: store (0)
    localHeader.writeUInt16LE(0, 10); // mod time
    localHeader.writeUInt16LE(0x5421, 12); // mod date
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(dataBuf.length, 18);
    localHeader.writeUInt32LE(dataBuf.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28); // extra len

    localChunks.push(localHeader, nameBuf, dataBuf);

    // Central directory header (46 bytes + name)
    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4); // version made by
    centralHeader.writeUInt16LE(20, 6); // version needed
    centralHeader.writeUInt16LE(0, 8); // flags
    centralHeader.writeUInt16LE(0, 10); // compression: store
    centralHeader.writeUInt16LE(0, 12);
    centralHeader.writeUInt16LE(0x5421, 14);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(dataBuf.length, 20);
    centralHeader.writeUInt32LE(dataBuf.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42);

    centralChunks.push(centralHeader, nameBuf);
    offset += localHeader.length + nameBuf.length + dataBuf.length;
  }

  const centralDirBuf = Buffer.concat(centralChunks);
  const endRecord = Buffer.alloc(22);
  endRecord.writeUInt32LE(0x06054b50, 0);
  endRecord.writeUInt16LE(0, 4);
  endRecord.writeUInt16LE(0, 6);
  endRecord.writeUInt16LE(entries.length, 8);
  endRecord.writeUInt16LE(entries.length, 10);
  endRecord.writeUInt32LE(centralDirBuf.length, 12);
  endRecord.writeUInt32LE(offset, 16);
  endRecord.writeUInt16LE(0, 20);

  return Buffer.concat([...localChunks, centralDirBuf, endRecord]);
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

const ALLOWED_EXTENSIONS = new Set([
  '.apk',
  '.zip',
  '.7z',
  '.rar',
  '.nes',
  '.sfc',
  '.smc',
  '.gba',
  '.gb',
  '.gbc',
  '.n64',
  '.z64',
  '.iso',
  '.bin',
  '.cue',
  '.chd',
  '.png',
  '.jpg',
  '.jpeg',
  '.webp',
]);

const STARTER_PACKAGE_METADATA: Record<
  string,
  { title: string; edition: string; platform: string; version: string; notes: string; isApk?: boolean }
> = {
  'byte-vortex-free.apk': {
    title: 'Byte Vortex Mobile',
    edition: 'Gratuita (Padrão)',
    platform: 'Android 9.0+',
    version: '3.4.0',
    notes: 'Inclui launcher unificado, suporte a controles Bluetooth e núcleos básicos.',
    isApk: true,
  },
  'byte-vortex-pro.apk': {
    title: 'Byte Vortex Mobile Pro',
    edition: 'Pro (Completa)',
    platform: 'Android 9.0+',
    version: '3.4.0-pro',
    notes: 'Sem anúncios, shaders CRT/4K, saves na nuvem e turbo multithread.',
    isApk: true,
  },
};

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '35mb' }));

  // Pure Email & Password auth routes (independent of Google Sign-In)
  app.post('/api/email-auth/register', (req, res) => {
    const { email, password } = req.body as { email?: string; password?: string };
    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      res.status(400).json({ error: 'Informe um endereço de e-mail válido.' });
      return;
    }
    if (typeof password !== 'string' || password.length < 6) {
      res.status(400).json({ error: 'A senha precisa ter pelo menos 6 caracteres.' });
      return;
    }

    const store = readEmailStore();
    const existing = store.users[cleanEmail];
    if (existing && existing.passwordHash) {
      res.status(409).json({ error: 'Este e-mail já está cadastrado. Use a aba Entrar.' });
      return;
    }

    const uid = existing?.uid ?? `email_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
    store.users[cleanEmail] = {
      uid,
      email: cleanEmail,
      passwordHash: hashPassword(password),
      resetToken: existing?.resetToken,
      orders: existing?.orders ?? [],
      createdAt: existing?.createdAt ?? new Date().toISOString(),
    };
    writeEmailStore(store);

    const token = signEmailToken(uid, cleanEmail);
    res.json({
      token,
      user: { uid, email: cleanEmail, emailVerified: true, source: 'email-server' },
    });
  });

  app.post('/api/email-auth/login', (req, res) => {
    const { email, password } = req.body as { email?: string; password?: string };
    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    if (!cleanEmail || typeof password !== 'string') {
      res.status(400).json({ error: 'Preencha e-mail e senha.' });
      return;
    }

    const store = readEmailStore();
    const record = store.users[cleanEmail];
    if (!record) {
      res.status(404).json({
        error: 'E-mail ainda não cadastrado. Clique na aba "Criar conta" para registrar.',
      });
      return;
    }
    if (!verifyPassword(password, record.passwordHash)) {
      res.status(401).json({ error: 'E-mail ou senha incorretos.' });
      return;
    }

    const token = signEmailToken(record.uid, record.email);
    res.json({
      token,
      user: {
        uid: record.uid,
        email: record.email,
        emailVerified: true,
        source: 'email-server',
      },
    });
  });

  app.get('/api/email-auth/me', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Não autenticado.' });
      return;
    }
    const verified = verifyEmailToken(authHeader.slice('Bearer '.length).trim());
    if (!verified) {
      res.status(401).json({ error: 'Sessão expirada.' });
      return;
    }
    const store = readEmailStore();
    const record = store.users[verified.email];
    if (!record) {
      res.status(404).json({ error: 'Conta não encontrada.' });
      return;
    }
    res.json({
      user: {
        uid: record.uid,
        email: record.email,
        emailVerified: true,
        source: 'email-server',
      },
      orders: record.orders ?? [],
    });
  });

  app.post('/api/email-auth/orders', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Não autenticado.' });
      return;
    }
    const verified = verifyEmailToken(authHeader.slice('Bearer '.length).trim());
    if (!verified) {
      res.status(401).json({ error: 'Sessão expirada.' });
      return;
    }
    const { itemIds } = req.body as { itemIds?: unknown };
    if (!Array.isArray(itemIds)) {
      res.status(400).json({ error: 'Itens inválidos.' });
      return;
    }
    const store = readEmailStore();
    const record = store.users[verified.email];
    if (!record) {
      res.status(404).json({ error: 'Conta não encontrada.' });
      return;
    }
    const validIds = itemIds.filter((x): x is string => typeof x === 'string' && x.length > 0);
    record.orders = Array.from(new Set([...(record.orders ?? []), ...validIds]));
    writeEmailStore(store);
    res.json({ orders: record.orders });
  });

  // Non-expiring, reusable password reset link generator
  app.post('/api/email-auth/reset-link', (req, res) => {
    const { email, origin } = req.body as { email?: string; origin?: string };
    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      res.status(400).json({ error: 'Informe um endereço de e-mail válido.' });
      return;
    }

    const store = readEmailStore();
    let record = store.users[cleanEmail];
    const resetToken = record?.resetToken || crypto.randomBytes(24).toString('hex');
    if (!record) {
      const uid = `email_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
      record = {
        uid,
        email: cleanEmail,
        passwordHash: '',
        resetToken,
        orders: [],
        createdAt: new Date().toISOString(),
      };
      store.users[cleanEmail] = record;
    } else if (!record.resetToken) {
      record.resetToken = resetToken;
    }
    writeEmailStore(store);

    const baseOrigin =
      typeof origin === 'string' && /^https?:\/\//i.test(origin)
        ? origin.replace(/\/+$/, '')
        : `${req.protocol}://${req.get('host') ?? 'localhost:3000'}`;
    const resetUrl = `${baseOrigin}/?bvReset=${encodeURIComponent(resetToken)}&email=${encodeURIComponent(cleanEmail)}`;

    res.json({
      email: cleanEmail,
      resetToken,
      resetUrl,
    });
  });

  // Confirm new password using the non-expiring token (never expires, reusable until changed)
  app.post('/api/email-auth/reset-confirm', (req, res) => {
    const { email, resetToken, newPassword } = req.body as {
      email?: string;
      resetToken?: string;
      newPassword?: string;
    };
    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    const cleanToken = typeof resetToken === 'string' ? resetToken.trim() : '';

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail) || !cleanToken) {
      res.status(400).json({ error: 'Dados de redefinição inválidos.' });
      return;
    }
    if (typeof newPassword !== 'string' || newPassword.length < 6) {
      res.status(400).json({ error: 'A nova senha precisa ter pelo menos 6 caracteres.' });
      return;
    }

    const store = readEmailStore();
    const record = store.users[cleanEmail];
    if (!record || !record.resetToken || record.resetToken !== cleanToken) {
      res.status(400).json({ error: 'Link de redefinição inválido para este e-mail.' });
      return;
    }

    record.passwordHash = hashPassword(newPassword);
    writeEmailStore(store);

    const sessionToken = signEmailToken(record.uid, record.email);
    res.json({
      token: sessionToken,
      user: {
        uid: record.uid,
        email: record.email,
        emailVerified: true,
        source: 'email-server',
      },
    });
  });

  // Admin-only real file upload endpoint
  app.post('/api/upload', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Token de autenticação obrigatório.' });
      return;
    }

    const token = authHeader.slice('Bearer '.length).trim();
    const check = await verifyAdminIdToken(token);
    if (!check.ok) {
      res.status(403).json({ error: check.reason ?? 'Acesso negado.' });
      return;
    }

    const { fileName, dataBase64 } = req.body as {
      fileName?: string;
      dataBase64?: string;
    };

    if (!fileName || typeof fileName !== 'string' || !dataBase64 || typeof dataBase64 !== 'string') {
      res.status(400).json({ error: 'Arquivo inválido.' });
      return;
    }

    const ext = path.extname(fileName).toLowerCase();
    if (!ALLOWED_EXTENSIONS.has(ext)) {
      res.status(400).json({
        error: `Formato não permitido (${ext}). Aceitos: .apk, .zip, .7z, .nes, .sfc, .gba, .iso, .bin, .png, .jpg.`,
      });
      return;
    }

    const cleanBase = path
      .basename(fileName, ext)
      .replace(/[^a-zA-Z0-9_\-]/g, '_')
      .slice(0, 60) || 'arquivo';

    const storedName = `${Date.now()}-${crypto.randomBytes(3).toString('hex')}-${cleanBase}${ext}`;
    const rawBase64 = dataBase64.includes(',') ? dataBase64.split(',')[1] : dataBase64;
    const buffer = Buffer.from(rawBase64, 'base64');

    if (buffer.length === 0 || buffer.length > 26 * 1024 * 1024) {
      res.status(400).json({ error: 'O arquivo deve ter entre 1 byte e 25 MB.' });
      return;
    }

    fs.writeFileSync(path.join(UPLOADS_DIR, storedName), buffer);

    res.json({
      url: `/uploads/${storedName}`,
      fileName: `${cleanBase}${ext}`,
      sizeBytes: buffer.length,
      sizeFormatted: formatBytes(buffer.length),
    });
  });

  // Serve uploaded files safely
  app.get('/uploads/:filename', (req, res) => {
    const safeName = path.basename(req.params.filename);
    const fullPath = path.join(UPLOADS_DIR, safeName);

    if (!fs.existsSync(fullPath)) {
      res.status(404).json({ error: 'Arquivo não encontrado.' });
      return;
    }

    const ext = path.extname(safeName).toLowerCase();
    if (ext === '.png' || ext === '.jpg' || ext === '.jpeg' || ext === '.webp') {
      res.sendFile(fullPath);
      return;
    }

    if (ext === '.apk') {
      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    }
    res.download(fullPath, safeName);
  });

  // Starter APK & Emulator Package real download generator
  app.get('/api/download/:packageId', (req, res) => {
    const packageId = path.basename(req.params.packageId);
    const meta = STARTER_PACKAGE_METADATA[packageId];

    if (!meta) {
      res.status(404).json({ error: 'Pacote não encontrado.' });
      return;
    }

    const manifestJson = JSON.stringify(
      {
        publisher: 'Byte Vortex Store',
        packageId,
        title: meta.title,
        edition: meta.edition,
        platform: meta.platform,
        version: meta.version,
        notes: meta.notes,
        generatedAt: new Date().toISOString(),
      },
      null,
      2
    );

    const entries: ZipEntryInput[] = meta.isApk
      ? [
          {
            name: 'META-INF/MANIFEST.MF',
            content: `Manifest-Version: 1.0\nCreated-By: Byte Vortex Distribution\nPackage-Title: ${meta.title}\nVersion-Name: ${meta.version}\n`,
          },
          {
            name: 'AndroidManifest.xml',
            content: `<manifest package="com.bytevortex.app" versionName="${meta.version}" edition="${meta.edition}" />`,
          },
          {
            name: 'assets/byte_vortex_release.json',
            content: manifestJson,
          },
          {
            name: 'LEIA-ME.txt',
            content: `${meta.title} (${meta.edition})\nVersão: ${meta.version}\nCompatibilidade: ${meta.platform}\n\n${meta.notes}\n`,
          },
        ]
      : [
          {
            name: 'vortex_package.json',
            content: manifestJson,
          },
          {
            name: 'LEIA-ME.txt',
            content: `Byte Vortex — ${meta.title}\nEdição: ${meta.edition}\nPlataforma: ${meta.platform}\nVersão: ${meta.version}\n\n${meta.notes}\n`,
          },
        ];

    const archive = buildZipArchive(entries);
    res.setHeader(
      'Content-Type',
      meta.isApk ? 'application/vnd.android.package-archive' : 'application/zip'
    );
    res.setHeader('Content-Disposition', `attachment; filename="${packageId}"`);
    res.send(archive);
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(DIST_DIR));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(DIST_DIR, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Byte Vortex server running on http://0.0.0.0:${port}`);
  });
}

startServer();
