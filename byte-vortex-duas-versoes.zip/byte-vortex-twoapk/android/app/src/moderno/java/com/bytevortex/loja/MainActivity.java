package com.bytevortex.loja;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.DownloadListener;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebResourceResponse;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends Activity {
 private static final String STORE_URL = "https://raullygomesbarbosa2-lgtm.github.io/byte-vortex-loja-publica/";
 private WebView web;
 private ValueCallback<Uri[]> pick;
 private FrameLayout root;
 private View errorPanel;
 private final Handler handler = new Handler(Looper.getMainLooper());
 private boolean showingError = false;
 private int loadGeneration = 0;

 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setStatusBarColor(Color.rgb(11,12,16));
  getWindow().setNavigationBarColor(Color.rgb(11,12,16));
  root = new FrameLayout(this);
  root.setBackgroundColor(Color.rgb(14,15,19));
  web = new WebView(this);
  WebSettings s = web.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowContentAccess(true);
  s.setAllowFileAccess(false);
  s.setCacheMode(WebSettings.LOAD_DEFAULT);
  s.setSupportZoom(false);
  s.setBuiltInZoomControls(false);
  if (android.os.Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  web.setBackgroundColor(Color.rgb(14,15,19));
  web.setWebViewClient(new WebViewClient() {
   @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
    if (url.startsWith("https://raullygomesbarbosa2-lgtm.github.io/byte-vortex-loja-publica/") || url.startsWith("about:")) return false;
    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
    catch (Exception e) { Toast.makeText(MainActivity.this, "Não foi possível abrir o endereço", Toast.LENGTH_SHORT).show(); }
    return true;
   }
   @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
    super.onPageStarted(v,url,icon);
    showingError = false;
    errorPanel.setVisibility(View.GONE);
    web.setVisibility(View.VISIBLE);
   }
   @Override public void onPageFinished(WebView v, String url) {
    super.onPageFinished(v,url);
    showingError = false;
    errorPanel.setVisibility(View.GONE);
    web.setVisibility(View.VISIBLE);
   }
   @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError error) {
    super.onReceivedError(v,req,error);
    if (req != null) {
     String failedUrl = req.getUrl() == null ? "" : req.getUrl().toString();
     if (req.isForMainFrame() || failedUrl.contains("/assets/index-") ) showLoadError();
    }
   }
   @Override public void onReceivedHttpError(WebView v, WebResourceRequest req, WebResourceResponse response) {
    super.onReceivedHttpError(v,req,response);
    if (req != null && req.isForMainFrame() && response != null && response.getStatusCode() >= 500) showLoadError();
   }
  });
  web.setDownloadListener(new DownloadListener() {
   @Override public void onDownloadStart(String u,String ua,String cd,String mt,long l) {
    try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u))); }
    catch(Exception e) { Toast.makeText(MainActivity.this,"Não foi possível abrir o download",Toast.LENGTH_SHORT).show(); }
   }
  });
  web.setWebChromeClient(new ModernChrome());
  root.addView(web,new FrameLayout.LayoutParams(-1,-1));
  errorPanel = makeErrorPanel();
  errorPanel.setVisibility(View.GONE);
  root.addView(errorPanel,new FrameLayout.LayoutParams(-1,-1));
  setContentView(root);
  loadStore();
 }

 private int dp(float x) { return (int)(x*getResources().getDisplayMetrics().density+0.5f); }

 private View makeErrorPanel() {
  LinearLayout box = new LinearLayout(this);
  box.setOrientation(LinearLayout.VERTICAL);
  box.setGravity(Gravity.CENTER);
  box.setPadding(dp(26),dp(28),dp(26),dp(28));
  box.setBackgroundColor(Color.rgb(14,15,19));
  TextView title = new TextView(this);
  title.setText("A conexão com a loja caiu");
  title.setTextColor(Color.WHITE);
  title.setTextSize(21);
  title.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
  title.setGravity(Gravity.CENTER);
  box.addView(title,new LinearLayout.LayoutParams(-1,-2));
  TextView message = new TextView(this);
  message.setText("Pode ser uma queda momentânea da internet. Confira sua conexão e tente novamente; seus dados e publicações não foram apagados.");
  message.setTextColor(Color.rgb(190,195,205));
  message.setTextSize(15);
  message.setGravity(Gravity.CENTER);
  message.setLineSpacing(dp(3),1.0f);
  LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1,-2);
  mp.topMargin=dp(14); mp.bottomMargin=dp(24);
  box.addView(message,mp);
  Button retry = new Button(this);
  retry.setText("Tentar novamente");
  retry.setAllCaps(false);
  retry.setTextColor(Color.WHITE);
  retry.setTextSize(15);
  retry.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
  retry.setBackgroundColor(Color.rgb(217,56,17));
  box.addView(retry,new LinearLayout.LayoutParams(-1,dp(52)));
  retry.setOnClickListener(new View.OnClickListener(){ @Override public void onClick(View v){loadStore();} });
  Button browser = new Button(this);
  browser.setText("Abrir no navegador");
  browser.setAllCaps(false);
  browser.setTextColor(Color.WHITE);
  browser.setTextSize(14);
  browser.setBackgroundColor(Color.rgb(35,38,50));
  LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,dp(50)); bp.topMargin=dp(10);
  box.addView(browser,bp);
  browser.setOnClickListener(new View.OnClickListener(){ @Override public void onClick(View v){
   try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(STORE_URL))); }
   catch(Exception e){ Toast.makeText(MainActivity.this,"Nenhum navegador disponível",Toast.LENGTH_SHORT).show(); }
  }});
  return box;
 }

 private void loadStore() {
  if (web == null) return;
  loadGeneration++;
  final int generation=loadGeneration;
  showingError=false;
  errorPanel.setVisibility(View.GONE);
  web.setVisibility(View.VISIBLE);
  web.loadUrl(STORE_URL);
  handler.postDelayed(new Runnable(){ @Override public void run(){
   if(generation==loadGeneration && web!=null && !showingError) showLoadError();
  }},25000);
 }

 private void showLoadError() {
  if(showingError || isFinishing()) return;
  showingError=true;
  web.setVisibility(View.GONE);
  errorPanel.setVisibility(View.VISIBLE);
 }

 @android.annotation.TargetApi(21) private class ModernChrome extends WebChromeClient {
  @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){
   if(pick!=null)pick.onReceiveValue(null); pick=cb;
   try { startActivityForResult(params.createIntent(),101); return true; }
   catch(Exception e){ pick=null; cb.onReceiveValue(null); return false; }
  }
 }
 @Override protected void onActivityResult(int req,int result,Intent data){
  super.onActivityResult(req,result,data);
  if(req==101&&pick!=null){ if(android.os.Build.VERSION.SDK_INT>=21)pick.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data)); else pick.onReceiveValue(null); pick=null; }
 }
 @Override protected void onResume(){ super.onResume(); if(showingError && web!=null) handler.postDelayed(new Runnable(){@Override public void run(){if(showingError)loadStore();}},350); }
 @Override protected void onDestroy(){ handler.removeCallbacksAndMessages(null); if(web!=null){web.stopLoading();web.destroy();web=null;} super.onDestroy(); }
 @Override public void onBackPressed(){ if(showingError){finish();return;} if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed(); }
}
