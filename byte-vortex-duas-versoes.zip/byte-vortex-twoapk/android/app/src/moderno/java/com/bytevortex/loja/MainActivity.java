package com.bytevortex.loja;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.content.Intent;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.DownloadListener;
import android.widget.Toast;

public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> pick;
 @Override public void onCreate(Bundle b){
  super.onCreate(b); web=new WebView(this); WebSettings s=web.getSettings();
  s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowContentAccess(true);s.setAllowFileAccess(true);
  if(android.os.Build.VERSION.SDK_INT>=21){s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);}
  web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,String url){
   if(url.startsWith("file:///android_asset/") || url.startsWith("https://raullygomesbarbosa2-lgtm.github.io/byte-vortex-loja-publica/") || url.startsWith("about:"))return false;
   try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(MainActivity.this,"Não foi possível abrir o endereço",Toast.LENGTH_SHORT).show();}return true;
  }});
  web.setDownloadListener(new DownloadListener(){public void onDownloadStart(String u,String ua,String cd,String mt,long l){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){Toast.makeText(MainActivity.this,"Não foi possível abrir o download",Toast.LENGTH_SHORT).show();}}});
  if(android.os.Build.VERSION.SDK_INT>=21)web.setWebChromeClient(new ModernChrome());
  else web.setWebChromeClient(new WebChromeClient());
  setContentView(web); web.loadUrl("https://raullygomesbarbosa2-lgtm.github.io/byte-vortex-loja-publica/");
 }
 @android.annotation.TargetApi(21) private class ModernChrome extends WebChromeClient {
  @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){if(pick!=null)pick.onReceiveValue(null);pick=cb;try{startActivityForResult(params.createIntent(),101);return true;}catch(Exception e){pick=null;cb.onReceiveValue(null);return false;}}
 }
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==101&&pick!=null){if(android.os.Build.VERSION.SDK_INT>=21)pick.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));else pick.onReceiveValue(null);pick=null;}}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
