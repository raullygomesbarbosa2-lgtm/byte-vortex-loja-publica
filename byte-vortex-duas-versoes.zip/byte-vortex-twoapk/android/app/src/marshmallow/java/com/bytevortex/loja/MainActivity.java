package com.bytevortex.loja;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Lightweight native launcher for Android 6.0. Does not instantiate WebView. */
public class MainActivity extends Activity {
  private static final String STORE_URL = "https://raullygomesbarbosa2-lgtm.github.io/byte-vortex-loja-publica/";
  private static final String EMAIL_URL = STORE_URL + "?acesso=email";
  private static final int BG = Color.rgb(14, 15, 19);
  private static final int FG = Color.rgb(244, 245, 247);
  private static final int MUTED = Color.rgb(163, 170, 184);
  private static final int ACCENT = Color.rgb(217, 56, 17);

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(11, 12, 16));
    getWindow().setNavigationBarColor(Color.rgb(11, 12, 16));
    showHome();
  }

  private int dp(float value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }

  private void showHome() {
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setGravity(Gravity.CENTER_VERTICAL);
    root.setPadding(dp(24), dp(28), dp(24), dp(28));
    root.setBackgroundColor(BG);

    TextView brand = new TextView(this);
    brand.setText("BYTE VORTEX");
    brand.setTextColor(FG);
    brand.setTextSize(25);
    brand.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
    root.addView(brand, new LinearLayout.LayoutParams(-1, -2));

    TextView heading = new TextView(this);
    heading.setText("Sua loja de jogos e emuladores");
    heading.setTextColor(FG);
    heading.setTextSize(19);
    heading.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
    LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
    hp.topMargin = dp(28);
    root.addView(heading, hp);

    TextView info = new TextView(this);
    info.setText("Este modo leve evita a tela preta no Android 6.0. A loja abre no navegador do celular e precisa de internet.");
    info.setTextColor(MUTED);
    info.setTextSize(15);
    info.setLineSpacing(dp(3), 1.0f);
    LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
    ip.topMargin = dp(10);
    ip.bottomMargin = dp(24);
    root.addView(info, ip);

    Button store = makeButton("ABRIR A LOJA", ACCENT, FG);
    root.addView(store, buttonParams());
    store.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) { openInBrowser(STORE_URL); }
    });

    Button email = makeButton("ACESSAR COM E-MAIL", Color.rgb(35, 38, 50), FG);
    LinearLayout.LayoutParams ep = buttonParams();
    ep.topMargin = dp(12);
    root.addView(email, ep);
    email.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) { openInBrowser(EMAIL_URL); }
    });

    TextView foot = new TextView(this);
    foot.setText("Android 6.0+ · Byte Vortex");
    foot.setTextColor(MUTED);
    foot.setTextSize(12);
    foot.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
    fp.topMargin = dp(32);
    root.addView(foot, fp);
    setContentView(root);
  }

  private Button makeButton(String label, int background, int foreground) {
    Button button = new Button(this);
    button.setText(label);
    button.setTextColor(foreground);
    button.setTextSize(14);
    button.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
    button.setAllCaps(false);
    button.setBackgroundColor(background);
    button.setMinHeight(dp(52));
    return button;
  }

  private LinearLayout.LayoutParams buttonParams() {
    return new LinearLayout.LayoutParams(-1, dp(54));
  }

  private void openInBrowser(String url) {
    try {
      Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
      startActivity(intent);
    } catch (Exception e) {
      Toast.makeText(this, "Não encontrei um navegador. Instale ou atualize um navegador e tente de novo.", Toast.LENGTH_LONG).show();
    }
  }
}
